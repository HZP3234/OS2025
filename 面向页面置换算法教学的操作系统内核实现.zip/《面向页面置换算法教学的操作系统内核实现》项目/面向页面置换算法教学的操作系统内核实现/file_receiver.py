#!/usr/bin/env python3
"""
内核文件接收器 - 正确接收JSON数据并保存到results文件夹
用于接收内核通过串口输出的JSON格式数据
"""

import os
import sys
import json
import re
from datetime import datetime

class KernelFileReceiver:
    def __init__(self):
        self.results_dir = "results"
        self.ensure_results_dir()
        
    def ensure_results_dir(self):
        """确保results文件夹存在"""
        if not os.path.exists(self.results_dir):
            os.makedirs(self.results_dir)
            print(f"创建results文件夹: {self.results_dir}")
    
    def process_line(self, line):
        """处理接收到的每一行数据"""
        line = line.strip()
        
        # 检测文件开始标记
        if "=== FILE_BEGIN:" in line:
            return self.handle_file_begin(line)
        
        # 检测文件结束标记
        elif "=== FILE_END:" in line:
            return self.handle_file_end(line)
        
        # 检测JSON内容
        elif hasattr(self, 'current_file') and self.current_file:
            if line.startswith('{') or hasattr(self, 'in_json') and self.in_json:
                return self.handle_json_content(line)
        
        return None
    
    def handle_file_begin(self, line):
        """处理文件开始标记"""
        # 提取文件名
        match = re.search(r'=== FILE_BEGIN:\s*(.+?)\s*===', line)
        if match:
            filename = match.group(1).strip()
            # 清理文件名
            safe_filename = self.clean_filename(filename)
            
            self.current_file = safe_filename
            self.json_lines = []
            self.in_json = False
            
            print(f"\n✓ 开始接收文件: {safe_filename}")
            return True
        return False
    
    def handle_file_end(self, line):
        """处理文件结束标记"""
        if hasattr(self, 'current_file') and self.current_file:
            # 提取文件名进行验证
            match = re.search(r'=== FILE_END:\s*(.+?)\s*===', line)
            if match:
                end_filename = match.group(1).strip()
                if self.current_file == end_filename:
                    print(f"✓ {self.current_file} 文件接收完成")
                    
                    # 保存文件
                    self.save_current_file()
                    
                    # 清理状态
                    self.current_file = None
                    self.json_lines = []
                    self.in_json = False
                    return True
        return False
    
    def handle_json_content(self, line):
        """处理JSON内容"""
        if line.startswith('{'):
            self.in_json = True
        
        if self.in_json:
            self.json_lines.append(line)
            
            # 检查JSON是否结束
            if line.strip().endswith('}'):
                self.in_json = False
                print(f"✓ JSON内容接收完成 ({len(self.json_lines)} 行)")
        return True
    
    def save_current_file(self):
        """保存当前接收的文件"""
        if not self.json_lines:
            return False
        
        try:
            # 合并JSON内容
            json_content = '\n'.join(self.json_lines)
            
            # 保存文件
            filepath = os.path.join(self.results_dir, self.current_file)
            
            # 尝试解析JSON
            try:
                json_data = json.loads(json_content)
                with open(filepath, 'w', encoding='utf-8') as f:
                    json.dump(json_data, f, indent=2, ensure_ascii=False)
                print(f"✓ JSON文件已保存: {filepath}")
                
            except json.JSONDecodeError:
                # 如果不是有效JSON，保存为文本
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(json_content)
                print(f"✓ 文本文件已保存: {filepath}")
            
            return True
            
        except Exception as e:
            print(f"✗ 保存文件失败: {e}")
            return False
    
    def clean_filename(self, filename):
        """清理文件名"""
        # 移除或替换不安全的字符
        safe_filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        return safe_filename
    
    def generate_summary(self):
        """生成结果摘要"""
        summary_file = os.path.join(self.results_dir, "summary.txt")
        file_count = 0
        
        with open(summary_file, 'w', encoding='utf-8') as f:
            f.write("页面置换算法测试结果摘要\n")
            f.write("=" * 50 + "\n")
            f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 50 + "\n\n")
            
            # 查找所有JSON文件
            for filename in sorted(os.listdir(self.results_dir)):
                if filename.endswith('.json') and filename != 'summary.txt':
                    filepath = os.path.join(self.results_dir, filename)
                    try:
                        with open(filepath, 'r', encoding='utf-8') as json_file:
                            data = json.load(json_file)
                            file_count += 1
                            
                            f.write(f"算法结果 - {filename}:\n")
                            f.write(f"  文件名: {data.get('filename', 'N/A')}\n")
                            f.write(f"  文件大小: {data.get('filesize', 'N/A')} 字节\n")
                            
                            if 'results' in data:
                                for result in data['results']:
                                    for key, value in result.items():
                                        f.write(f"  {key}: {value}\n")
                            f.write("\n" + "-" * 30 + "\n\n")
                    except Exception as e:
                        f.write(f"读取文件 {filename} 时出错: {e}\n\n")
            
            f.write(f"总计处理文件数: {file_count}\n")
        
        print(f"结果摘要已生成: {summary_file}")
        return file_count
    
    def run_interactive(self):
        """交互模式：接收串口数据"""
        print("内核文件接收器")
        print("=" * 50)
        print("请粘贴从内核串口接收到的数据")
        print("程序会自动识别FILE_BEGIN和FILE_END标记")
        print("输入 'quit' 结束程序")
        print("=" * 50)
        
        try:
            while True:
                line = input("> ")
                if line.lower() == 'quit':
                    break
                
                self.process_line(line)
                
        except KeyboardInterrupt:
            print("\n程序被用户中断")
        except Exception as e:
            print(f"\n发生错误: {e}")
        finally:
            file_count = self.generate_summary()
            print(f"\n处理完成，共接收 {file_count} 个文件")

def main():
    receiver = KernelFileReceiver()
    receiver.run_interactive()

if __name__ == "__main__":
    main()