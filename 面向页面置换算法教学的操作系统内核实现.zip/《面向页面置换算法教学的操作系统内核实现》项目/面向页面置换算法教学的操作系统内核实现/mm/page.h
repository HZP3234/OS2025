#ifndef __PAGE_H__
#define __PAGE_H__

#include "../lib/common.h"

// 页表项结构
typedef u32 page_entry_t;

// 页帧状态
typedef enum {
    PAGE_FREE,
    PAGE_USED,
    PAGE_RESERVED
} page_status_t;

// 页帧描述符
typedef struct {
    page_status_t status;
    u32 reference_count;
    u32 flags;
} page_frame_t;

// 页帧管理器
typedef struct {
    page_frame_t* frames;
    u32 total_frames;
    u32 free_frames;
    u32 used_frames;
    u32 reserved_frames;
    u32 next_free_frame;
} page_frame_manager_t;

// CLOCK页面置换算法
typedef struct {
    u32* frames;
    u32* ref_bits;
    u32* vaddrs;
    u32 hand;
    u32 count;
} clock_replacer_t;

// 物理内存布局常量
#define KERNEL_BASE     0x100000    // 内核起始地址 1MB
#define MEMORY_BASE     0x0         // 物理内存起始地址

// LRU页面置换算法
#define LRU_MAX_FRAMES 64

typedef struct {
    u32 frame;
    u32 virtual_addr;
    u32 last_access_time;
} lru_entry_t;

typedef struct {
    lru_entry_t* entries;
    u32* access_order;
    u32 hand;
    u32 count;
    u32 max_count;
} lru_replacer_t;

// 函数声明
void page_frame_init(void);
u32 alloc_page_frame(void);
void free_page_frame(u32 frame);
page_frame_manager_t* get_page_frame_manager(void);
u32 get_total_memory(void);         // 新增：获取总内存

// 分页函数
void page_table_init(void);
page_entry_t* get_page_entry(u32 virtual_addr, bool create);
void map_page(u32 virtual_addr, u32 physical_addr, u32 flags);
u32 get_physical_addr(u32 virtual_addr);

// 页目录访问函数
page_entry_t* get_page_directory(void);

// 检查页帧是否已被分配
bool is_page_allocated(u32 page);

// 页面置换
void clock_init(u32 count);
bool clock_is_initialized(void);
u32 clock_replace(void);
void clock_set_ref_bit(u32 frame);
bool clock_add_frame(u32 frame, u32 virtual_addr);
void clock_remove_frame(u32 frame);
void clock_update_vaddr(u32 frame, u32 virtual_addr);
u32 clock_get_vaddr(u32 frame);
void clock_mark_accessed(u32 frame);
int clock_find_frame(u32 frame);
u32 clock_get_hand(void);
u32 clock_get_count(void);
void clock_get_state(u32* frames, u32* ref_bits, u32* hand, u32* vaddrs);

// 新增：位图分配器调试函数
void bitmap_print_status(void);

// 新增：内存检测函数
u32 detect_memory(void);

// LRU页面置换算法函数声明
void lru_init(u32 count);
bool lru_is_initialized(void);
u32 lru_replace(void);
void lru_access_page(u32 frame, u32 virtual_addr);
bool lru_add_frame(u32 frame, u32 virtual_addr);
void lru_remove_frame(u32 frame);
u32 lru_get_vaddr(u32 frame);
void lru_update_vaddr(u32 frame, u32 virtual_addr);
int lru_find_frame(u32 frame);
void lru_get_state(u32* frames, u32* vaddrs, u32* access_times);

// FIFO页面置换算法
#define FIFO_MAX_FRAMES 64

typedef struct {
    u32* frames;
    u32* vaddrs;
    u32* insert_order;
    u32 hand;
    u32 count;
    u32 max_count;
    u32 next_insert_order;
} fifo_replacer_t;

// FIFO页面置换算法函数声明
void fifo_init(u32 count);
bool fifo_is_initialized(void);
u32 fifo_replace(void);
bool fifo_add_frame(u32 frame, u32 virtual_addr);
void fifo_remove_frame(u32 frame);
u32 fifo_get_vaddr(u32 frame);
void fifo_update_vaddr(u32 frame, u32 virtual_addr);
int fifo_find_frame(u32 frame);
void fifo_get_state(u32* frames, u32* vaddrs, u32* orders);

#endif