#include "page.h"
#include "../lib/common.h"
#include "../lib/param.h"
#include "../kernel/console.h"

// 页目录和页表
static page_entry_t page_directory[1024] __attribute__((aligned(4096)));
static page_entry_t first_page_table[1024] __attribute__((aligned(4096)));

// 初始化分页机制
void page_table_init(void) {
    // 初始化第一个页表 (映射前4MB内存)
    for (int i = 0; i < 1024; i++) {
        first_page_table[i] = (i * PAGE_SIZE) | PAGE_PRESENT | PAGE_WRITE;
    }
    
    // 初始化页目录
    page_directory[0] = (u32)first_page_table | PAGE_PRESENT | PAGE_WRITE;
    
    // 其他页目录项初始化为不存在
    for (int i = 1; i < 1024; i++) {
        page_directory[i] = 0;  // 移除错误的PAGE_PRESENT标记
    }
    
    // 启用分页
    u32 cr3 = (u32)page_directory;
    asm volatile("mov %0, %%cr3" : : "r"(cr3));
    
    u32 cr0;
    asm volatile("mov %%cr0, %0" : "=r"(cr0));
    cr0 |= 0x80000000;
    asm volatile("mov %0, %%cr0" : : "r"(cr0));
    
    console_printf("分页机制初始化完成\n");
}

// 获取虚拟地址对应的页表项
page_entry_t* get_page_entry(u32 virtual_addr, bool create) {
    u32 dir_index = (virtual_addr >> 22) & 0x3FF;
    u32 table_index = (virtual_addr >> 12) & 0x3FF;
    
    page_entry_t* table = (page_entry_t*)(page_directory[dir_index] & 0xFFFFF000);
    
    // 如果页表不存在且需要创建
    if (!(page_directory[dir_index] & PAGE_PRESENT) && create) {
        u32 frame = alloc_page_frame();
        if (!frame) return NULL;
        
        page_directory[dir_index] = frame | PAGE_PRESENT | PAGE_WRITE;
        table = (page_entry_t*)frame;
        
        // 清空新页表
        for (int i = 0; i < 1024; i++) {
            table[i] = 0;
        }
    }
    
    return &table[table_index];
}

// 映射虚拟地址到物理地址
void map_page(u32 virtual_addr, u32 physical_addr, u32 flags) {
    page_entry_t* entry = get_page_entry(virtual_addr, true);
    if (entry) {
        *entry = physical_addr | flags | PAGE_PRESENT;
    }
}

// 获取虚拟地址对应的物理地址
u32 get_physical_addr(u32 virtual_addr) {
    page_entry_t* entry = get_page_entry(virtual_addr, false);
    if (!entry || !(*entry & PAGE_PRESENT)) {
        return 0; // 未映射
    }
    return (*entry & 0xFFFFF000) | (virtual_addr & 0xFFF);
}

// 获取页目录指针
page_entry_t* get_page_directory(void) {
    return page_directory;
}
