#include "bitmap.h"
#include "../lib/common.h"
#include "../lib/param.h"
#include "../kernel/console.h"
#include "../kernel/kernel.h"
#include "page.h"  // 添加这个头文件以获取页帧管理器

#define BITMAP_WORD_BITS 32

bitmap_allocator_t bm_allocator;

#define BITMAP_INDEX(page)  ((page) / BITMAP_WORD_BITS)
#define BITMAP_OFFSET(page) ((page) % BITMAP_WORD_BITS)
#define SET_BIT(page)       (bm_allocator.bitmap[BITMAP_INDEX(page)] |= (1 << BITMAP_OFFSET(page)))
#define CLEAR_BIT(page)     (bm_allocator.bitmap[BITMAP_INDEX(page)] &= ~(1 << BITMAP_OFFSET(page)))
#define TEST_BIT(page)      (bm_allocator.bitmap[BITMAP_INDEX(page)] & (1 << BITMAP_OFFSET(page)))

void bitmap_init(void) {
    u32 bitmap_words = (MAX_PAGE_COUNT + BITMAP_WORD_BITS - 1) / BITMAP_WORD_BITS;
    u32 bitmap_size = bitmap_words * sizeof(u32);
    
    // 重要：将位图放在更高的安全地址，避免与其他数据结构冲突
    // 0x200000 = 2MB位置，足够远离内核区域
    bm_allocator.bitmap = (u32*)0x200000;
    
    // 获取页帧管理器
    page_frame_manager_t* manager = get_page_frame_manager();
    if (manager == NULL) {
        console_printf("错误: 需要先初始化页帧管理器\n");
        return;
    }
    
    bm_allocator.reserved_pages = manager->reserved_frames;
    bm_allocator.total_pages = MAX_PAGE_COUNT;
    
    // ====== 关键修复：使用memset风格手动初始化 ======
    u32* bitmap = bm_allocator.bitmap;
    for (u32 i = 0; i < bitmap_words; i++) {
        bitmap[i] = 0xFFFFFFFF;  // 所有位初始化为1（空闲）
    }
    
    // 标记保留页为已使用（位为0）
    for (u32 i = 0; i < bm_allocator.reserved_pages; i++) {
        u32 word_index = i / BITMAP_WORD_BITS;
        u32 bit_offset = i % BITMAP_WORD_BITS;
        bitmap[word_index] &= ~(1 << bit_offset);  // 清除位
    }

    u32 errors = 0;
    
    // 检查前512个页
    for (u32 i = 0; i < 512 && i < bm_allocator.total_pages; i++) {
        u32 word_index = i / BITMAP_WORD_BITS;
        u32 bit_offset = i % BITMAP_WORD_BITS;
        bool is_set = (bitmap[word_index] & (1 << bit_offset)) != 0;
        
        if (i < bm_allocator.reserved_pages) {
            // 保留页应该为0（已使用）
            if (is_set) {
                console_printf("错误: 保留页%u未被正确标记\n", i);
                errors++;
                bitmap[word_index] &= ~(1 << bit_offset);  // 修复
            }
        } else {
            // 非保留页应该为1（空闲）
            if (!is_set) {
                console_printf("错误: 非保留页%u被错误标记\n", i);
                errors++;
                bitmap[word_index] |= (1 << bit_offset);  // 修复
            }
        }
    }
    
    bm_allocator.free_pages = bm_allocator.total_pages - bm_allocator.reserved_pages;
    bm_allocator.last_scan = bm_allocator.reserved_pages;
    
    console_printf("初始化完成\n");
}

u32 bitmap_alloc_page(void) {
    // 确保不从保留区域分配
    if (bm_allocator.last_scan < bm_allocator.reserved_pages) {
        bm_allocator.last_scan = bm_allocator.reserved_pages;
    }
    
    // 从last_scan开始向前搜索
    for (u32 page = bm_allocator.last_scan; page < bm_allocator.total_pages; page++) {
        if (TEST_BIT(page)) {
            CLEAR_BIT(page);
            bm_allocator.free_pages--;
            bm_allocator.last_scan = page;
            return page * PAGE_SIZE;
        }
    }
    
    // 如果后面没找到，从保留区域后开始搜索
    for (u32 page = bm_allocator.reserved_pages; page < bm_allocator.last_scan; page++) {
        if (TEST_BIT(page)) {
            CLEAR_BIT(page);
            bm_allocator.free_pages--;
            bm_allocator.last_scan = page;
            return page * PAGE_SIZE;
        }
    }
    
    return 0;
}

void bitmap_free_page(u32 addr) {
    u32 page = addr / PAGE_SIZE;
    
    if (page >= bm_allocator.total_pages) {
        console_printf("bitmap_free_page: 无效地址 0x%x\n", addr);
        return;
    }
    
    // 检查是否尝试释放保留页
    if (page < bm_allocator.reserved_pages) {
        console_printf("bitmap_free_page: 不能释放保留页 0x%x (页索引%u)\n", addr, page);
        return;
    }
    
    if (TEST_BIT(page) == 0) {  // 位为0表示正在使用
        SET_BIT(page);
        bm_allocator.free_pages++;
        
        // 如果释放的页比last_scan更靠前，更新last_scan
        if (page < bm_allocator.last_scan) {
            bm_allocator.last_scan = page;
        }
    } else {
        console_printf("bitmap_free_page: 页帧 0x%x 已经空闲\n", addr);
    }
}

void bitmap_print_status(void) {
    // 获取页帧管理器状态用于对比
    page_frame_manager_t* manager = get_page_frame_manager();
    
    console_printf("=== 位图分配器状态 ===\n");
    console_printf("总页数: %u\n", bm_allocator.total_pages);
    console_printf("空闲页: %u\n", bm_allocator.free_pages);
    
    // 计算使用页的正确方法
    u32 used_pages = bm_allocator.total_pages - bm_allocator.reserved_pages - bm_allocator.free_pages;
    console_printf("使用页: %u\n", used_pages);
    console_printf("保留页: %u\n", bm_allocator.reserved_pages);
    console_printf("最后扫描位置: %u\n", bm_allocator.last_scan);
    
    // 对比页帧管理器状态
    if (manager != NULL) {
        console_printf("\n=== 对比页帧管理器 ===\n");
        console_printf("页帧管理器: 总=%u, 空闲=%u, 使用=%u, 保留=%u\n",
                      manager->total_frames, manager->free_frames,
                      manager->used_frames, manager->reserved_frames);
        
        if (manager->reserved_frames != bm_allocator.reserved_pages) {
            console_printf("警告: 保留页数不一致 (页帧:%u vs 位图:%u)\n",
                          manager->reserved_frames, bm_allocator.reserved_pages);
        }
        
        if ((manager->total_frames - manager->reserved_frames - manager->free_frames) != used_pages) {
            console_printf("警告: 使用页数不一致\n");
        }
    }
    
    // 显示位图（前512位）
    console_printf("\n位图 (前512位, .=空闲, X=使用/保留, 每128位一行):\n");
    for (u32 i = 0; i < 512; i++) {
        if (i < bm_allocator.reserved_pages) {
            console_printf("X");  // 保留页始终显示为X
        } else {
            console_printf("%c", TEST_BIT(i) ? '.' : 'X');
        }
        
        if ((i + 1) % 128 == 0) console_printf("\n");
        else if ((i + 1) % 32 == 0) console_printf(" ");
    }
    
    // 显示前几个已分配页的具体位置
    console_printf("\n前10个已分配页帧位置:\n");
    u32 found = 0;
    for (u32 i = bm_allocator.reserved_pages; i < 512 && found < 10; i++) {
        if (TEST_BIT(i) == 0) {  // 位为0表示已分配
            console_printf("  页%u (地址:0x%x)\n", i, i * PAGE_SIZE);
            found++;
        }
    }
    if (found == 0) {
        console_printf("  无已分配页帧\n");
    }
}