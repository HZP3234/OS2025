// mm/memory.c
#include "page.h"
#include "../lib/common.h"
#include "../lib/param.h"
#include "../kernel/kernel.h"
#include "../kernel/console.h"
#include "bitmap.h"

static page_frame_manager_t frame_manager;

// 内存检测函数（使用 BIOS INT 15h E820 中断）
u32 detect_memory(void) {
    console_printf("正在检测物理内存...\n");

    u32 total_memory = PHYSICAL_MEMORY_SIZE; 
    if (total_memory < (4 * 1024 * 1024)) {  // 至少需要4MB
        console_printf("警告: 内存太小，设置为最小4MB\n");
        total_memory = 4 * 1024 * 1024;
    }
    
    console_printf("物理内存总量: %u MB\n", total_memory / 1024 / 1024); 
    return total_memory;
}

void page_frame_init(void) {
    u32 total_memory = detect_memory();
    frame_manager.total_frames = total_memory / PAGE_SIZE;

    // 获取内核结束地址
    extern char end;
    u32 kernel_end = (u32)&end;
    
    // 计算内核占用的页帧数（包括内核代码和数据）
    u32 kernel_frames = (kernel_end + PAGE_SIZE - 1) / PAGE_SIZE;
    
    // 计算页帧描述符占用的内存
    u32 frames_size = frame_manager.total_frames * sizeof(page_frame_t);
    u32 frames_addr = kernel_end + 0x1000;
    frames_addr = (frames_addr + 0xFFF) & 0xFFFFF000;
    
    // 计算页帧描述符占用的页帧数
    u32 frames_desc_frames = (frames_size + PAGE_SIZE - 1) / PAGE_SIZE;
    
    // 位图分配器占用的页帧数（从bitmap.c获取）
    u32 bitmap_frames = (MAX_PAGE_COUNT / 8 + PAGE_SIZE - 1) / PAGE_SIZE;
    
    // 总保留页帧数
    frame_manager.reserved_frames = kernel_frames + frames_desc_frames + bitmap_frames;
    
    // 确保至少保留一定数量的页帧
    if (frame_manager.reserved_frames < 256) {
        frame_manager.reserved_frames = 256; // 至少保留1MB
    }

    // 初始化所有页帧描述符
    for (u32 i = 0; i < frame_manager.total_frames; i++) {
        // 检查页帧是否属于内核保留区域
        if (i < frame_manager.reserved_frames) {
            // 内核保留页帧（包括页帧0、内核代码、页帧描述符、位图）
            frame_manager.frames[i].status = PAGE_RESERVED;
            frame_manager.frames[i].reference_count = 1;
            frame_manager.frames[i].flags = 0;
        } else {
            // 用户可用页帧
            frame_manager.frames[i].status = PAGE_FREE;
            frame_manager.frames[i].reference_count = 0;
            frame_manager.frames[i].flags = 0;
        }
    }

    // 计算可用空闲页帧数量
    frame_manager.free_frames = frame_manager.total_frames - frame_manager.reserved_frames;
    frame_manager.used_frames = 0;
    frame_manager.next_free_frame = frame_manager.reserved_frames; // 从保留区域后开始

    console_printf("总页帧数: %u\n", frame_manager.total_frames);
    console_printf("空闲页帧数: %u\n", frame_manager.free_frames);
    console_printf("保留页帧数: %u\n", frame_manager.reserved_frames);

    // 更新内核状态
    kernel_t* kernel = get_kernel_state();
    kernel->memory_size = total_memory;
    kernel->used_memory = frame_manager.reserved_frames * PAGE_SIZE;
    kernel->free_memory = frame_manager.free_frames * PAGE_SIZE;

    console_printf("物理内存管理器初始化完成\n");
}

// 分配一个页帧（真实物理内存）
u32 alloc_page_frame(void) {
    // 1. 查找空闲页帧
    u32 frame_index = 0xFFFFFFFF;
    
    // 从next_free_frame开始搜索，提高效率
    for (u32 i = frame_manager.next_free_frame; i < frame_manager.total_frames; i++) {
        if (frame_manager.frames[i].status == PAGE_FREE) {
            frame_index = i;
            frame_manager.next_free_frame = i + 1;
            break;
        }
    }
    
    // 如果后面没找到，从头搜索
    if (frame_index == 0xFFFFFFFF) {
        for (u32 i = 0; i < frame_manager.next_free_frame; i++) {
            if (frame_manager.frames[i].status == PAGE_FREE) {
                frame_index = i;
                frame_manager.next_free_frame = i + 1;
                break;
            }
        }
    }
    
    // 2. 如果没有空闲页帧，尝试页面置换
    if (frame_index == 0xFFFFFFFF) {
        console_printf("内存不足！尝试页面置换...\n");
        
        if (clock_is_initialized()) {
            u32 victim_frame = clock_replace();
            if (victim_frame != 0 && victim_frame != 0xFFFFFFFF) {
                // 找到牺牲页帧
                frame_index = victim_frame;
                
                // 标记为已使用
                frame_manager.frames[frame_index].status = PAGE_USED;
                frame_manager.frames[frame_index].reference_count = 1;
                
                // 更新位图
                CLEAR_BIT(frame_index);
                bm_allocator.free_pages--;
                
                // 更新统计信息
                frame_manager.free_frames--;
                frame_manager.used_frames++;
                
                // 计算物理地址
                u32 physical_addr = frame_index * PAGE_SIZE;
                
                // 更新内核状态
                kernel_t* kernel = get_kernel_state();
                kernel->used_memory += PAGE_SIZE;
                kernel->free_memory -= PAGE_SIZE;
                
                console_printf("页面置换成功: 置换页框 %u, 地址=0x%x\n", frame_index, physical_addr);
                
                return physical_addr;
            }
        }
        
        console_printf("内存分配失败！无法通过置换获取页帧\n");
        return 0;
    }
    
    // 3. 标记页帧为已使用
    frame_manager.frames[frame_index].status = PAGE_USED;
    frame_manager.frames[frame_index].reference_count = 1;
    
    // 4. 更新位图
    CLEAR_BIT(frame_index);
    bm_allocator.free_pages--;
    
    // 5. 更新统计信息
    frame_manager.free_frames--;
    frame_manager.used_frames++;
    
    // 6. 计算物理地址
    // 物理地址 = 页帧索引 * 页大小
    u32 physical_addr = frame_index * PAGE_SIZE;
    
    // 7. 更新内核状态
    kernel_t* kernel = get_kernel_state();
    kernel->used_memory += PAGE_SIZE;
    kernel->free_memory -= PAGE_SIZE;
    
    return physical_addr;
}

// 释放页帧
void free_page_frame(u32 frame) {
    u32 frame_index = frame / PAGE_SIZE;
    
    // 1. 验证参数
    if (frame_index >= frame_manager.total_frames) {
        console_printf("错误: 页帧索引 %u 超出范围\n", frame_index);
        return;
    }
    
    // 检查是否是保留页帧（新增）
    if (frame_index < frame_manager.reserved_frames) {
        console_printf("警告: 页帧 %u (地址 0x%x) 是内核保留页帧，不能释放\n", frame_index, frame);
        return;
    }
    
    if (frame_manager.frames[frame_index].status != PAGE_USED) {
        console_printf("错误: 页帧 %u 未在使用中\n", frame_index);
        return;
    }
    
    // 2. 同步 CLOCK 队列
    if (clock_is_initialized()) {
        clock_remove_frame(frame_index);
    }
    
    // 3. 减少引用计数
    frame_manager.frames[frame_index].reference_count--;
    
    // 4. 如果引用计数为0，释放页帧
    if (frame_manager.frames[frame_index].reference_count == 0) {
        frame_manager.frames[frame_index].status = PAGE_FREE;
        frame_manager.frames[frame_index].reference_count = 0;
        
        // 5. 更新位图
        bitmap_free_page(frame);
        
        // 6. 更新统计信息
        frame_manager.free_frames++;
        frame_manager.used_frames--;
        
        // 7. 更新next_free_frame（如果释放的帧更靠前）
        if (frame_index < frame_manager.next_free_frame) {
            frame_manager.next_free_frame = frame_index;
        }
        
        // 8. 更新内核状态
        kernel_t* kernel = get_kernel_state();
        kernel->used_memory -= PAGE_SIZE;
        kernel->free_memory += PAGE_SIZE;
        
        console_printf("释放页帧: 索引=%u, 地址=0x%x\n", frame_index, frame);
    } else {
        console_printf("页帧 %u 引用计数减少到 %u\n", 
                      frame_index, frame_manager.frames[frame_index].reference_count);
    }
}

// 获取页帧管理器
page_frame_manager_t* get_page_frame_manager(void) {
    return &frame_manager;
}

// 检查页帧是否已被分配
bool is_page_allocated(u32 page) {
    if (page < frame_manager.total_frames) {
        return frame_manager.frames[page].status == PAGE_USED;
    }
    return false;
}

// 获取总内存大小
u32 get_total_memory(void) {
    return frame_manager.total_frames * PAGE_SIZE;
}