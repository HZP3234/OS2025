#include "page.h"
#include "../lib/common.h"
#include "../kernel/console.h"
#include "../lib/param.h"

#define FIFO_MAX_FRAMES 64

// FIFO算法置换器结构体
static fifo_replacer_t fifo;
// 标记FIFO算法是否已初始化
static bool fifo_initialized = false;
// 存储物理帧号的数组，最大支持64个帧
static u32 fifo_frames_storage[FIFO_MAX_FRAMES];
// 存储虚拟地址的数组
static u32 fifo_vaddrs_storage[FIFO_MAX_FRAMES];
// 存储插入顺序的数组，用于FIFO算法确定淘汰顺序
static u32 fifo_insert_order_storage[FIFO_MAX_FRAMES];

/**
 * @brief 初始化FIFO页面置换算法
 * @param count 期望的帧数量
 * 
 * FIFO（First In First Out）算法是最简单的页面置换算法之一，
 * 它总是淘汰最先进入内存的页面。该算法实现了一个队列结构，
 * 新页面加入到队尾，置换时从队首移除页面。
 */
void fifo_init(u32 count) {
    u32 max_frames = PAGE_SIZE / sizeof(page_frame_t);
    fifo.max_count = count;
    
    // 限制帧数量不超过最大值和页面大小限制
    if (fifo.max_count > FIFO_MAX_FRAMES) {
        fifo.max_count = FIFO_MAX_FRAMES;
    }
    if (fifo.max_count > max_frames) {
        fifo.max_count = max_frames;
    }

    // 初始化FIFO算法的各个组件
    fifo.hand = 0;  // 当前处理位置（类似于队列指针）
    fifo.count = 0;  // 当前已使用的帧数量
    fifo.frames = fifo_frames_storage;  // 指向帧存储数组
    fifo.vaddrs = fifo_vaddrs_storage;  // 指向虚拟地址数组
    fifo.insert_order = fifo_insert_order_storage;  // 指向插入顺序数组

    // 初始化所有槽位为空
    for (u32 i = 0; i < FIFO_MAX_FRAMES; i++) {
        fifo.frames[i] = 0xFFFFFFFF;  // 0xFFFFFFFF表示空槽位
        fifo.vaddrs[i] = 0;
        fifo.insert_order[i] = 0;
    }

    fifo.next_insert_order = 0;  // 下一个插入操作的顺序号
    fifo_initialized = true;
}

/**
 * @brief 检查FIFO算法是否已初始化
 * @return true 如果已初始化，false 如果未初始化
 */
bool fifo_is_initialized(void) {
    return fifo_initialized;
}

/**
 * @brief 执行FIFO页面置换算法，选择一个页面进行置换
 * @return 被置换出的物理帧号，如果没有可置换的页面则返回0
 * 
 * FIFO算法的置换策略：
 * 1. 查找插入顺序号最小的页面（最先进入内存的页面）
 * 2. 将该页面置换出去
 * 3. 返回被置换页面的物理帧号
 */
u32 fifo_replace(void) {
    if (!fifo_initialized || fifo.count == 0) {
        return 0;
    }

    // 查找插入顺序最早的页面（FIFO的核心思想）
    u32 oldest_order = 0xFFFFFFFF;  // 最小的插入顺序号
    u32 victim_index = 0;  // 受害页面的索引

    for (u32 i = 0; i < fifo.max_count; i++) {
        if (fifo.frames[i] != 0xFFFFFFFF) {  // 检查槽位是否被占用
            if (fifo.insert_order[i] < oldest_order) {
                oldest_order = fifo.insert_order[i];
                victim_index = i;
            }
        }
    }

    // 移除找到的最早页面
    u32 victim_frame = fifo.frames[victim_index];
    u32 victim_vaddr = fifo.vaddrs[victim_index];

    // 清空该槽位
    fifo.frames[victim_index] = 0xFFFFFFFF;
    fifo.vaddrs[victim_index] = 0;
    fifo.insert_order[victim_index] = 0;
    fifo.count--;  // 减少已使用帧计数

    return victim_frame;
}

/**
 * @brief 添加一个新的页面帧到FIFO算法中
 * @param frame 物理帧号
 * @param virtual_addr 对应的虚拟地址
 * @return true 如果添加成功，false 如果没有可用槽位
 * 
 * 新添加的页面会被分配一个递增的插入顺序号，
 * 这个顺序号用于在FIFO置换时确定哪个页面应该被优先淘汰。
 */
bool fifo_add_frame(u32 frame, u32 virtual_addr) {
    if (!fifo_initialized) {
        return false;
    }

    // 查找空的槽位
    for (u32 i = 0; i < fifo.max_count; i++) {
        if (fifo.frames[i] == 0xFFFFFFFF) {
            fifo.frames[i] = frame;
            fifo.vaddrs[i] = virtual_addr;
            fifo.insert_order[i] = fifo.next_insert_order++;  // 分配插入顺序号
            fifo.count++;  // 增加已使用帧计数
            return true;
        }
    }

    return false;  // 没有可用槽位
}

/**
 * @brief 从FIFO算法中移除指定的页面帧
 * @param frame 要移除的物理帧号
 * 
 * 通常在页面被交换到磁盘或其他存储设备时调用此函数。
 * 移除操作不会影响其他页面的插入顺序。
 */
void fifo_remove_frame(u32 frame) {
    if (!fifo_initialized) {
        return;
    }

    // 查找并移除指定的帧
    for (u32 i = 0; i < fifo.max_count; i++) {
        if (fifo.frames[i] == frame) {
            fifo.frames[i] = 0xFFFFFFFF;
            fifo.vaddrs[i] = 0;
            fifo.insert_order[i] = 0;  // 重置插入顺序
            fifo.count--;  // 减少已使用帧计数
            return;
        }
    }
}

/**
 * @brief 获取指定帧对应的虚拟地址
 * @param frame 物理帧号
 * @return 对应的虚拟地址，如果帧不存在则返回0
 */
u32 fifo_get_vaddr(u32 frame) {
    if (!fifo_initialized) {
        return 0;
    }

    // 查找指定帧对应的虚拟地址
    for (u32 i = 0; i < fifo.max_count; i++) {
        if (fifo.frames[i] == frame) {
            return fifo.vaddrs[i];
        }
    }

    return 0;
}

/**
 * @brief 更新指定帧对应的虚拟地址
 * @param frame 物理帧号
 * @param virtual_addr 新的虚拟地址
 * 
 * 当页面的虚拟地址发生变化时（如页面移动）调用此函数。
 * 注意：此操作不会影响FIFO的置换顺序。
 */
void fifo_update_vaddr(u32 frame, u32 virtual_addr) {
    if (!fifo_initialized) {
        return;
    }

    // 更新指定帧的虚拟地址
    for (u32 i = 0; i < fifo.max_count; i++) {
        if (fifo.frames[i] == frame) {
            fifo.vaddrs[i] = virtual_addr;
            return;
        }
    }
}

/**
 * @brief 查找指定帧在FIFO数组中的位置
 * @param frame 要查找的物理帧号
 * @return 帧在数组中的索引，如果不存在则返回-1
 */
int fifo_find_frame(u32 frame) {
    if (!fifo_initialized) {
        return -1;
    }

    // 查找指定帧的位置
    for (u32 i = 0; i < fifo.max_count; i++) {
        if (fifo.frames[i] == frame) {
            return i;
        }
    }

    return -1;
}

/**
 * @brief 获取FIFO算法的当前状态
 * @param frames 用于存储帧号的数组
 * @param vaddrs 用于存储虚拟地址的数组
 * @param orders 用于存储插入顺序的数组
 * 
 * 此函数主要用于调试和状态监控，可以查看当前FIFO队列中
 * 所有页面的状态和它们的插入顺序。
 */
void fifo_get_state(u32* frames, u32* vaddrs, u32* orders) {
    if (!fifo_initialized) {
        return;
    }

    // 复制所有状态信息到输出数组
    for (u32 i = 0; i < fifo.max_count; i++) {
        frames[i] = fifo.frames[i];
        vaddrs[i] = fifo.vaddrs[i];
        orders[i] = fifo.insert_order[i];
    }
}
