#ifndef __BITMAP_H
#define __BITMAP_H

#include "../lib/common.h"

#define BITMAP_WORD_BITS 32

typedef struct {
    u32* bitmap;
    u32 total_pages;
    u32 free_pages;
    u32 last_scan;
    u32 reserved_pages;
} bitmap_allocator_t;

extern bitmap_allocator_t bm_allocator;

#define BITMAP_INDEX(page)  ((page) / BITMAP_WORD_BITS)
#define BITMAP_OFFSET(page) ((page) % BITMAP_WORD_BITS)
#define SET_BIT(page)       (bm_allocator.bitmap[BITMAP_INDEX(page)] |= (1 << BITMAP_OFFSET(page)))
#define CLEAR_BIT(page)     (bm_allocator.bitmap[BITMAP_INDEX(page)] &= ~(1 << BITMAP_OFFSET(page)))
#define TEST_BIT(page)      (bm_allocator.bitmap[BITMAP_INDEX(page)] & (1 << BITMAP_OFFSET(page)))

void bitmap_init(void);
u32 bitmap_alloc_page(void);
void bitmap_free_page(u32 addr);
void bitmap_print_status(void);

#endif
