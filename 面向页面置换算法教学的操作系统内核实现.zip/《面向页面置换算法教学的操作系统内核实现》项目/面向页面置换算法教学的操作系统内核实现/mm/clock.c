#include "page.h"
#include "../lib/common.h"
#include "../kernel/console.h"
#include "../lib/param.h"

#define CLOCK_MAX_FRAMES 64

// Clock算法置换器结构体
static clock_replacer_t clock;
// 标记Clock算法是否已初始化
static bool clock_initialized = false;
// 存储物理帧号的数组，最大支持64个帧
static u32 clock_frames_storage[CLOCK_MAX_FRAMES];
// 存储引用位（Reference Bit）的数组，用于Clock算法
static u32 clock_ref_bits_storage[CLOCK_MAX_FRAMES];
// 存储虚拟地址的数组
static u32 clock_vaddrs_storage[CLOCK_MAX_FRAMES];

/**
 * @brief 初始化Clock页面置换算法
 * @param count 期望的帧数量
 * 
 * Clock算法是一种改进的页面置换算法，它使用一个循环指针（时钟手）
 * 和引用位来决定哪个页面应该被置换出去。
 */
void clock_init(u32 count) {
    u32 max_frames = PAGE_SIZE / sizeof(page_frame_t);
    clock.count = count;
    
    // 限制帧数量不超过最大值和页面大小限制
    if (clock.count > CLOCK_MAX_FRAMES) {
        clock.count = CLOCK_MAX_FRAMES;
    }
    if (clock.count > max_frames) {
        clock.count = max_frames;
    }

    // 初始化Clock算法的各个组件
    clock.hand = 0;  // 时钟手，从位置0开始
    clock.frames = clock_frames_storage;  // 指向帧存储数组
    clock.ref_bits = clock_ref_bits_storage;  // 指向引用位数组
    clock.vaddrs = clock_vaddrs_storage;  // 指向虚拟地址数组

    // 清空所有帧槽位，0xFFFFFFFF表示空槽位
    for (u32 i = 0; i < CLOCK_MAX_FRAMES; i++) {
        clock.frames[i] = 0xFFFFFFFF;
        clock.ref_bits[i] = 0;  // 初始时所有引用位都为0
        clock.vaddrs[i] = 0;
    }

    clock_initialized = true;
}

/**
 * @brief 检查Clock算法是否已初始化
 * @return true 如果已初始化，false 如果未初始化
 */
bool clock_is_initialized(void) {
    return clock_initialized;
}

/**
 * @brief 执行Clock页面置换算法，选择一个页面进行置换
 * @return 被置换出的物理帧号，如果没有可置换的页面则返回0
 * 
 * Clock算法的工作原理：
 * 1. 使用一个循环指针（时钟手）扫描所有页面
 * 2. 如果遇到引用位为0的页面，则将其置换出去
 * 3. 如果遇到引用位为1的页面，则将其清0并继续扫描
 * 4. 最多扫描两轮，确保能找到合适的置换页面
 */
u32 clock_replace(void) {
    if (!clock_initialized || clock.count == 0) {
        return 0;
    }

    u32 start_hand = clock.hand;  // 记录起始位置，用于检测完整循环
    u32 scans = 0;  // 扫描计数器

    // 第一轮扫描：查找引用位为0的页面
    while (scans < clock.count * 2) {
        u32 current = clock.hand;

        if (clock.frames[current] != 0xFFFFFFFF) {  // 检查是否有页面占用
            if (clock.ref_bits[current] == 0) {
                // 找到引用位为0的页面，进行置换
                u32 victim_frame = clock.frames[current];
                u32 victim_vaddr = clock.vaddrs[current];

                // 清除该槽位的信息
                clock.frames[current] = 0xFFFFFFFF;
                clock.vaddrs[current] = 0;
                clock.ref_bits[current] = 0;
                clock.hand = (current + 1) % clock.count;  // 时钟手前进

                return victim_frame;
            } else {
                // 引用位为1，将其清0并继续扫描
                clock.ref_bits[current] = 0;
            }
        }

        // 时钟手前进到下一个位置
        clock.hand = (current + 1) % clock.count;
        scans++;

        // 如果时钟手回到起始位置，说明已经完成一轮扫描
        if (clock.hand == start_hand) {
            break;
        }
    }

    // 第二轮扫描：查找引用位为0的页面（如果第一轮没找到）
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] != 0xFFFFFFFF && clock.ref_bits[i] == 0) {
            u32 victim_frame = clock.frames[i];
            clock.frames[i] = 0xFFFFFFFF;
            clock.vaddrs[i] = 0;
            clock.ref_bits[i] = 0;
            clock.hand = (i + 1) % clock.count;
            return victim_frame;
        }
    }

    // 第三轮扫描：置换任意一个页面（如果前两轮都没找到）
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] != 0xFFFFFFFF) {
            u32 victim_frame = clock.frames[i];
            clock.frames[i] = 0xFFFFFFFF;
            clock.vaddrs[i] = 0;
            clock.ref_bits[i] = 0;
            clock.hand = (i + 1) % clock.count;
            return victim_frame;
        }
    }

    return 0;  // 没有可置换的页面
}

/**
 * @brief 设置指定帧的引用位
 * @param frame 物理帧号
 * 
 * 当页面被访问时，调用此函数将对应的引用位设置为1，
 * 表示该页面最近被访问过。
 */
void clock_set_ref_bit(u32 frame) {
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] == frame) {
            clock.ref_bits[i] = 1;
            return;
        }
    }
}

/**
 * @brief 添加一个新的页面帧到Clock算法中
 * @param frame 物理帧号
 * @param virtual_addr 对应的虚拟地址
 * @return true 如果添加成功，false 如果没有可用槽位
 * 
 * 新添加的页面会被设置为已访问状态（引用位为1），
 * 这是因为新加载的页面通常会被立即访问。
 */
bool clock_add_frame(u32 frame, u32 virtual_addr) {
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] == 0xFFFFFFFF) {
            clock.frames[i] = frame;
            clock.vaddrs[i] = virtual_addr;
            clock.ref_bits[i] = 1;  // 新页面设置为已访问
            return true;
        }
    }
    return false;
}

/**
 * @brief 从Clock算法中移除指定的页面帧
 * @param frame 要移除的物理帧号
 * 
 * 通常在页面被交换到磁盘或其他存储设备时调用此函数。
 */
void clock_remove_frame(u32 frame) {
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] == frame) {
            clock.frames[i] = 0xFFFFFFFF;
            clock.vaddrs[i] = 0;
            clock.ref_bits[i] = 0;
            return;
        }
    }
}

/**
 * @brief 更新指定帧对应的虚拟地址
 * @param frame 物理帧号
 * @param virtual_addr 新的虚拟地址
 * 
 * 当页面的虚拟地址发生变化时（如页面移动）调用此函数。
 */
void clock_update_vaddr(u32 frame, u32 virtual_addr) {
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] == frame) {
            clock.vaddrs[i] = virtual_addr;
            return;
        }
    }
}

/**
 * @brief 获取指定帧对应的虚拟地址
 * @param frame 物理帧号
 * @return 对应的虚拟地址，如果帧不存在则返回0
 */
u32 clock_get_vaddr(u32 frame) {
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] == frame) {
            return clock.vaddrs[i];
        }
    }
    return 0;
}

/**
 * @brief 标记页面为已访问状态
 * @param frame 被访问的物理帧号
 * 
 * 这是clock_set_ref_bit函数的包装，主要用于表示页面访问事件。
 */
void clock_mark_accessed(u32 frame) {
    clock_set_ref_bit(frame);
}

/**
 * @brief 查找指定帧在Clock数组中的位置
 * @param frame 要查找的物理帧号
 * @return 帧在数组中的索引，如果不存在则返回-1
 */
int clock_find_frame(u32 frame) {
    for (u32 i = 0; i < clock.count; i++) {
        if (clock.frames[i] == frame) {
            return i;
        }
    }
    return -1;
}

/**
 * @brief 获取当前时钟手的位置
 * @return 当前时钟手指向的位置
 */
u32 clock_get_hand(void) {
    return clock.hand;
}

/**
 * @brief 获取当前管理的帧数量
 * @return 当前帧数量
 */
u32 clock_get_count(void) {
    return clock.count;
}

/**
 * @brief 获取Clock算法的当前状态
 * @param frames 用于存储帧号的数组
 * @param ref_bits 用于存储引用位的数组
 * @param hand 用于存储时钟手位置的变量
 * @param vaddrs 用于存储虚拟地址的数组
 * 
 * 此函数主要用于调试和状态监控。
 */
void clock_get_state(u32* frames, u32* ref_bits, u32* hand, u32* vaddrs) {
    for (u32 i = 0; i < clock.count; i++) {
        frames[i] = clock.frames[i];
        ref_bits[i] = clock.ref_bits[i];
        vaddrs[i] = clock.vaddrs[i];
    }
    *hand = clock.hand;
}