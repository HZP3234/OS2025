#ifndef __VMM_H__
#define __VMM_H__

#include "../lib/common.h"

#define SWAP_SPACE_SIZE 64
#define PAGE_SIZE 4096

typedef struct {
    u32 page_faults;
    u32 page_replacements;
    u32 hits;
    u32 swap_writes;
    u32 swap_reads;
} vmm_stats_t;

typedef struct {
    bool in_swap;
    u32 swap_page;
    u32 virtual_addr;
    bool dirty;
} swap_entry_t;

typedef struct {
    swap_entry_t entries[SWAP_SPACE_SIZE];
    u32 next_swap_page;
} swap_space_t;

typedef struct {
    u32 frame;
    u32 virtual_addr;
    bool in_use;
} page_cache_t;

void vmm_init(void);
bool vmm_is_initialized(void);
void vmm_get_stats(vmm_stats_t* stats);

void vmm_page_fault_handler(u32 fault_addr, u32 error_code);

u32 handle_page_fault(u32 fault_addr, bool page_not_present, bool is_write, bool is_user);

u32 find_free_frame(void);
u32 perform_page_replacement(u32 fault_addr, bool is_write, bool is_user);
u32 find_victim_virtual_page(u32 frame);

u32 allocate_swap_page(void);
u32 find_swap_entry(u32 virtual_addr);
void update_swap_entry(u32 idx, u32 virtual_addr, bool dirty);

void swap_out_page(u32 virtual_addr, u32 physical_addr);
void swap_in_page(u32 virtual_addr, u32 physical_addr);

void invalidate_tlb(u32 virtual_addr);
void flush_tlb(void);

void set_page_accessed(u32 virtual_addr);
void set_page_dirty(u32 virtual_addr);
bool is_page_accessed(u32 virtual_addr);
bool is_page_dirty(u32 virtual_addr);

void map_page_with_swap(u32 virtual_addr, u32 swap_page);
bool get_swap_info(u32 virtual_addr, u32* swap_page);

void vmm_on_page_access(u32 virtual_addr);
void vmm_on_page_write(u32 virtual_addr);

void vmm_init_lru(u32 frame_count);
void vmm_use_lru(bool enable);
bool vmm_is_using_lru(void);

#endif
