#include "page.h"
#include "../lib/common.h"
#include "../kernel/console.h"
#include "../lib/param.h"

#define LRU_MAX_FRAMES 64

// LRU算法置换器结构体
static lru_replacer_t lru;
// 标记LRU算法是否已初始化
static bool lru_initialized = false;
// 存储物理帧号的数组，最大支持64个帧
static u32 lru_frames_storage[LRU_MAX_FRAMES];
// 存储虚拟地址的数组
static u32 lru_vaddrs_storage[LRU_MAX_FRAMES];
// 存储访问时间戳的数组，用于LRU算法确定淘汰顺序
static u32 lru_access_times_storage[LRU_MAX_FRAMES];
// 全局时间计数器，用于记录页面访问顺序
static u32 current_time = 0;

/**
 * @brief 初始化LRU页面置换算法
 * @param count 期望的帧数量
 * 
 * LRU（Least Recently Used）算法是一种基于程序局部性原理的页面置换算法，
 * 它选择最近最少使用的页面进行置换。该算法维护每个页面的最后访问时间，
 * 置换时选择访问时间最早的页面。
 */
void lru_init(u32 count) {
    u32 max_frames = PAGE_SIZE / sizeof(page_frame_t);
    lru.max_count = count;
    
    // 限制帧数量不超过最大值和页面大小限制
    if (lru.max_count > LRU_MAX_FRAMES) {
        lru.max_count = LRU_MAX_FRAMES;
    }
    if (lru.max_count > max_frames) {
        lru.max_count = max_frames;
    }

    // 初始化LRU算法的各个组件
    lru.hand = 0;  // 当前处理位置（类似于循环指针）
    lru.count = 0;  // 当前已使用的帧数量
    lru.entries = (lru_entry_t*)lru_frames_storage;  // 指向帧存储数组
    lru.access_order = lru_access_times_storage;  // 指向访问时间数组

    // 初始化所有槽位为空
    for (u32 i = 0; i < LRU_MAX_FRAMES; i++) {
        lru_frames_storage[i] = 0xFFFFFFFF;  // 0xFFFFFFFF表示空槽位
        lru_vaddrs_storage[i] = 0;
        lru_access_times_storage[i] = 0;  // 初始访问时间为0
    }

    current_time = 0;  // 初始化全局时间计数器
    lru_initialized = true;
}

/**
 * @brief 检查LRU算法是否已初始化
 * @return true 如果已初始化，false 如果未初始化
 */
bool lru_is_initialized(void) {
    return lru_initialized;
}

/**
 * @brief 执行LRU页面置换算法，选择一个页面进行置换
 * @return 被置换出的物理帧号，如果没有可置换的页面则返回0
 * 
 * LRU算法的置换策略：
 * 1. 扫描所有已占用的页面，查找访问时间最早的页面
 * 2. 将该页面置换出去（因为它是最近最少使用的）
 * 3. 返回被置换页面的物理帧号
 */
u32 lru_replace(void) {
    if (!lru_initialized || lru.count == 0) {
        return 0;
    }

    // 查找访问时间最早的页面（LRU的核心思想）
    u32 oldest_time = 0xFFFFFFFF;  // 最早的访问时间戳
    u32 victim_index = 0;  // 受害页面的索引

    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] != 0xFFFFFFFF) {  // 检查槽位是否被占用
            if (lru_access_times_storage[i] < oldest_time) {
                oldest_time = lru_access_times_storage[i];
                victim_index = i;
            }
        }
    }

    // 移除找到的最早访问页面
    u32 victim_frame = lru_frames_storage[victim_index];
    u32 victim_vaddr = lru_vaddrs_storage[victim_index];

    // 清空该槽位
    lru_frames_storage[victim_index] = 0xFFFFFFFF;
    lru_vaddrs_storage[victim_index] = 0;
    lru_access_times_storage[victim_index] = 0;
    lru.count--;  // 减少已使用帧计数

    return victim_frame;
}

/**
 * @brief 记录页面访问事件，更新访问时间戳
 * @param frame 被访问的物理帧号
 * @param virtual_addr 对应的虚拟地址（参数保留，用于接口兼容性）
 * 
 * 当页面被访问时，调用此函数更新该页面的访问时间戳。
 * LRU算法会基于这个时间戳来决定哪个页面应该被置换。
 */
void lru_access_page(u32 frame, u32 virtual_addr) {
    if (!lru_initialized) {
        return;
    }

    // 查找指定的帧并更新其访问时间戳
    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] == frame) {
            lru_access_times_storage[i] = current_time++;  // 更新时间戳并递增全局时间
            return;
        }
    }
}

/**
 * @brief 添加一个新的页面帧到LRU算法中
 * @param frame 物理帧号
 * @param virtual_addr 对应的虚拟地址
 * @return true 如果添加成功，false 如果没有可用槽位
 * 
 * 新添加的页面会被分配当前时间戳作为访问时间，
 * 表示这个页面刚刚被加载（相当于被访问了一次）。
 */
bool lru_add_frame(u32 frame, u32 virtual_addr) {
    if (!lru_initialized) {
        return false;
    }

    // 查找空的槽位
    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] == 0xFFFFFFFF) {
            lru_frames_storage[i] = frame;
            lru_vaddrs_storage[i] = virtual_addr;
            lru_access_times_storage[i] = current_time++;  // 分配当前时间戳
            lru.count++;  // 增加已使用帧计数
            return true;
        }
    }

    return false;  // 没有可用槽位
}

/**
 * @brief 从LRU算法中移除指定的页面帧
 * @param frame 要移除的物理帧号
 * 
 * 通常在页面被交换到磁盘或其他存储设备时调用此函数。
 * 移除操作不会影响其他页面的访问时间戳。
 */
void lru_remove_frame(u32 frame) {
    if (!lru_initialized) {
        return;
    }

    // 查找并移除指定的帧
    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] == frame) {
            lru_frames_storage[i] = 0xFFFFFFFF;
            lru_vaddrs_storage[i] = 0;
            lru_access_times_storage[i] = 0;  // 重置访问时间
            lru.count--;  // 减少已使用帧计数
            return;
        }
    }
}

/**
 * @brief 获取指定帧对应的虚拟地址
 * @param frame 物理帧号
 * @return 对应的虚拟地址，如果帧不存在则返回0
 */
u32 lru_get_vaddr(u32 frame) {
    if (!lru_initialized) {
        return 0;
    }

    // 查找指定帧对应的虚拟地址
    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] == frame) {
            return lru_vaddrs_storage[i];
        }
    }

    return 0;
}

/**
 * @brief 更新指定帧对应的虚拟地址
 * @param frame 物理帧号
 * @param virtual_addr 新的虚拟地址
 * 
 * 当页面的虚拟地址发生变化时（如页面移动）调用此函数。
 * 注意：此操作不会影响LRU的置换顺序，因为访问时间戳保持不变。
 */
void lru_update_vaddr(u32 frame, u32 virtual_addr) {
    if (!lru_initialized) {
        return;
    }

    // 更新指定帧的虚拟地址
    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] == frame) {
            lru_vaddrs_storage[i] = virtual_addr;
            return;
        }
    }
}

/**
 * @brief 查找指定帧在LRU数组中的位置
 * @param frame 要查找的物理帧号
 * @return 帧在数组中的索引，如果不存在则返回-1
 */
int lru_find_frame(u32 frame) {
    if (!lru_initialized) {
        return -1;
    }

    // 查找指定帧的位置
    for (u32 i = 0; i < lru.max_count; i++) {
        if (lru_frames_storage[i] == frame) {
            return i;
        }
    }

    return -1;
}

/**
 * @brief 获取LRU算法的当前状态
 * @param frames 用于存储帧号的数组
 * @param vaddrs 用于存储虚拟地址的数组
 * @param access_times 用于存储访问时间戳的数组
 * 
 * 此函数主要用于调试和状态监控，可以查看当前LRU列表中
 * 所有页面的状态和它们的访问时间戳（用于确定LRU顺序）。
 */
void lru_get_state(u32* frames, u32* vaddrs, u32* access_times) {
    if (!lru_initialized) {
        return;
    }

    // 复制所有状态信息到输出数组
    for (u32 i = 0; i < lru.max_count; i++) {
        frames[i] = lru_frames_storage[i];
        vaddrs[i] = lru_vaddrs_storage[i];
        access_times[i] = lru_access_times_storage[i];
    }
}
