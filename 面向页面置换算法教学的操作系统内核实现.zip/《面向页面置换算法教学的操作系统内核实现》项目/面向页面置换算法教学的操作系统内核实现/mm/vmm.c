#include "vmm.h"
#include "page.h"
#include "../lib/common.h"
#include "../lib/param.h"
#include "../kernel/console.h"
#include "../kernel/kernel.h"
#include "bitmap.h"

#define VMM_DEBUG 1

static vmm_stats_t vmm_stats;
static swap_space_t swap_space;
static u32 vmm_initialized = false;
static u32 clock_initialized_in_vmm = false;
static u32 lru_initialized_in_vmm = false;
static u32 use_lru = false;

void vmm_init(void) {
    if (vmm_initialized) {
        return;
    }
    
    vmm_stats.page_faults = 0;
    vmm_stats.page_replacements = 0;
    vmm_stats.hits = 0;
    vmm_stats.swap_writes = 0;
    vmm_stats.swap_reads = 0;

    swap_space.next_swap_page = 0;

    for (u32 i = 0; i < SWAP_SPACE_SIZE; i++) {
        swap_space.entries[i].in_swap = false;
        swap_space.entries[i].swap_page = 0;
        swap_space.entries[i].virtual_addr = 0;
        swap_space.entries[i].dirty = false;
    }

    vmm_initialized = true;
    console_printf("虚拟内存管理器初始化完成\n");
    console_printf("  支持的最大交换页数: %d\n", SWAP_SPACE_SIZE);
}

void vmm_init_lru(u32 frame_count) {
    if (lru_initialized_in_vmm) {
        return;
    }
    lru_init(frame_count);
    lru_initialized_in_vmm = true;
    console_printf("LRU页面置换算法初始化完成，最大帧数: %u\n", frame_count);
}

void vmm_use_lru(bool enable) {
    use_lru = enable;
}

bool vmm_is_using_lru(void) {
    return use_lru;
}

bool vmm_is_initialized(void) {
    return vmm_initialized;
}

void vmm_get_stats(vmm_stats_t* stats) {
    stats->page_faults = vmm_stats.page_faults;
    stats->page_replacements = vmm_stats.page_replacements;
    stats->hits = vmm_stats.hits;
    stats->swap_writes = vmm_stats.swap_writes;
    stats->swap_reads = vmm_stats.swap_reads;
}

void vmm_page_fault_handler(u32 fault_addr, u32 error_code) {
    vmm_stats.page_faults++;

#if VMM_DEBUG
    console_printf("\n=== 页错误异常 ===\n");
    console_printf("错误地址: 0x%x\n", fault_addr);
#endif

    bool present = !(error_code & 0x01);
    bool write = error_code & 0x02;
    bool user = error_code & 0x04;
    bool reserved = error_code & 0x08;

    if (reserved) {
        console_printf("错误: 保留位违反\n");
        return;
    }

    if (user && (fault_addr >= KERNEL_BASE)) {
        console_printf("错误: 用户态访问内核空间\n");
        return;
    }

    u32 page_dir = fault_addr >> 22;
    u32 page_table = (fault_addr >> 12) & 0x3FF;

#if VMM_DEBUG
    console_printf("页目录索引: %u, 页表索引: %u\n", page_dir, page_table);
    if (present) {
        console_printf("原因: 页面不存在 (Present=0)\n");
    } else {
        console_printf("原因: 页保护违反 (Present=1)\n");
    }
    console_printf("操作: %s\n", write ? "写" : "读");
    console_printf("模式: %s\n", user ? "用户态" : "内核态");
#endif

    page_entry_t* pte = get_page_entry(fault_addr, false);

    if (pte && (*pte & PAGE_PRESENT)) {
#if VMM_DEBUG
        console_printf("页已存在但受保护，跳过处理\n");
#endif
        return;
    }

    u32 new_frame = handle_page_fault(fault_addr, present, write, user);

    if (new_frame) {
#if VMM_DEBUG
        console_printf("成功分配页框: 0x%x\n", new_frame);
#endif
        vmm_stats.hits++;
    } else {
#if VMM_DEBUG
        console_printf("警告: 页面置换发生\n");
#endif
    }

#if VMM_DEBUG
    console_printf("===================\n\n");
#endif
}

u32 handle_page_fault(u32 fault_addr, bool page_not_present, bool is_write, bool is_user) {
    u32 aligned_addr = fault_addr & 0xFFFFF000;

    u32 frame = find_free_frame();
    if (!frame) {
        frame = perform_page_replacement(fault_addr, is_write, is_user);
        if (!frame) {
            console_printf("严重错误: 页面置换失败\n");
            return 0;
        }
        vmm_stats.page_replacements++;
    } else {
        if (use_lru && lru_is_initialized()) {
            lru_add_frame(frame >> 12, aligned_addr);
        } else if (clock_is_initialized() && clock_initialized_in_vmm) {
            clock_add_frame(frame >> 12, aligned_addr);
        }
    }

    page_entry_t* pte = get_page_entry(aligned_addr, true);
    if (!pte) {
        console_printf("错误: 无法获取页表项\n");
        free_page_frame(frame);
        return 0;
    }

    u32 flags = PAGE_PRESENT | PAGE_USER;
    if (is_write) {
        flags |= PAGE_WRITE | PAGE_DIRTY;
    }

    *pte = frame | flags;

    if (use_lru && lru_is_initialized()) {
        lru_access_page(frame >> 12, aligned_addr);
    } else if (clock_is_initialized() && clock_initialized_in_vmm) {
        clock_set_ref_bit(frame >> 12);
    }

    invalidate_tlb(aligned_addr);

    return frame;
}

u32 find_free_frame(void) {
    page_frame_manager_t* fm = get_page_frame_manager();

    for (u32 i = 0; i < fm->total_frames; i++) {
        if (fm->frames[i].status == PAGE_FREE) {
            fm->frames[i].status = PAGE_USED;
            fm->frames[i].reference_count = 1;
            return i * PAGE_SIZE;
        }
    }

    return 0;
}

u32 perform_page_replacement(u32 fault_addr, bool is_write, bool is_user) {
    if (!clock_is_initialized() && !lru_is_initialized()) {
        return 0;
    }

#if VMM_DEBUG
    console_printf("执行页面置换...\n");
#endif

    u32 victim_frame;
    if (use_lru && lru_is_initialized()) {
        victim_frame = lru_replace();
        if (!victim_frame) {
            console_printf("错误: LRU算法未能找到可置换页面\n");
            return 0;
        }
#if VMM_DEBUG
        console_printf("LRU选择置换页框: %u\n", victim_frame);
#endif
    } else {
        victim_frame = clock_replace();
        if (!victim_frame) {
            console_printf("错误: CLOCK算法未能找到可置换页面\n");
            return 0;
        }
#if VMM_DEBUG
        console_printf("CLOCK选择置换页框: %u\n", victim_frame);
#endif
    }

    u32 victim_phys = victim_frame * PAGE_SIZE;
    u32 victim_vaddr;
    if (use_lru && lru_is_initialized()) {
        victim_vaddr = lru_get_vaddr(victim_frame);
    } else {
        victim_vaddr = clock_get_vaddr(victim_frame);
    }

    if (victim_vaddr == 0) {
        victim_vaddr = find_victim_virtual_page(victim_frame);
    }

    if (victim_vaddr) {
        page_entry_t* victim_pte = get_page_entry(victim_vaddr, false);
        if (victim_pte && (*victim_pte & PAGE_PRESENT)) {
            bool is_dirty = (*victim_pte & PAGE_DIRTY) != 0;

            if (is_dirty) {
#if VMM_DEBUG
                console_printf("页面脏，需写回交换空间\n");
#endif
                swap_out_page(victim_vaddr, victim_phys);
                vmm_stats.swap_writes++;
            }

            *victim_pte &= ~PAGE_PRESENT;
            *victim_pte &= ~PAGE_ACCESSED;

            u32 swap_idx = find_swap_entry(victim_vaddr);
            if (swap_idx == 0xFFFFFFFF) {
                swap_idx = allocate_swap_page();
            }

            if (swap_idx != 0xFFFFFFFF) {
                update_swap_entry(swap_idx, victim_vaddr, is_dirty);
            }

            invalidate_tlb(victim_vaddr);

            if (use_lru && lru_is_initialized()) {
                lru_remove_frame(victim_frame);
            } else {
                clock_remove_frame(victim_frame);
            }
        }
    }

    page_entry_t* new_pte = get_page_entry(fault_addr & 0xFFFFF000, false);
    if (new_pte) {
        if (is_write) {
            *new_pte |= PAGE_DIRTY;
        }
    }

    if (use_lru && lru_is_initialized()) {
        lru_add_frame(victim_frame, fault_addr & 0xFFFFF000);
    } else {
        clock_add_frame(victim_frame, fault_addr & 0xFFFFF000);
    }

#if VMM_DEBUG
    console_printf("置换完成: 页框 %u 分配给虚拟地址 0x%x\n", victim_frame, fault_addr & 0xFFFFF000);
#endif

    return victim_phys;
}

u32 find_victim_virtual_page(u32 frame) {
    page_entry_t* page_dir = get_page_directory();

    for (u32 dir = 0; dir < 1024; dir++) {
        if (!(page_dir[dir] & PAGE_PRESENT)) {
            continue;
        }

        page_entry_t* table = (page_entry_t*)(page_dir[dir] & 0xFFFFF000);

        for (u32 tbl = 0; tbl < 1024; tbl++) {
            if (!(table[tbl] & PAGE_PRESENT)) {
                continue;
            }

            u32 pfn = (table[tbl] & 0xFFFFF000) >> 12;
            if (pfn == frame) {
                return (dir << 22) | (tbl << 12);
            }
        }
    }

    return 0;
}

u32 allocate_swap_page(void) {
    u32 start = swap_space.next_swap_page;
    do {
        if (!swap_space.entries[swap_space.next_swap_page].in_swap) {
            swap_space.entries[swap_space.next_swap_page].in_swap = true;
            swap_space.entries[swap_space.next_swap_page].swap_page = swap_space.next_swap_page;
            u32 result = swap_space.next_swap_page;
            swap_space.next_swap_page = (swap_space.next_swap_page + 1) % SWAP_SPACE_SIZE;
            return result;
        }
        swap_space.next_swap_page = (swap_space.next_swap_page + 1) % SWAP_SPACE_SIZE;
    } while (swap_space.next_swap_page != start);

    return 0xFFFFFFFF;
}

u32 find_swap_entry(u32 virtual_addr) {
    for (u32 i = 0; i < SWAP_SPACE_SIZE; i++) {
        if (swap_space.entries[i].in_swap &&
            swap_space.entries[i].virtual_addr == virtual_addr) {
            return i;
        }
    }
    return 0xFFFFFFFF;
}

void update_swap_entry(u32 idx, u32 virtual_addr, bool dirty) {
    if (idx < SWAP_SPACE_SIZE) {
        swap_space.entries[idx].virtual_addr = virtual_addr;
        swap_space.entries[idx].dirty = dirty;
        swap_space.entries[idx].in_swap = true;
    }
}

void swap_out_page(u32 virtual_addr, u32 physical_addr) {
    u32 swap_idx = find_swap_entry(virtual_addr);
    if (swap_idx == 0xFFFFFFFF) {
        swap_idx = allocate_swap_page();
    }

    if (swap_idx != 0xFFFFFFFF) {
        update_swap_entry(swap_idx, virtual_addr, true);
    }

    console_printf("换出页面: 虚拟地址 0x%x -> 交换页 %u (物理地址 0x%x)\n",
                   virtual_addr, swap_idx, physical_addr);
}

void swap_in_page(u32 virtual_addr, u32 physical_addr) {
    u32 swap_idx = 0xFFFFFFFF;

    for (u32 i = 0; i < SWAP_SPACE_SIZE; i++) {
        if (swap_space.entries[i].in_swap &&
            swap_space.entries[i].virtual_addr == virtual_addr) {
            swap_idx = i;
            break;
        }
    }

    console_printf("换入页面: 虚拟地址 0x%x -> 物理地址 0x%x (交换页 %u)\n",
                   virtual_addr, physical_addr, swap_idx);

    if (swap_idx != 0xFFFFFFFF && swap_idx < SWAP_SPACE_SIZE) {
        swap_space.entries[swap_idx].in_swap = false;
        swap_space.entries[swap_idx].virtual_addr = 0;
    }

    vmm_stats.swap_reads++;
}

void invalidate_tlb(u32 virtual_addr) {
    asm volatile("invlpg %0" : : "m"(virtual_addr));
}

void flush_tlb(void) {
    u32 cr3;
    asm volatile("mov %%cr3, %0" : "=r"(cr3));
    asm volatile("mov %0, %%cr3" : : "r"(cr3));
}

void set_page_accessed(u32 virtual_addr) {
    page_entry_t* pte = get_page_entry(virtual_addr, false);
    if (pte) {
        *pte |= PAGE_ACCESSED;
        u32 frame = (*pte & 0xFFFFF000) >> 12;
        if (use_lru && lru_is_initialized()) {
            lru_access_page(frame, virtual_addr);
        } else if (clock_is_initialized()) {
            clock_mark_accessed(frame);
        }
    }
}

void set_page_dirty(u32 virtual_addr) {
    page_entry_t* pte = get_page_entry(virtual_addr, false);
    if (pte) {
        *pte |= PAGE_DIRTY;
    }
}

bool is_page_accessed(u32 virtual_addr) {
    page_entry_t* pte = get_page_entry(virtual_addr, false);
    return pte && (*pte & PAGE_ACCESSED);
}

bool is_page_dirty(u32 virtual_addr) {
    page_entry_t* pte = get_page_entry(virtual_addr, false);
    return pte && (*pte & PAGE_DIRTY);
}

void map_page_with_swap(u32 virtual_addr, u32 swap_page) {
    page_entry_t* pte = get_page_entry(virtual_addr, true);
    if (pte) {
        *pte = (swap_page << 12) | PAGE_PRESENT | PAGE_USER;
    }
}

bool get_swap_info(u32 virtual_addr, u32* swap_page) {
    for (u32 i = 0; i < SWAP_SPACE_SIZE; i++) {
        if (swap_space.entries[i].in_swap &&
            swap_space.entries[i].virtual_addr == virtual_addr) {
            *swap_page = swap_space.entries[i].swap_page;
            return true;
        }
    }
    return false;
}

void vmm_on_page_access(u32 virtual_addr) {
    set_page_accessed(virtual_addr);
}

void vmm_on_page_write(u32 virtual_addr) {
    set_page_dirty(virtual_addr);
}
