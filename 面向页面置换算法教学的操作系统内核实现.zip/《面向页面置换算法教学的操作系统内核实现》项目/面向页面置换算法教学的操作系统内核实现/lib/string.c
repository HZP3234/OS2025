#include "common.h"

size_t strlen(const char* str) {
    size_t len = 0;
    while (str[len] != '\0') {
        len++;
    }
    return len;
}

char* custom_strstr(const char* haystack, const char* needle) {
    if (!*needle) return (char*)haystack;
    
    for (size_t i = 0; haystack[i]; i++) {
        size_t j = 0;
        while (haystack[i + j] && needle[j] && haystack[i + j] == needle[j]) {
            j++;
        }
        if (!needle[j]) return (char*)(haystack + i);
    }
    return NULL;
}

char* strcpy(char* dest, const char* src) {
    char* d = dest;
    while (*src != '\0') {
        *d++ = *src++;
    }
    *d = '\0';
    return dest;
}

int strcmp(const char* s1, const char* s2) {
    while (*s1 && (*s1 == *s2)) {
        s1++;
        s2++;
    }
    return *(unsigned char*)s1 - *(unsigned char*)s2;
}

void* memset(void* dest, int c, size_t n) {
    unsigned char* d = (unsigned char*)dest;
    for (size_t i = 0; i < n; i++) {
        d[i] = (unsigned char)c;
    }
    return dest;
}

void* memcpy(void* dest, const void* src, size_t n) {
    unsigned char* d = (unsigned char*)dest;
    const unsigned char* s = (const unsigned char*)src;
    for (size_t i = 0; i < n; i++) {
        d[i] = s[i];
    }
    return dest;
}

int memcmp(const void* s1, const void* s2, size_t n) {
    const unsigned char* p1 = (const unsigned char*)s1;
    const unsigned char* p2 = (const unsigned char*)s2;
    for (size_t i = 0; i < n; i++) {
        if (p1[i] != p2[i]) {
            return p1[i] - p2[i];
        }
    }
    return 0;
}

char* strncpy(char* dest, const char* src, size_t n) {
    size_t i = 0;
    while (i < n && src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    while (i < n) {
        dest[i] = '\0';
        i++;
    }
    return dest;
}

int strncmp(const char* s1, const char* s2, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (s1[i] != s2[i]) {
            return (unsigned char)s1[i] - (unsigned char)s2[i];
        }
        if (s1[i] == '\0') {
            return 0;
        }
    }
    return 0;
}

void reverse_string(char* str, size_t length) {
    size_t start = 0;
    size_t end = length - 1;
    while (start < end) {
        char temp = str[start];
        str[start] = str[end];
        str[end] = temp;
        start++;
        end--;
    }
}

void utoa(unsigned int value, char* str, int base) {
    if (base < 2 || base > 16) {
        *str = '\0';
        return;
    }
    
    char* ptr = str;
    unsigned int num = value;
    
    do {
        unsigned int rem = num % base;
        *ptr++ = (rem < 10) ? (rem + '0') : (rem - 10 + 'A');
        num /= base;
    } while (num != 0);
    
    *ptr = '\0';
    reverse_string(str, ptr - str);
}

int atoi(const char* str) {
    int result = 0;
    int sign = 1;
    int i = 0;
    
    while (str[i] == ' ') {
        i++;
    }
    
    if (str[i] == '-') {
        sign = -1;
        i++;
    } else if (str[i] == '+') {
        i++;
    }
    
    while (str[i] >= '0' && str[i] <= '9') {
        result = result * 10 + (str[i] - '0');
        i++;
    }
    
    return result * sign;
}

static char* parse_number(const char* str, double* out_num) {
    double num = 0.0;
    int sign = 1;
    int after_decimal = 0;
    double divisor = 1.0;
    
    if (*str == '-') {
        sign = -1;
        str++;
    } else if (*str == '+') {
        str++;
    }
    
    while (*str >= '0' && *str <= '9') {
        num = num * 10 + (*str - '0');
        str++;
    }
    
    if (*str == '.') {
        str++;
        after_decimal = 1;
        while (*str >= '0' && *str <= '9') {
            num = num * 10 + (*str - '0');
            divisor *= 10;
            str++;
        }
    }
    
    if (after_decimal) {
        num /= divisor;
    }
    
    *out_num = num * sign;
    return (char*)str;
}

double strtod(const char* str, char** endptr) {
    if (str == NULL) {
        if (endptr != NULL) {
            *endptr = (char*)str;
        }
        return 0.0;
    }
    
    while (*str == ' ' || *str == '\n' || *str == '\t' || *str == '\r' || *str == '\f' || *str == '\v') {
        str++;
    }
    
    double result;
    char* end = parse_number(str, &result);
    
    if (endptr != NULL) {
        *endptr = end;
    }
    
    return result;
}

typedef struct BlockHeader {
    size_t size;
    struct BlockHeader* next;
    int is_free;
} BlockHeader;

#define HEAP_START 0x1000000
#define HEAP_SIZE 0x100000

static BlockHeader* heap_head = NULL;
static u32 heap_current = HEAP_START;
static u32 heap_end = HEAP_START + HEAP_SIZE;

void* malloc(size_t size) {
    if (size == 0) {
        return NULL;
    }
    
    size_t total_size = sizeof(BlockHeader) + size;
    total_size = (total_size + 3) & ~0x3;
    
    if (heap_current + total_size > heap_end) {
        return NULL;
    }
    
    BlockHeader* block = (BlockHeader*)heap_current;
    block->size = size;
    block->next = heap_head;
    block->is_free = 0;
    
    heap_head = block;
    heap_current += total_size;
    
    return (void*)((u32)block + sizeof(BlockHeader));
}

void free(void* ptr) {
    if (ptr == NULL) {
        return;
    }
}

void* realloc(void* ptr, size_t size) {
    if (size == 0) {
        return NULL;
    }
    
    void* new_ptr = malloc(size);
    if (new_ptr == NULL) {
        return NULL;
    }
    
    if (ptr != NULL) {
        BlockHeader* block = (BlockHeader*)((u32)ptr - sizeof(BlockHeader));
        size_t old_size = block->size;
        memcpy(new_ptr, ptr, old_size < size ? old_size : size);
    }
    
    return new_ptr;
}

static const char* format_spec(const char* fmt, va_list* args, char* buffer, size_t bufsize) {
    char* buf = buffer;
    char* buf_end = buffer + bufsize - 1;
    int width = 0;
    int precision = -1;
    int long_flag = 0;
    int short_flag = 0;
    
    if (*fmt == 'l') {
        long_flag = 1;
        fmt++;
    } else if (*fmt == 'h') {
        short_flag = 1;
        fmt++;
        if (*fmt == 'h') {
            short_flag = 2;
            fmt++;
        }
    }
    
    if (*fmt >= '0' && *fmt <= '9') {
        width = 0;
        while (*fmt >= '0' && *fmt <= '9') {
            width = width * 10 + (*fmt - '0');
            fmt++;
        }
    }
    
    if (*fmt == '.') {
        fmt++;
        precision = 0;
        while (*fmt >= '0' && *fmt <= '9') {
            precision = precision * 10 + (*fmt - '0');
            fmt++;
        }
    }
    
    char temp[32];
    char* temp_end = temp + sizeof(temp) - 1;
    
    switch (*fmt) {
        case 'd':
        case 'i': {
            long val = long_flag ? va_arg(*args, long) : va_arg(*args, int);
            if (val < 0) {
                if (buf < buf_end) *buf++ = '-';
                val = -val;
            }
            char* p = temp_end;
            *p = '\0';
            do {
                *--p = '0' + (val % 10);
                val /= 10;
            } while (val > 0);
            while (p < temp_end && buf < buf_end) *buf++ = *p++;
            break;
        }
        case 'u': {
            unsigned long val = long_flag ? va_arg(*args, unsigned long) : va_arg(*args, unsigned int);
            char* p = temp_end;
            *p = '\0';
            do {
                *--p = '0' + (val % 10);
                val /= 10;
            } while (val > 0);
            while (p < temp_end && buf < buf_end) *buf++ = *p++;
            break;
        }
        case 'x':
        case 'X': {
            unsigned long val = long_flag ? va_arg(*args, unsigned long) : va_arg(*args, unsigned int);
            const char* hex_chars = (*fmt == 'x') ? "0123456789abcdef" : "0123456789ABCDEF";
            char* p = temp_end;
            *p = '\0';
            do {
                *--p = hex_chars[val % 16];
                val /= 16;
            } while (val > 0);
            while (p < temp_end && buf < buf_end) *buf++ = *p++;
            break;
        }
        case 'c': {
            if (buf < buf_end) *buf++ = (char)va_arg(*args, int);
            break;
        }
        case 's': {
            const char* s = va_arg(*args, const char*);
            if (s == NULL) s = "(null)";
            while (*s && buf < buf_end) *buf++ = *s++;
            break;
        }
        case 'p': {
            unsigned long val = (unsigned long)va_arg(*args, void*);
            const char* hex_chars = "0123456789abcdef";
            if (buf < buf_end) *buf++ = '0';
            if (buf < buf_end) *buf++ = 'x';
            char* p = temp_end;
            *p = '\0';
            do {
                *--p = hex_chars[val % 16];
                val /= 16;
            } while (val > 0);
            while (p < temp_end && buf < buf_end) *buf++ = *p++;
            break;
        }
        case '%': {
            if (buf < buf_end) *buf++ = '%';
            break;
        }
    }
    
    *buf = '\0';
    return fmt + 1;
}

int snprintf(char* buffer, size_t size, const char* format, ...) {
    if (buffer == NULL || size == 0) {
        return 0;
    }
    
    va_list args;
    va_start(args, format);
    
    const char* fmt = format;
    char* buf = buffer;
    char* buf_end = buffer + size - 1;
    
    while (*fmt && buf < buf_end) {
        if (*fmt == '%') {
            fmt++;
            if (*fmt == '\0') break;
            if (*fmt == '%') {
                *buf++ = '%';
                fmt++;
                continue;
            }
            fmt = format_spec(fmt, &args, buf, buf_end - buf + 1);
            while (*fmt && buf < buf_end) {
                if (*fmt == '%') {
                    fmt++;
                    if (*fmt == '\0') break;
                    fmt = format_spec(fmt, &args, buf, buf_end - buf + 1);
                } else {
                    *buf++ = *fmt++;
                }
            }
            break;
        } else {
            *buf++ = *fmt++;
        }
    }
    
    *buf = '\0';
    va_end(args);
    
    return buf - buffer;
}
