#ifndef COMMON_H
#define COMMON_H

#include<stdint.h>
#include<stddef.h>
#include<stdbool.h>

typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t   i8;
typedef int16_t  i16;
typedef int32_t  i32;
typedef int64_t  i64;

typedef __builtin_va_list va_list;

#ifndef va_start
#define va_start(ap, param) __builtin_va_start(ap, param)
#endif

#ifndef va_end
#define va_end(ap)          __builtin_va_end(ap)
#endif

#ifndef va_arg
#define va_arg(ap, type)    __builtin_va_arg(ap, type)
#endif

#ifndef va_copy
#define va_copy(dest, src)  __builtin_va_copy(dest, src)
#endif

static inline u8 inb(u16 port) {
    u8 ret;
    asm volatile ("inb %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

static inline void outb(u16 port, u8 value) {
    asm volatile ("outb %0, %1" : : "a" (value), "dN" (port));
}

static inline u16 inw(u16 port) {
    u16 ret;
    asm volatile ("inw %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

static inline void outw(u16 port, u16 value) {
    asm volatile ("outw %0, %1" : : "a" (value), "dN" (port));
}

static inline u32 inl(u16 port) {
    u32 ret;
    asm volatile ("inl %1, %0" : "=a" (ret) : "dN" (port));
    return ret;
}

static inline void outl(u16 port, u32 value) {
    asm volatile ("outl %0, %1" : : "a" (value), "dN" (port));
}

size_t strlen(const char* str);
char* strcpy(char* dest, const char* src);
int strcmp(const char* s1, const char* s2);
void* memset(void* dest, int c, size_t n);
void* memcpy(void* dest, const void* src, size_t n);
char* strncpy(char* dest, const char* src, size_t n);
int strncmp(const char* s1, const char* s2, size_t n);

void itoa(int value, char* str, int base);
void utoa(unsigned int value, char* str, int base);
int atoi(const char* str);
void reverse_string(char* str, size_t length);

void* malloc(size_t size);
void free(void* ptr);
void* realloc(void* ptr, size_t size);

double strtod(const char* str, char** endptr);
int snprintf(char* buffer, size_t size, const char* format, ...);

#endif