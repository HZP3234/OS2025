#ifndef __PARAM_H__
#define __PARAM_H__

// 物理内存配置
#define PHYSICAL_MEMORY_SIZE (16 * 1024 * 1024)  // 物理内存16MB
#define PAGE_SIZE 4096  // 页大小4KB
#define MAX_PAGE_COUNT (PHYSICAL_MEMORY_SIZE / PAGE_SIZE)  //最大页数量
#define KERNEL_RESERVED_FRAMES 256  // 保留前256个页帧（1MB）给内核

// 内存布局常量
#define KERNEL_BASE     0x100000    // 内核起始地址 1MB
#define PAGE_FRAME_BASE 0x120000    // 页帧池起始地址 (1MB + 128KB)

#define PAGE_PRESENT 0x01
#define PAGE_WRITE 0x02
#define PAGE_USER 0x04
#define PAGE_WRITETHROUGH 0x08
#define PAGE_CACHE_DISABLE 0x10
#define PAGE_ACCESSED 0x20
#define PAGE_DIRTY    0x40

// 内存分配器配置
#define USE_BITMAP_ALLOCATOR 1  // 使用位图分配器
#define BITMAP_WORD_BITS 32

#endif