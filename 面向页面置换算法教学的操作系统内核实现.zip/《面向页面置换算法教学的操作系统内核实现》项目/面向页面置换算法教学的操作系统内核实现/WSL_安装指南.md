# WSL环境下的操作系统内核开发环境安装指南

## 1. 打开WSL终端
- 按 Win+R，输入 `wsl` 或 `bash`

## 2. 进入项目目录
```bash
cd /mnt/c/Users/lenovo/OS
```

## 3. 一键安装所有工具
```bash
# 更新包列表
sudo apt update

# 安装所有必需的工具
sudo apt install -y build-essential nasm qemu-system-x86
```

## 4. 验证安装
```bash
# 检查各个工具版本
gcc --version
nasm --version
qemu-system-i386 --version
```

## 5. 编译和运行
```bash
# 使用原有的shell脚本
./run.sh kernel
```

## 工具说明：
- **build-essential**: 包含gcc、ld、make等编译工具
- **nasm**: 汇编器 (对应Windows版本的NASM)
- **qemu-system-x86**: x86模拟器 (对应Windows版本的QEMU)

## WSL vs Windows原生的对比：

| 方面 | WSL环境 | Windows原生 |
|------|---------|-------------|
| 安装复杂度 | 一条命令安装所有工具 | 需要下载3个独立安装包 |
| 兼容性 | 原生Linux工具，100%兼容 | 需要处理Windows路径和编码 |
| 脚本运行 | 直接运行.sh脚本 | 需要转换脚本格式 |
| 开发体验 | 熟悉的Linux环境 | 跨平台兼容性处理 |

## 总结：
**WSL环境更简单、更稳定、更兼容！**