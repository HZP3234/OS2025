#ifndef __FS_H__
#define __FS_H__

#include "../lib/common.h"

#define RESULTS_DIR "../results/"

//创建文件
void create_file(void);

//写入数据
void write_result(const char* algo_name, int page_fault, int page_hit, 
                               u32 fault_percent, int access_count);

//导出结果文件到指定目录
void export_files(void);

//辅助函数：拼接文件路径
void join_path(const char* dir, const char* filename, char* result);

#endif