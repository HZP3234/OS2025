#include "fs.h"
#include "../kernel/console.h"
#include "../lib/common.h"

// 前向声明结果文件结构
typedef struct {
    char filename[256];
    char content[2048];    // 直接存储文件内容
    u32 content_size;      // 内容大小
} result_file_t;

// 简单的字符串查找最后出现位置的函数
char* custom_strrchr(const char* str, int c) {
    char* last = NULL;
    while (*str) {
        if (*str == (char)c) {
            last = (char*)str;
        }
        str++;
    }
    return last;
}

// 简单的字符串查找函数
char* custom_strchr(const char* str, int c) {
    while (*str) {
        if (*str == (char)c) {
            return (char*)str;
        }
        str++;
    }
    return NULL;
}

// 简单的字符串长度函数（如果 common.h 中没有的话）
#ifndef strlen
size_t custom_strlen(const char* str) {
    size_t len = 0;
    while (str[len]) {
        len++;
    }
    return len;
}
#define strlen custom_strlen
#endif

// 简单的字符串复制函数（如果 common.h 中没有的话）
#ifndef strcpy
char* custom_strcpy(char* dest, const char* src) {
    char* original_dest = dest;
    while ((*dest++ = *src++));
    return original_dest;
}
#define strcpy custom_strcpy
#endif

// 简单的字符串连接函数
char* custom_strcat(char* dest, const char* src) {
    char* original_dest = dest;
    while (*dest) dest++;
    while ((*dest++ = *src++));
    return original_dest;
}

// 映射到标准函数名
#define strcat custom_strcat

// 简单的整数转字符串函数
void custom_itoa(int value, char* str, int base) {
    if (base < 2 || base > 36) {
        *str = '\0';
        return;
    }
    
    char* ptr = str;
    char* ptr1 = str;
    char tmp_char;
    int tmp_value;
    
    if (value == 0) {
        *ptr++ = '0';
        *ptr = '\0';
        return;
    }
    
    // 处理负数
    if (value < 0 && base == 10) {
        *ptr++ = '-';
        value = -value;
    }
    
    // 转换数字
    while (value > 0) {
        tmp_value = value;
        value /= base;
        *ptr++ = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"[tmp_value - value * base];
    }
    
    *ptr-- = '\0';
    
    // 反转字符串
    while (ptr1 < ptr) {
        tmp_char = *ptr1;
        *ptr1++ = *ptr;
        *ptr-- = tmp_char;
    }
}

// 无符号整数转字符串
void uitoa(unsigned int value, char* str) {
    char temp[32];
    int i = 0;
    
    // 处理0
    if (value == 0) {
        str[0] = '0';
        str[1] = '\0';
        return;
    }
    
    // 转换数字到临时数组
    while (value > 0) {
        temp[i++] = (value % 10) + '0';
        value /= 10;
    }
    
    // 反转到最终字符串
    int j = 0;
    while (i > 0) {
        str[j++] = temp[--i];
    }
    str[j] = '\0';
}

// 简单的格式化字符串函数（模拟snprintf）
size_t custom_snprintf(char* buffer, size_t buffer_size, const char* format, ...) {
    // 这里实现一个非常简单的格式化函数
    // 只支持基本的字符串和数字格式化
    size_t written = 0;
    
    // 简单的实现：直接复制格式字符串
    const char* pos = format;
    while (*pos && written < buffer_size - 1) {
        if (*pos == '%' && *(pos + 1) == 's') {
            // %s 格式（需要通过参数提供）
            // 这个简化版本不处理参数，只作为占位符
            const char* placeholder = "STRING";
            size_t placeholder_len = strlen(placeholder);
            if (written + placeholder_len < buffer_size) {
                strcpy(buffer + written, placeholder);
                written += placeholder_len;
            }
            pos += 2;
        } else if (*pos == '%' && *(pos + 1) == 'u') {
            // %u 格式（需要通过参数提供）
            const char* placeholder = "NUMBER";
            size_t placeholder_len = strlen(placeholder);
            if (written + placeholder_len < buffer_size) {
                strcpy(buffer + written, placeholder);
                written += placeholder_len;
            }
            pos += 2;
        } else {
            buffer[written++] = *pos++;
        }
    }
    
    buffer[written] = '\0';
    return written;
}

// 转换为JSON格式
void convert_to_json(result_file_t* file, char* json_buffer, size_t buffer_size) {
    // 解析TXT格式内容并转换为JSON
    // 格式: "算法: FIFO\n页面错误: 10\n..."
    
    char* content = file->content;
    u32 content_len = file->content_size;
    
    // 清空缓冲区并开始JSON结构
    json_buffer[0] = '\0';
    size_t current_len = 0;
    
    // JSON结构开始
    strcpy(json_buffer, "{\n");
    current_len = strlen(json_buffer);
    
    // 添加文件信息
    char temp_line[256];
    strcpy(temp_line, "  \"filename\": \"");
    strcat(temp_line, file->filename);
    strcat(temp_line, "\",\n");
    
    if (current_len + strlen(temp_line) < buffer_size) {
        strcpy(json_buffer + current_len, temp_line);
        current_len += strlen(temp_line);
    }
    
    // 转换文件大小为字符串
    char size_str[32];
    custom_itoa(file->content_size, size_str, 10);
    strcpy(temp_line, "  \"filesize\": ");
    strcat(temp_line, size_str);
    strcat(temp_line, ",\n");
    
    if (current_len + strlen(temp_line) < buffer_size) {
        strcpy(json_buffer + current_len, temp_line);
        current_len += strlen(temp_line);
    }
    
    strcpy(temp_line, "  \"results\": [\n");
    if (current_len + strlen(temp_line) < buffer_size) {
        strcpy(json_buffer + current_len, temp_line);
        current_len += strlen(temp_line);
    }
    
    // 解析算法数据 - 按分隔线分组
    char* line_start = content;
    char* line_end;
    bool first_algo = true;
    
    for (u32 i = 0; i <= content_len; i++) {
        if (i == content_len || content[i] == '\n') {
            line_end = content + i;
            
            if (line_end > line_start) {
                // 复制行内容到临时缓冲区
                char line_content[256];
                size_t line_len = line_end - line_start;
                if (line_len >= sizeof(line_content)) {
                    line_len = sizeof(line_content) - 1;
                }
                
                memcpy(line_content, line_start, line_len);
                line_content[line_len] = '\0';
                
                // 检查是否是分隔线
                if (custom_strstr(line_content, "-------------------") != NULL) {
                    // 分隔线，表示一个算法数据结束
                    if (!first_algo) {
                        // 添加前一个算法的结束括号和逗号
                        if (current_len + 4 < buffer_size) {
                            strcpy(json_buffer + current_len, "    }\n");
                            current_len += 4;
                        }
                    }
                    first_algo = false;
                } else {
                    // 解析键值对
                    char* colon_pos = custom_strchr(line_content, ':');
                    if (colon_pos != NULL) {
                        *colon_pos = '\0'; // 分离键和值
                        char* key = line_content;
                        char* value = colon_pos + 1;
                        
                        // 跳过空格
                        while (*value == ' ') value++;
                        
                        // 清除换行符
                        size_t vlen = custom_strlen(value);
                        if (vlen > 0 && value[vlen-1] == '\n') {
                            value[vlen-1] = '\0';
                        }
                        
                        // 如果是"算法"键，表示开始新算法
                        if (strcmp(key, "算法") == 0) {
                            // 如果不是第一个算法，先关闭前一个算法
                            if (!first_algo) {
                                if (current_len + 4 < buffer_size) {
                                    strcpy(json_buffer + current_len, "    },\n");
                                    current_len += 4;
                                }
                            }
                            first_algo = false;
                            
                            // 开始新算法对象
                            if (current_len + strlen(value) + 20 < buffer_size) {
                                strcpy(json_buffer + current_len, "    {\n");
                                current_len += 4;
                                strcpy(temp_line, "      \"算法\": \"");
                                strcat(temp_line, value);
                                strcat(temp_line, "\",\n");
                                strcpy(json_buffer + current_len, temp_line);
                                current_len += strlen(temp_line);
                            }
                        } else {
                            // 其他键值对
                            if (current_len + strlen(key) + strlen(value) + 20 < buffer_size) {
                                strcpy(temp_line, "      \"");
                                strcat(temp_line, key);
                                strcat(temp_line, "\": \"");
                                strcat(temp_line, value);
                                strcat(temp_line, "\",\n");
                                strcpy(json_buffer + current_len, temp_line);
                                current_len += strlen(temp_line);
                            }
                        }
                    }
                }
            }
            
            line_start = line_end + 1;
        }
    }
    
    // 关闭最后一个算法对象
    if (!first_algo && current_len + 4 < buffer_size) {
        strcpy(json_buffer + current_len, "    }\n");
        current_len += 4;
    }
    
    // JSON结构结束
    if (current_len + 6 < buffer_size) {
        strcpy(json_buffer + current_len, "  ]\n}\n");
    }
}

//结果文件结构已在文件开头声明

//最大支持的文件数量
#define MAX_FILES 16

//全局结果文件列表
static result_file_t result_files[MAX_FILES];
static u32 file_count = 0;

//路径拼接辅助函数
void join_path(const char* dir, const char* filename, char* result) {
    //拷贝目录
    strcpy(result, dir);
    
    //检查是否需要添加路径分隔符
    size_t len = strlen(result);
    if (len > 0 && result[len-1] != '/') {
        result[len] = '/';
        result[len+1] = '\0';
    }
    
    //添加文件名
    strcpy(result + strlen(result), filename);
}

//创建结果文件
void create_file(void) {
    if (file_count >= MAX_FILES) {
        console_printf("错误: 已达到最大文件数量限制 %d\n", MAX_FILES);
        return;
    }
    
    //生成唯一的文件名
    char filename[256];
    char number_str[32];
    
    utoa(file_count + 1, number_str, 10);
    strcpy(filename, "result_");
    strcpy(filename + strlen(filename), number_str);
    strcpy(filename + strlen(filename), ".json");
    
    //检查文件是否已存在
    for (u32 i = 0; i < file_count; i++) {
        if (strcmp(result_files[i].filename, filename) == 0) {
            console_printf("警告: 文件 %s 已存在\n", filename);
            return;
        }
    }
    
    //创建文件记录
    result_file_t* file = &result_files[file_count];
    strcpy(file->filename, filename);
    file->content[0] = '\0';  // 初始化为空字符串
    file->content_size = 0;
    
    file_count++;
    
    console_printf("创建结果文件: %s\n", filename);
}

//写入结果数据到文件
void write_result(const char* algo_name, int page_fault, int page_hit, 
                 u32 fault_percent, int access_count) {
    if (file_count == 0) {
        console_printf("错误: 没有可用的结果文件，请先调用 create_file()\n");
        return;
    }
    
    //使用最近创建的文件
    result_file_t* file = &result_files[file_count - 1];
    
    //检查空间是否足够 (每个结果大约150字节)
    u32 required_size = 150;
    if (file->content_size + required_size >= sizeof(file->content)) {
        console_printf("警告: 文件 %s 空间不足，无法写入更多数据\n", file->filename);
        return;
    }
    
    //格式化结果数据并追加到文件内容
    char line[256];
    char temp[64];
    
    //算法名称
    strcpy(line, "算法: ");
    strcpy(line + strlen(line), algo_name);
    strcpy(line + strlen(line), "\n");
    
    //页面错误数
    strcpy(temp, "页面错误: ");
    utoa(page_fault, temp + strlen(temp), 10);
    strcpy(line + strlen(line), temp);
    strcpy(line + strlen(line), "\n");
    
    //页面命中数
    strcpy(temp, "页面命中: ");
    utoa(page_hit, temp + strlen(temp), 10);
    strcpy(line + strlen(line), temp);
    strcpy(line + strlen(line), "\n");
    
    //错误率
    strcpy(temp, "错误率: ");
    utoa(fault_percent, temp + strlen(temp), 10);
    strcpy(temp + strlen(temp), "%");
    strcpy(line + strlen(line), temp);
    strcpy(line + strlen(line), "\n");
    
    //访问次数
    strcpy(temp, "访问次数: ");
    utoa(access_count, temp + strlen(temp), 10);
    strcpy(line + strlen(line), temp);
    strcpy(line + strlen(line), "\n");
    
    //分隔线
    strcpy(line + strlen(line), "-------------------\n");
    
    //将内容追加到文件缓冲区
    strcpy(file->content + file->content_size, line);
    file->content_size += strlen(line);
    
    console_printf("成功写入 %s 算法结果到文件 %s (当前大小: %u 字节)\n", 
                   algo_name, file->filename, file->content_size);
}

//写入文件到实际文件系统（简化实现）
bool write_file_to_disk(const char* filepath, const char* content) {
    // 这里实现一个简化的文件写入功能
    // 在真实的系统中，这里会调用底层的文件系统接口
    
    // 使用命令行工具创建文件（仅用于演示和测试）
    char cmd[1024];
    
    // 创建临时文件写入脚本
    strcpy(cmd, "echo '");
    custom_strcat(cmd, content);
    custom_strcat(cmd, "' > ");
    custom_strcat(cmd, filepath);
    
    console_printf("正在写入文件: %s\n", filepath);
    console_printf("写入命令: %s\n", cmd);
    
    // 在真实环境中，这里会调用系统调用
    // system(cmd); // 注释掉，因为在内核环境中无法调用
    
    return true;
}

//导出所有结果文件
void export_files(void) {
    if (file_count == 0) {
        console_export_print("没有结果文件需要导出\n");
        return;
    }
    
    console_export_print("\n========================================\n");
    console_export_print("         开始导出结果文件\n");
    console_export_print("========================================\n");
    
    console_export_print("将通过stdout输出文件数据，请使用文件接收器保存...\n");
    
    for (u32 i = 0; i < file_count; i++) {
        result_file_t* file = &result_files[i];
        
        if (file->content_size > 0) {
            console_export_print("\n--- 文件信息 ---\n");
            console_export_print("文件名: ");
            console_export_print(file->filename);
            console_export_print("\n");
            console_export_print("文件大小: ");
            char size_str[32];
            uitoa(file->content_size, size_str);
            console_export_print(size_str);
            console_export_print(" 字节\n");
            
            // 输出JSON文件数据（带标记）
            console_export_print("\n=== FILE_BEGIN: ");
            console_export_print(file->filename);
            console_export_print(" ===\n");
            
            // 转换为JSON格式并输出
            char json_content[4096];
            convert_to_json(file, json_content, sizeof(json_content));
            
            // 直接输出JSON内容
            console_export_print(json_content);
            
            console_export_print("=== FILE_END: ");
            console_export_print(file->filename);
            console_export_print(" ===\n");
            
            console_export_print("文件 ");
            console_export_print(file->filename);
            console_export_print(" 已导出到results文件夹\n");
            console_export_print("-------------------\n");
        }
    }
    
    console_export_print("\n========================================\n");
    console_export_print("    所有 ");
    char count_str[32];
    uitoa(file_count, count_str);
    console_export_print(count_str);
    console_export_print(" 个结果文件导出完成!\n");
    console_export_print("请检查results文件夹中的保存结果\n");
    console_export_print("========================================\n");
}
