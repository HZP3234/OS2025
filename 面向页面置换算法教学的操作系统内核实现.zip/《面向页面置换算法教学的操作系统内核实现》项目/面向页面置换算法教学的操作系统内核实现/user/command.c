#include "command.h"
#include "../lib/common.h"
#include "../kernel/console.h"
#include "../lib/param.h"
#include "../mm/page.h"
#include "../mm/vmm.h"
#include "../kernel/kernel.h"

//命令初始化
void command_init(void){
   console_print("命令系统初始化完成，输入 help 查看命令列表\n");
}

//命令解析函数：将命令行拆分为命令名和参数数组
int parse_command(char* buffer, char* argv[]){    
    int argc = 0;
    char* token = buffer;
    
    //跳过开头的空格
    while (*token == ' ') {
        token++;
    }
    
    //解析命令名和参数
    while (*token != '\0' && argc < 10) {
        argv[argc++] = token;
        
        //找到下一个空格
        while (*token != ' ' && *token != '\0') {
            token++;
        }
        
        if (*token == ' ') {
            *token = '\0';
            token++;
            
            //跳过连续的空格
            while (*token == ' ') {
                token++;
            }
        }
    }
    
    argv[argc] = NULL;
    return argc;
}

void command_echo(int argc, char* argv[]){
    if (argc > 1) {
        for (int i = 1; i < argc; i++) {
            console_print(argv[i]);
            console_print(" ");
        }
    }
    console_print("\n");
}

void command_help(int argc, char* argv[]){
    (void)argc;
    (void)argv;
    console_print("=== 内存管理命令 ===\n");
    console_print("  help            - 显示此帮助信息\n");
    console_print("  echo <字符串>    - 回显参数\n");
    console_print("  alloc <字节>     - 分配物理内存\n");
    console_print("  free all        - 释放所有可释放内存\n");
    console_print("  list alloc      - 列出已分配的页帧\n");
    console_print("  meminfo         - 显示内存详细信息\n");
    console_print("  bitmap          - 显示位图分配器状态\n");
    console_print("  clock <页帧数>   - CLOCK页面置换算法（不输入页帧数默认为3）\n");
    console_print("  lru <页帧数>     - LRU页面置换算法（不输入页帧数默认为3）\n");
    console_print("  fifo <页帧数>    - FIFO页面置换算法（不输入页帧数默认为3）\n");
    console_print("  algo <页帧数>    - 综合执行页面置换算法（不输入页帧数默认为5）\n");
    console_print("  exit            - 退出系统\n");
    console_print("  memtest         - 测试内存能否正常读写\n");
    console_print("  【注意】：图形界面仅用于教学演示，不支持实际应用场景。\n");
    console_print("           请在另一个终端中打开图形界面（python3 vis_algo.py）\n");
}

void command_alloc(int argc, char* argv[]){
    console_print("准备分配物理内存\n");

    if(argc<2){
        console_print("请指定分配的内存大小（单位：字节）\n");
        return;
    }

    u32 size=atoi(argv[1]);
    if(size<=0){
        console_print("无效的内存大小，请输入正整数\n");
        return;
    }
    
    // 计算需要分配的页帧数
    u32 num_frames = (size + PAGE_SIZE - 1) / PAGE_SIZE;

    // 检查是否尝试分配保留区域
    page_frame_manager_t* manager = get_page_frame_manager();
    if (manager->next_free_frame < manager->reserved_frames) {
        manager->next_free_frame = manager->reserved_frames;
        console_printf("跳过保留区域，从页帧 %u 开始分配\n", manager->next_free_frame);
    }
    
    char num_str[20];
    utoa(num_frames, num_str, 10);
    console_print("需要分配 ");
    console_print(num_str);
    console_print(" 个页帧\n");
    
    // 检查请求的页帧数是否超过可用内存
    if (num_frames > manager->free_frames) {
        console_print("错误: 请求的页帧数超过可用内存\n");
        console_print("可用页帧: ");
        utoa(manager->free_frames, num_str, 10);
        console_print(num_str);
        console_print("\n");
        return;
    }
    
    // 分配页帧
    u32 allocated_frames = 0;
    u32 addresses[32];  // 最多分配32个页帧
    bool allocation_failed = false;
    
    for (u32 i = 0; i < num_frames; i++) {
        u32 addr = alloc_page_frame();
        if (addr == 0) {
            console_print("内存不足，分配失败\n");
            allocation_failed = true;
            break;
        }
        addresses[allocated_frames++] = addr;

        // 将分配的页帧加入时钟置换队列（队列最多32个槽位）
        if (!clock_is_initialized()) {
            clock_init(32);
        }
        if (!clock_add_frame(addr / PAGE_SIZE, 0)) {
            // 队列已满，新分配的页帧不会被CLOCK算法追踪
        }
    }
    
    // 如果部分分配失败，释放已分配的页帧
    if (allocation_failed && allocated_frames > 0) {
        console_print("部分分配失败，释放已分配的页帧\n");
        for (u32 i = 0; i < allocated_frames; i++) {
            free_page_frame(addresses[i]);
        }
        allocated_frames = 0;
    }
    
    // 显示分配结果
    if (allocated_frames > 0) {
        console_print("成功分配 ");
        utoa(allocated_frames, num_str, 10);
        console_print(num_str);
        console_print(" 个页帧\n");
        
        console_print("分配的物理地址：\n");
        for (u32 i = 0; i < allocated_frames; i++) {
            console_print("  页帧 ");
            utoa(i, num_str, 10);
            console_print(num_str);
            console_print(": 0x");
            
            char hex_str[10];
            utoa(addresses[i], hex_str, 16);
            console_print(hex_str);
            console_print(" (页索引");
            utoa(addresses[i] / PAGE_SIZE, num_str, 10);
            console_print(num_str);
            console_print(")\n");
        }
        
        u32 total_allocated = allocated_frames * PAGE_SIZE;
        console_print("总分配内存：");
        utoa(total_allocated, num_str, 10);
        console_print(num_str);
        console_print(" 字节\n");
        
        // 显示内存统计
        console_print("\n当前内存状态：\n");
        console_print("  总页帧: ");
        utoa(manager->total_frames, num_str, 10);
        console_print(num_str);
        console_print("\n  空闲页帧: ");
        utoa(manager->free_frames, num_str, 10);
        console_print(num_str);
        console_print("\n");
    } else {
        console_print("未分配任何内存\n");
    }
}

void command_free(int argc, char* argv[]) {
    if (argc < 2) {
        console_printf("指令无效\n");
        return;
    }
    
    if (strcmp(argv[1], "all") == 0) {
        // 释放所有用户分配的页帧（跳过内核保留）
        page_frame_manager_t* manager = get_page_frame_manager();
        u32 freed_count = 0;
        
        console_printf("开始释放用户页帧...\n");
        console_printf("内核保留页帧范围: 0-%u\n", manager->reserved_frames - 1);
        
        // 从保留页帧之后开始释放
        for (u32 i = manager->reserved_frames; i < manager->total_frames; i++) {
            if (manager->frames[i].status == PAGE_USED) {
                console_printf("释放页帧 %u (地址: 0x%x)\n", 
                              i, i * PAGE_SIZE);
                free_page_frame(i * PAGE_SIZE);
                freed_count++;
            }
        }
        
        console_printf("已释放 %u 个用户页帧\n", freed_count);
        
        // 显示当前状态
        console_printf("\n当前内存状态：\n");
        console_printf("  总页帧: %u\n", manager->total_frames);
        console_printf("  保留页帧: %u\n", manager->reserved_frames);
        console_printf("  空闲页帧: %u\n", manager->free_frames);
    }
}

void command_list_alloc(int argc, char* argv[]){
    (void)argc;
    (void)argv;
    console_printf("=== 已分配的页帧列表 ===\n");
    
    u32 count = 0;
    page_frame_manager_t* manager = get_page_frame_manager();
    for (u32 i = 0; i < manager->total_frames; i++) {
        if (manager->frames[i].status == PAGE_USED) {
            console_printf("%u. 页帧:%u 地址:0x%x 引用:%u\n",
                          count + 1, i, i * PAGE_SIZE, 
                          manager->frames[i].reference_count);
            count++;
        }
    }
    
    console_printf("总计: %u 个已分配页帧\n", count);
}

void command_meminfo(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
    console_printf("=== 系统内存信息 ===\n");
    
    // 1. 总体统计
    kernel_t* kernel = get_kernel_state();
    console_printf("物理内存总量: %u KB (%u MB)\n", 
                   kernel->memory_size / 1024,
                   kernel->memory_size / 1024 / 1024);
    console_printf("已使用内存: %u KB\n", kernel->used_memory / 1024);
    console_printf("空闲内存: %u KB\n", kernel->free_memory / 1024);
    
    if (kernel->memory_size > 0) {
        u32 usage = (kernel->used_memory * 100) / kernel->memory_size;
        console_printf("使用率: %u%%\n", usage);
    }
    
    // 2. 页帧详细信息
    page_frame_manager_t* manager = get_page_frame_manager();
    console_printf("\n=== 页帧管理信息 ===\n");
    console_printf("总页帧数: %u\n", manager->total_frames);
    console_printf("空闲页帧: %u\n", manager->free_frames);
    console_printf("使用页帧: %u\n", manager->used_frames);
    
    // 3. 按状态统计
    u32 free_count = 0, used_count = 0, reserved_count = 0;
    for (u32 i = 0; i < manager->total_frames; i++) {
        if (manager->frames[i].status == PAGE_RESERVED) {
            reserved_count++;
        } else if (manager->frames[i].status == PAGE_USED) {
            used_count++;
        } else {
            free_count++;
        }
    }
    console_printf("状态统计: 空闲=%u, 使用=%u, 保留=%u\n",free_count, used_count, reserved_count);
}

void command_bitmap(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
#ifdef USE_BITMAP_ALLOCATOR
    bitmap_print_status();
#else
    console_printf("位图分配器未启用（在param.h中设置USE_BITMAP_ALLOCATOR=1）\n");
#endif
}

void command_clock(int argc, char* argv[]) {
    u32 frame_count = 3;
    
    if (argc >= 2) {
        frame_count = atoi(argv[1]);
        if (frame_count < 2) frame_count = 2;
        if (frame_count > 32) frame_count = 32;
    }
    
    console_printf("=== CLOCK页面置换算法测试 ===\n");
    console_printf("物理页框限制: %u 个\n", frame_count);
    
    page_frame_manager_t* manager = get_page_frame_manager();
    
    u32 reserved_start = manager->reserved_frames;
    u32 test_frame_start = reserved_start + 1;
    u32 test_frame_end = test_frame_start + frame_count;
    
    console_printf("测试用物理页框范围: %u - %u\n", test_frame_start, test_frame_end - 1);
    
    for (u32 i = test_frame_start; i < test_frame_end; i++) {
        if (i < manager->total_frames && manager->frames[i].status == PAGE_USED) {
            free_page_frame(i * PAGE_SIZE);
        }
        manager->frames[i].status = PAGE_FREE;
        manager->frames[i].reference_count = 0;
    }
    
    console_printf("测试页框已准备就绪\n");
    
    #define TEST_PAGE_COUNT 20
    #define ACCESS_SEQUENCE_LENGTH 15
    
    u32 test_vaddrs[TEST_PAGE_COUNT];
    u32 user_base = 0x40000000;
    for (int i = 0; i < TEST_PAGE_COUNT; i++) {
        test_vaddrs[i] = user_base + (i * PAGE_SIZE);
    }
    
    console_printf("\n--- 创建虚拟页面 ---\n");
    for (int i = 0; i < TEST_PAGE_COUNT; i++) {
        console_printf("  虚拟页面 %d: 地址 0x%x\n", i, test_vaddrs[i]);
    }
    
    u32 access_sequence[ACCESS_SEQUENCE_LENGTH];
    u32 seed = 12345;
    for (int i = 0; i < ACCESS_SEQUENCE_LENGTH; i++) {
        seed = (seed * 1103515245 + 12345) & 0x7fffffff;
        access_sequence[i] = seed % TEST_PAGE_COUNT;
    }
    
    console_printf("\n--- 页面访问序列 ---\n");
    console_printf("  ");
    for (int i = 0; i < ACCESS_SEQUENCE_LENGTH; i++) {
        console_printf("%d ", access_sequence[i]);
    }
    console_printf("\n");
    
    typedef struct {
        u32 virtual_addr;
        u32 physical_frame;
        bool in_memory;
    } page_info_t;
    
    page_info_t page_info[TEST_PAGE_COUNT];
    for (int i = 0; i < TEST_PAGE_COUNT; i++) {
        page_info[i].virtual_addr = test_vaddrs[i];
        page_info[i].physical_frame = 0xFFFFFFFF;
        page_info[i].in_memory = false;
    }
    
    u32 frame_occupied[32];
    for (u32 i = 0; i < frame_count; i++) {
        frame_occupied[i] = 0xFFFFFFFF;
    }
    
    console_printf("\n--- 初始加载页面 ---\n");
    u32 loaded_count = 0;
    for (u32 i = 0; i < frame_count && i < TEST_PAGE_COUNT; i++) {
        u32 frame_idx = test_frame_start + i;
        
        if (frame_idx >= manager->total_frames) {
            console_printf("  错误: 页框索引 %u 超出范围\n", frame_idx);
            continue;
        }
        
        manager->frames[frame_idx].status = PAGE_USED;
        manager->frames[frame_idx].reference_count = 1;
        
        u32 physical_addr = frame_idx * PAGE_SIZE;
        map_page(test_vaddrs[i], physical_addr, PAGE_PRESENT | PAGE_WRITE);
        
        page_info[i].physical_frame = frame_idx;
        page_info[i].in_memory = true;
        frame_occupied[i] = i;
        
        console_printf("  页面 %d -> 物理页框 %d (0x%x)\n", 
                      i, frame_idx, physical_addr);
        loaded_count++;
    }
    
    console_printf("初始加载完成: %u 个页面\n", loaded_count);
    
    console_printf("\n--- 执行页面访问 ---\n");
    u32 page_faults = 0;
    u32 hits = 0;
    u32 next_free_slot = loaded_count;
    
    for (u32 access_num = 0; access_num < ACCESS_SEQUENCE_LENGTH; access_num++) {
        u32 page_id = access_sequence[access_num];
        u32 vaddr = test_vaddrs[page_id];
        
        console_printf("[访问 %d] 页面 %d: ", access_num + 1, page_id);
        
        page_entry_t* entry = get_page_entry(vaddr, false);
        bool present = (entry && (*entry & PAGE_PRESENT));
        
        if (present && page_info[page_id].in_memory) {
            u32 frame_idx = page_info[page_id].physical_frame;
            console_printf("命中 -> 页框 %d\n", frame_idx);
            hits++;
            continue;
        }
        
        page_faults++;
        console_printf("缺页 -> ");
        
        u32 victim_frame = 0;
        u32 victim_page_id = 0xFFFFFFFF;
        
        if (next_free_slot < frame_count) {
            victim_frame = test_frame_start + next_free_slot;
            next_free_slot++;
            console_printf("使用空闲页框 %d\n", victim_frame);
        } else {
            u32 start_hand = 0;
            u32 scans = 0;
            while (scans < frame_count * 2) {
                u32 current = start_hand;
                u32 frame_at_slot = test_frame_start + current;
                u32 page_at_frame = frame_occupied[current];
                
                if (page_at_frame != 0xFFFFFFFF) {
                    u32 ref_bit = manager->frames[frame_at_slot].reference_count;
                    if (ref_bit == 0) {
                        victim_frame = frame_at_slot;
                        victim_page_id = page_at_frame;
                        frame_occupied[current] = 0xFFFFFFFF;
                        start_hand = (current + 1) % frame_count;
                        break;
                    } else {
                        manager->frames[frame_at_slot].reference_count = 0;
                    }
                }
                
                start_hand = (current + 1) % frame_count;
                scans++;
                
                if (start_hand == 0) break;
            }
            
            if (victim_frame == 0) {
                for (u32 i = 0; i < frame_count; i++) {
                    u32 frame_at_slot = test_frame_start + i;
                    if (frame_occupied[i] != 0xFFFFFFFF) {
                        victim_frame = frame_at_slot;
                        victim_page_id = frame_occupied[i];
                        frame_occupied[i] = 0xFFFFFFFF;
                        break;
                    }
                }
            }
            
            if (victim_frame != 0 && victim_page_id != 0xFFFFFFFF) {
                console_printf("置换页框 %d (页面 %d) -> 页面 %d\n", 
                              victim_frame, victim_page_id, page_id);
                
                page_entry_t* victim_entry = get_page_entry(
                    page_info[victim_page_id].virtual_addr, false);
                if (victim_entry) {
                    *victim_entry = 0;
                }
                
                page_info[victim_page_id].in_memory = false;
                page_info[victim_page_id].physical_frame = 0xFFFFFFFF;
            } else {
                console_printf("错误: 无法找到置换目标\n");
                continue;
            }
        }
        
        if (victim_frame != 0 && victim_frame >= test_frame_start && 
            victim_frame < test_frame_end) {
            u32 physical_addr = victim_frame * PAGE_SIZE;
            map_page(vaddr, physical_addr, PAGE_PRESENT | PAGE_WRITE);
            
            page_info[page_id].physical_frame = victim_frame;
            page_info[page_id].in_memory = true;
            
            for (u32 i = 0; i < frame_count; i++) {
                if (test_frame_start + i == victim_frame) {
                    frame_occupied[i] = page_id;
                    break;
                }
            }
            
            manager->frames[victim_frame].reference_count = 1;
        }
    }
    
    console_printf("\n--- 测试结果 ---\n");
    console_printf("总访问次数: %u\n", ACCESS_SEQUENCE_LENGTH);
    console_printf("缺页次数: %u\n", page_faults);
    console_printf("命中次数: %u\n", hits);
    console_printf("缺页率: %u%%\n", (page_faults * 100) / ACCESS_SEQUENCE_LENGTH);
    
    console_printf("\n--- 最终页框状态 ---\n");
    for (u32 i = 0; i < frame_count; i++) {
        u32 frame_idx = test_frame_start + i;
        u32 page_id = frame_occupied[i];
        if (page_id != 0xFFFFFFFF) {
            console_printf("  页框 %d: 页面 %d (0x%x)\n", 
                          frame_idx, page_id, test_vaddrs[page_id]);
        } else {
            console_printf("  页框 %d: 空闲\n", frame_idx);
        }
    }
    
    console_printf("\n--- 清理测试页框 ---\n");
    for (u32 i = 0; i < frame_count; i++) {
        u32 frame_idx = test_frame_start + i;
        if (frame_idx < manager->total_frames) {
            u32 page_id = frame_occupied[i];
            if (page_id != 0xFFFFFFFF) {
                page_entry_t* entry = get_page_entry(
                    page_info[page_id].virtual_addr, false);
                if (entry) *entry = 0;
            }
            manager->frames[frame_idx].status = PAGE_FREE;
            manager->frames[frame_idx].reference_count = 0;
        }
    }
    console_printf("测试完成，页框已清理\n");
}

void command_lru(int argc, char* argv[]) {
    u32 frame_count = 3;
    
    if (argc >= 2) {
        frame_count = atoi(argv[1]);
        if (frame_count < 2) frame_count = 2;
        if (frame_count > 32) frame_count = 32;
    }
    
    console_printf("=== LRU页面置换算法测试 ===\n");
    console_printf("物理页框限制: %u 个\n", frame_count);
    
    page_frame_manager_t* manager = get_page_frame_manager();
    
    u32 reserved_start = manager->reserved_frames;
    u32 test_frame_start = reserved_start + 1;
    u32 test_frame_end = test_frame_start + frame_count;
    
    console_printf("测试用物理页框范围: %u - %u\n", test_frame_start, test_frame_end - 1);
    
    for (u32 i = test_frame_start; i < test_frame_end; i++) {
        if (i < manager->total_frames && manager->frames[i].status == PAGE_USED) {
            free_page_frame(i * PAGE_SIZE);
        }
        manager->frames[i].status = PAGE_FREE;
        manager->frames[i].reference_count = 0;
    }
    
    console_printf("测试页框已准备就绪\n");
    
    #define LRU_TEST_PAGE_COUNT 20
    #define LRU_ACCESS_SEQUENCE_LENGTH 15
    
    u32 test_vaddrs[LRU_TEST_PAGE_COUNT];
    u32 user_base = 0x50000000;
    for (int i = 0; i < LRU_TEST_PAGE_COUNT; i++) {
        test_vaddrs[i] = user_base + (i * PAGE_SIZE);
    }
    
    console_printf("\n--- 创建虚拟页面 ---\n");
    for (int i = 0; i < LRU_TEST_PAGE_COUNT; i++) {
        console_printf("  虚拟页面 %d: 地址 0x%x\n", i, test_vaddrs[i]);
    }
    
    u32 access_sequence[LRU_ACCESS_SEQUENCE_LENGTH];
    u32 seed = 12345;
    for (int i = 0; i < LRU_ACCESS_SEQUENCE_LENGTH; i++) {
        seed = (seed * 1103515245 + 12345) & 0x7fffffff;
        access_sequence[i] = seed % LRU_TEST_PAGE_COUNT;
    }
    
    console_printf("\n--- 页面访问序列 ---\n");
    console_printf("  ");
    for (int i = 0; i < LRU_ACCESS_SEQUENCE_LENGTH; i++) {
        console_printf("%d ", access_sequence[i]);
    }
    console_printf("\n");
    
    typedef struct {
        u32 virtual_addr;
        u32 physical_frame;
        bool in_memory;
        u32 last_access_time;
    } lru_page_info_t;
    
    lru_page_info_t page_info[LRU_TEST_PAGE_COUNT];
    for (int i = 0; i < LRU_TEST_PAGE_COUNT; i++) {
        page_info[i].virtual_addr = test_vaddrs[i];
        page_info[i].physical_frame = 0xFFFFFFFF;
        page_info[i].in_memory = false;
        page_info[i].last_access_time = 0;
    }
    
    u32 frame_occupied[32];
    for (u32 i = 0; i < frame_count; i++) {
        frame_occupied[i] = 0xFFFFFFFF;
    }
    
    console_printf("\n--- 初始加载页面 ---\n");
    u32 loaded_count = 0;
    u32 current_time = 0;
    
    for (u32 i = 0; i < frame_count && i < LRU_TEST_PAGE_COUNT; i++) {
        u32 frame_idx = test_frame_start + i;
        
        if (frame_idx >= manager->total_frames) {
            console_printf("  错误: 页框索引 %u 超出范围\n", frame_idx);
            continue;
        }
        
        manager->frames[frame_idx].status = PAGE_USED;
        manager->frames[frame_idx].reference_count = 1;
        
        u32 physical_addr = frame_idx * PAGE_SIZE;
        map_page(test_vaddrs[i], physical_addr, PAGE_PRESENT | PAGE_WRITE);
        
        page_info[i].physical_frame = frame_idx;
        page_info[i].in_memory = true;
        page_info[i].last_access_time = current_time++;
        frame_occupied[i] = i;
        
        console_printf("  页面 %d -> 物理页框 %d (0x%x) [访问时间: %u]\n", 
                      i, frame_idx, physical_addr, page_info[i].last_access_time);
        loaded_count++;
    }
    
    console_printf("初始加载完成: %u 个页面\n", loaded_count);
    
    console_printf("\n--- 执行页面访问 ---\n");
    u32 page_faults = 0;
    u32 hits = 0;
    u32 next_free_slot = loaded_count;
    
    for (u32 access_num = 0; access_num < LRU_ACCESS_SEQUENCE_LENGTH; access_num++) {
        u32 page_id = access_sequence[access_num];
        u32 vaddr = test_vaddrs[page_id];
        
        console_printf("[访问 %d] 页面 %d: ", access_num + 1, page_id);
        
        page_entry_t* entry = get_page_entry(vaddr, false);
        bool present = (entry && (*entry & PAGE_PRESENT));
        
        if (present && page_info[page_id].in_memory) {
            u32 frame_idx = page_info[page_id].physical_frame;
            console_printf("命中 -> 页框 %d\n", frame_idx);
            page_info[page_id].last_access_time = current_time++;
            hits++;
            continue;
        }
        
        page_faults++;
        console_printf("缺页 -> ");
        
        u32 victim_frame = 0;
        u32 victim_page_id = 0xFFFFFFFF;
        u32 victim_slot = 0xFFFFFFFF;
        
        if (next_free_slot < frame_count) {
            victim_frame = test_frame_start + next_free_slot;
            next_free_slot++;
            console_printf("使用空闲页框 %d\n", victim_frame);
        } else {
            u32 oldest_time = 0xFFFFFFFF;
            u32 oldest_slot = 0xFFFFFFFF;
            
            for (u32 slot = 0; slot < frame_count; slot++) {
                u32 page_at_frame = frame_occupied[slot];
                if (page_at_frame != 0xFFFFFFFF) {
                    if (page_info[page_at_frame].last_access_time < oldest_time) {
                        oldest_time = page_info[page_at_frame].last_access_time;
                        oldest_slot = slot;
                    }
                }
            }
            
            if (oldest_slot != 0xFFFFFFFF) {
                victim_frame = test_frame_start + oldest_slot;
                victim_page_id = frame_occupied[oldest_slot];
                victim_slot = oldest_slot;
                
                console_printf("LRU置换: 选择页面 %d (页框 %d, 最后访问时间: %u) -> 页面 %d\n", 
                              victim_page_id, victim_frame, oldest_time, page_id);
                
                page_entry_t* victim_entry = get_page_entry(
                    page_info[victim_page_id].virtual_addr, false);
                if (victim_entry) {
                    *victim_entry = 0;
                }
                
                page_info[victim_page_id].in_memory = false;
                page_info[victim_page_id].physical_frame = 0xFFFFFFFF;
                frame_occupied[oldest_slot] = 0xFFFFFFFF;
            } else {
                console_printf("错误: 无法找到置换目标\n");
                continue;
            }
        }
        
        if (victim_frame != 0 && victim_frame >= test_frame_start && 
            victim_frame < test_frame_end) {
            u32 physical_addr = victim_frame * PAGE_SIZE;
            map_page(vaddr, physical_addr, PAGE_PRESENT | PAGE_WRITE);
            
            page_info[page_id].physical_frame = victim_frame;
            page_info[page_id].in_memory = true;
            page_info[page_id].last_access_time = current_time++;
            
            for (u32 slot = 0; slot < frame_count; slot++) {
                if (test_frame_start + slot == victim_frame) {
                    frame_occupied[slot] = page_id;
                    break;
                }
            }
            
            manager->frames[victim_frame].reference_count = 1;
        }
    }
    
    console_printf("\n--- 测试结果 ---\n");
    console_printf("总访问次数: %u\n", LRU_ACCESS_SEQUENCE_LENGTH);
    console_printf("缺页次数: %u\n", page_faults);
    console_printf("命中次数: %u\n", hits);
    console_printf("缺页率: %u%%\n", (page_faults * 100) / LRU_ACCESS_SEQUENCE_LENGTH);
    
    console_printf("\n--- 最终页框状态 ---\n");
    for (u32 i = 0; i < frame_count; i++) {
        u32 frame_idx = test_frame_start + i;
        u32 page_id = frame_occupied[i];
        if (page_id != 0xFFFFFFFF) {
            console_printf("  页框 %d: 页面 %d (0x%x) [访问时间: %u]\n", 
                          frame_idx, page_id, test_vaddrs[page_id], 
                          page_info[page_id].last_access_time);
        } else {
            console_printf("  页框 %d: 空闲\n", frame_idx);
        }
    }
    
    console_printf("\n--- 清理测试页框 ---\n");
    for (u32 i = 0; i < frame_count; i++) {
        u32 frame_idx = test_frame_start + i;
        if (frame_idx < manager->total_frames) {
            u32 page_id = frame_occupied[i];
            if (page_id != 0xFFFFFFFF) {
                page_entry_t* entry = get_page_entry(
                    page_info[page_id].virtual_addr, false);
                if (entry) *entry = 0;
            }
            manager->frames[frame_idx].status = PAGE_FREE;
            manager->frames[frame_idx].reference_count = 0;
        }
    }
    console_printf("测试完成，页框已清理\n");
}

void command_fifo(int argc, char* argv[]) {
    u32 frame_count = 3;
    
    if (argc >= 2) {
        frame_count = atoi(argv[1]);
        if (frame_count < 2) frame_count = 2;
        if (frame_count > 32) frame_count = 32;
    }
    
    console_printf("=== FIFO页面置换算法测试 ===\n");
    console_printf("物理页框限制: %u 个\n", frame_count);
    
    page_frame_manager_t* manager = get_page_frame_manager();
    
    u32 reserved_start = manager->reserved_frames;
    u32 test_frame_start = reserved_start + 1;
    u32 test_frame_end = test_frame_start + frame_count;
    
    console_printf("测试用物理页框范围: %u - %u\n", test_frame_start, test_frame_end - 1);
    
    for (u32 i = test_frame_start; i < test_frame_end; i++) {
        if (i < manager->total_frames && manager->frames[i].status == PAGE_USED) {
            free_page_frame(i * PAGE_SIZE);
        }
        manager->frames[i].status = PAGE_FREE;
        manager->frames[i].reference_count = 0;
    }
    
    console_printf("测试页框已准备就绪\n");
    
    #define FIFO_TEST_PAGE_COUNT 20
    #define FIFO_ACCESS_SEQUENCE_LENGTH 15
    
    u32 test_vaddrs[FIFO_TEST_PAGE_COUNT];
    u32 user_base = 0x50000000;
    for (int i = 0; i < FIFO_TEST_PAGE_COUNT; i++) {
        test_vaddrs[i] = user_base + (i * PAGE_SIZE);
    }
    
    console_printf("\n--- 创建虚拟页面 ---\n");
    for (int i = 0; i < FIFO_TEST_PAGE_COUNT; i++) {
        console_printf("  虚拟页面 %d: 地址 0x%x\n", i, test_vaddrs[i]);
    }
    
    u32 access_sequence[FIFO_ACCESS_SEQUENCE_LENGTH];
    u32 seed = 12345;
    for (int i = 0; i < FIFO_ACCESS_SEQUENCE_LENGTH; i++) {
        seed = (seed * 1103515245 + 12345) & 0x7fffffff;
        access_sequence[i] = seed % FIFO_TEST_PAGE_COUNT;
    }
    
    console_printf("\n--- 页面访问序列 ---\n");
    console_printf("  ");
    for (int i = 0; i < FIFO_ACCESS_SEQUENCE_LENGTH; i++) {
        console_printf("%d ", access_sequence[i]);
    }
    console_printf("\n");
    
    typedef struct {
        u32 virtual_addr;
        u32 physical_frame;
        bool in_memory;
        u32 insert_order;
    } fifo_page_info_t;
    
    fifo_page_info_t page_info[FIFO_TEST_PAGE_COUNT];
    for (int i = 0; i < FIFO_TEST_PAGE_COUNT; i++) {
        page_info[i].virtual_addr = test_vaddrs[i];
        page_info[i].physical_frame = 0xFFFFFFFF;
        page_info[i].in_memory = false;
        page_info[i].insert_order = 0xFFFFFFFF;
    }
    
    u32 frame_occupied[32];
    u32 frame_order[32];
    for (u32 i = 0; i < frame_count; i++) {
        frame_occupied[i] = 0xFFFFFFFF;
        frame_order[i] = 0xFFFFFFFF;
    }
    
    console_printf("\n--- 初始加载页面 ---\n");
    u32 loaded_count = 0;
    u32 next_insert_order = 0;
    
    for (u32 i = 0; i < frame_count && i < FIFO_TEST_PAGE_COUNT; i++) {
        u32 frame_idx = test_frame_start + i;
        
        if (frame_idx >= manager->total_frames) {
            console_printf("  错误: 页框索引 %u 超出范围\n", frame_idx);
            continue;
        }
        
        manager->frames[frame_idx].status = PAGE_USED;
        manager->frames[frame_idx].reference_count = 1;
        
        u32 physical_addr = frame_idx * PAGE_SIZE;
        map_page(test_vaddrs[i], physical_addr, PAGE_PRESENT | PAGE_WRITE);
        
        page_info[i].physical_frame = frame_idx;
        page_info[i].in_memory = true;
        page_info[i].insert_order = next_insert_order++;
        frame_occupied[i] = i;
        frame_order[i] = page_info[i].insert_order;
        
        console_printf("  页面 %d -> 物理页框 %d (0x%x) [插入顺序: %u]\n", 
                      i, frame_idx, physical_addr, page_info[i].insert_order);
        loaded_count++;
    }
    
    console_printf("初始加载完成: %u 个页面\n", loaded_count);
    
    console_printf("\n--- 执行页面访问 ---\n");
    u32 page_faults = 0;
    u32 hits = 0;
    u32 next_free_slot = loaded_count;
    
    for (u32 access_num = 0; access_num < FIFO_ACCESS_SEQUENCE_LENGTH; access_num++) {
        u32 page_id = access_sequence[access_num];
        u32 vaddr = test_vaddrs[page_id];
        
        console_printf("[访问 %d] 页面 %d: ", access_num + 1, page_id);
        
        page_entry_t* entry = get_page_entry(vaddr, false);
        bool present = (entry && (*entry & PAGE_PRESENT));
        
        if (present && page_info[page_id].in_memory) {
            u32 frame_idx = page_info[page_id].physical_frame;
            console_printf("命中 -> 页框 %d\n", frame_idx);
            hits++;
            continue;
        }
        
        page_faults++;
        console_printf("缺页 -> ");
        
        u32 victim_frame = 0;
        u32 victim_page_id = 0xFFFFFFFF;
        u32 victim_order = 0xFFFFFFFF;
        
        if (next_free_slot < frame_count) {
            victim_frame = test_frame_start + next_free_slot;
            next_free_slot++;
            console_printf("使用空闲页框 %d\n", victim_frame);
        } else {
            u32 oldest_order = 0xFFFFFFFF;
            u32 victim_slot = 0;
            
            for (u32 i = 0; i < frame_count; i++) {
                if (frame_occupied[i] != 0xFFFFFFFF) {
                    if (frame_order[i] < oldest_order) {
                        oldest_order = frame_order[i];
                        victim_slot = i;
                    }
                }
            }
            
            victim_frame = test_frame_start + victim_slot;
            victim_page_id = frame_occupied[victim_slot];
            victim_order = frame_order[victim_slot];
            
            frame_occupied[victim_slot] = 0xFFFFFFFF;
            frame_order[victim_slot] = 0xFFFFFFFF;
            
            console_printf("置换页框 %d (页面 %d, 插入顺序: %u) -> 页面 %d\n", 
                          victim_frame, victim_page_id, victim_order, page_id);
            
            page_entry_t* victim_entry = get_page_entry(
                page_info[victim_page_id].virtual_addr, false);
            if (victim_entry) {
                *victim_entry = 0;
            }
            
            page_info[victim_page_id].in_memory = false;
            page_info[victim_page_id].physical_frame = 0xFFFFFFFF;
            page_info[victim_page_id].insert_order = 0xFFFFFFFF;
        }
        
        if (victim_frame != 0 && victim_frame >= test_frame_start && 
            victim_frame < test_frame_end) {
            u32 physical_addr = victim_frame * PAGE_SIZE;
            map_page(vaddr, physical_addr, PAGE_PRESENT | PAGE_WRITE);
            
            page_info[page_id].physical_frame = victim_frame;
            page_info[page_id].in_memory = true;
            page_info[page_id].insert_order = next_insert_order++;
            
            for (u32 i = 0; i < frame_count; i++) {
                if (test_frame_start + i == victim_frame) {
                    frame_occupied[i] = page_id;
                    frame_order[i] = page_info[page_id].insert_order;
                    break;
                }
            }
            
            manager->frames[victim_frame].reference_count = 1;
        }
    }
    
    console_printf("\n--- 测试结果 ---\n");
    console_printf("总访问次数: %u\n", FIFO_ACCESS_SEQUENCE_LENGTH);
    console_printf("缺页次数: %u\n", page_faults);
    console_printf("命中次数: %u\n", hits);
    console_printf("缺页率: %u%%\n", (page_faults * 100) / FIFO_ACCESS_SEQUENCE_LENGTH);
    
    console_printf("\n--- 最终页框状态 ---\n");
    for (u32 i = 0; i < frame_count; i++) {
        u32 frame_idx = test_frame_start + i;
        u32 page_id = frame_occupied[i];
        if (page_id != 0xFFFFFFFF) {
            console_printf("  页框 %d: 页面 %d (0x%x) [插入顺序: %u]\n", 
                          frame_idx, page_id, test_vaddrs[page_id], frame_order[i]);
        } else {
            console_printf("  页框 %d: 空闲\n", frame_idx);
        }
    }
    
    console_printf("\n--- 清理测试页框 ---\n");
    for (u32 i = 0; i < frame_count; i++) {
        u32 frame_idx = test_frame_start + i;
        if (frame_idx < manager->total_frames) {
            u32 page_id = frame_occupied[i];
            if (page_id != 0xFFFFFFFF) {
                page_entry_t* entry = get_page_entry(
                    page_info[page_id].virtual_addr, false);
                if (entry) *entry = 0;
            }
            manager->frames[frame_idx].status = PAGE_FREE;
            manager->frames[frame_idx].reference_count = 0;
        }
    }
    console_printf("测试完成，页框已清理\n");
}

void command_algo(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
    run_algo();
}

void command_memtest(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
    
    console_printf("=== 内存读写测试 ===\n");
    
    page_frame_manager_t* manager = get_page_frame_manager();
    
    if (manager->free_frames < 1) {
        console_printf("错误: 没有空闲内存\n");
        return;
    }
    
    u32 paddr = alloc_page_frame();
    if (paddr == 0) {
        console_printf("错误: 内存分配失败\n");
        return;
    }
    
    console_printf("分配物理地址: 0x%x\n", paddr);
    
    u32* ptr = (u32*)paddr;
    u32 write_value = 0x12345678;
    *ptr = write_value;
    
    console_printf("写入数据: 0x%x\n", write_value);
    console_printf("等待一段时间...\n");
    
    // 简单延时循环
    for (u32 i = 0; i < 1000000000; i++);
    
    u32 read_value = *ptr;
    
    console_printf("等待完成，读取数据: 0x%x\n", read_value);
    
    free_page_frame(paddr);
    
    console_printf("已释放内存: 0x%x\n", paddr);
    
    if (read_value == write_value) {
        console_printf("结果: 通过\n");
    } else {
        console_printf("结果: 失败\n");
    }
}

void command_exit(int argc, char* argv[]) {
    (void)argc;
    (void)argv;
    console_printf("系统已退出\n");
    while(1) {}
}