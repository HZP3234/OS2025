#ifndef __COMMAND_H__
#define __COMMAND_H__

#include "../lib/common.h"

//命令结构体
typedef struct{
    char* name;
    void (*handler)(int argc, char* argv[]);
} command_t;

void command_init(void);

//命令函数声明
void command_echo(int argc, char* argv[]);
void command_help(int argc, char* argv[]);
void command_alloc(int argc, char* argv[]);
void command_free(int argc, char* argv[]);
void command_list_alloc(int argc, char* argv[]);
void command_meminfo(int argc, char* argv[]);
void command_bitmap(int argc, char* argv[]);
void command_clock(int argc, char* argv[]);
void command_exit(int argc, char* argv[]);
void command_memtest(int argc, char* argv[]);
void command_lru(int argc, char* argv[]);
void command_fifo(int argc, char* argv[]);
void command_algo(int argc, char* argv[]);

void run_algo(void);

//命令解析函数
int parse_command(char* buffer, char* argv[]);

#endif