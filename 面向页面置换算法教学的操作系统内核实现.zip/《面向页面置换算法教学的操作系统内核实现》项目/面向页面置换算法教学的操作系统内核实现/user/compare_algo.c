#include "command.h"
#include "../mm/page.h"
#include "../kernel/kernel.h"
#include "../lib/common.h"
#include "../kernel/console.h"
#include "../lib/param.h"
#include "../file/fs.h"

#define FRAME_COUNT 6
#define MAX_ACCESS_SEQUENCE_LENGTH 100
#define MAX_PAGES 20
#define EXEC_LOOP_COUNT 5

typedef struct {
    char name[16];
    int page_fault;
    int page_hit;
    u32 fault_percent;
    int access_count;
} algo_result;

// 页面访问统计
typedef struct {
    u32 page_accessed[MAX_ACCESS_SEQUENCE_LENGTH];
    int current_index;
    int fault_count;
    int hit_count;
} page_access_stats;

// 全局变量存储用户输入的访问序列
static u32 user_access_sequence[MAX_ACCESS_SEQUENCE_LENGTH];
static int actual_sequence_length = 0;
static bool use_user_sequence = false;

// 简单的字符串转数字函数
u32 simple_atoi(const char* str) {
    u32 result = 0;
    while (*str >= '0' && *str <= '9') {
        result = result * 10 + (*str - '0');
        str++;
    }
    return result;
}

// 解析用户输入的访问序列
void parse_access_sequence(const char* input) {
    actual_sequence_length = 0;
    const char* ptr = input;
    
    while (*ptr && actual_sequence_length < MAX_ACCESS_SEQUENCE_LENGTH) {
        // 跳过空格
        while (*ptr == ' ' || *ptr == '\t') ptr++;
        
        if (*ptr == '\0' || *ptr == '\n' || *ptr == '\r') break;
        
        // 检查是否是"done"命令
        if (strncmp(ptr, "done", 4) == 0) {
            break;
        }
        
        // 解析数字
        u32 page_num = simple_atoi(ptr);
        if (page_num >= 1 && page_num <= MAX_PAGES) {
            user_access_sequence[actual_sequence_length++] = page_num;
        }
        
        // 移动到下一个数字
        while (*ptr >= '0' && *ptr <= '9') ptr++;
    }
}

// 为用户访问序列分配虚拟地址
void allocate_virtual_addresses(void) {
    console_print("\n=== 为访问序列分配虚拟地址 ===\n");
    
    // 获取页面管理器
    page_frame_manager_t* manager = get_page_frame_manager();
    u32 user_base = 0x60000000; // 用户空间基地址
    
    console_printf("页面基地址: 0x%x\n", user_base);
    console_printf("总共有 %d 个页面访问需要处理\n", actual_sequence_length);
    
    // 为每个唯一页面分配虚拟地址
    u32 allocated_pages[MAX_PAGES];
    for (int i = 0; i < MAX_PAGES; i++) {
        allocated_pages[i] = 0xFFFFFFFF; // 标记为未分配
    }
    
    u32 page_counter = 1;
    console_print("页面地址分配:\n");
    
    for (int i = 0; i < actual_sequence_length; i++) {
        u32 page_num = user_access_sequence[i];
        
        // 如果这个页面还没有分配地址
        if (allocated_pages[page_num - 1] == 0xFFFFFFFF) {
            u32 virtual_addr = user_base + (page_counter * PAGE_SIZE);
            allocated_pages[page_num - 1] = virtual_addr;
            
            console_printf("  页面 %d -> 虚拟地址 0x%x\n", page_num, virtual_addr);
            page_counter++;
        }
    }
    
    console_print("地址分配完成\n");
    console_print("=================================================\n\n");
}
void get_user_access_sequence(void) {
    console_print("\n=================================================\n");
    console_print("         页面访问序列输入\n");
    console_print("=================================================\n");
    
    console_print("请输入页面访问序列（页面编号，用空格分隔）:\n");
    console_print("例如: 1 2 3 4 5 1 2 6 1 2 7 8 9 7 8\n");
    console_print("支持的页面编号范围: 1-20\n");
    console_print("最大访问序列长度: 100\n");
    console_print("输入完成后请输入 'done' 结束输入\n");
    
    console_print("\n开始输入页面访问序列:\n");
    console_print("> ");
    
    // 读取用户输入的一行
    char input_buffer[512];
    console_readline(input_buffer, sizeof(input_buffer));
    
    console_printf("您输入的序列: %s\n", input_buffer);
    
    // 解析输入序列
    parse_access_sequence(input_buffer);
    
    // 如果用户没有输入任何数字，使用默认序列
    if (actual_sequence_length == 0) {
        console_print("\n未检测到有效输入，使用默认示例序列:\n");
        u32 default_sequence[] = {1, 2, 3, 4, 5, 1, 2, 6, 1, 2, 7, 8, 9, 7, 8, 3, 4, 5, 6, 1, 2, 3, 7, 8, 9};
        int default_length = sizeof(default_sequence) / sizeof(default_sequence[0]);
        
        if (default_length > MAX_ACCESS_SEQUENCE_LENGTH) {
            default_length = MAX_ACCESS_SEQUENCE_LENGTH;
        }
        
        for (int i = 0; i < default_length; i++) {
            user_access_sequence[i] = default_sequence[i];
        }
        actual_sequence_length = default_length;
    }
    
    // 显示解析结果
    console_print("\n解析后的访问序列: ");
    for (int i = 0; i < actual_sequence_length; i++) {
        console_printf("%d ", user_access_sequence[i]);
    }
    console_print("\n");
    
    console_printf("有效页面访问数量: %d\n", actual_sequence_length);
    console_print("=================================================\n\n");
    
    use_user_sequence = true;
}

// FIFO算法进程函数
void fifo_test_process(void) {
    algo_result result;
    (void)result;
    
    // 初始化结果结构
    strcpy(result.name, "FIFO");
    result.page_fault = 0;
    result.page_hit = 0;
    result.access_count = 0;
    
    console_print("FIFO进程开始执行页面置换测试...\n");
    
    // 获取页面管理器
    page_frame_manager_t* manager = get_page_frame_manager();
    
    // 为测试准备页帧
    u32 test_frame_start = manager->reserved_frames + 1;
    u32 test_frame_end = test_frame_start + FRAME_COUNT;
    
    console_printf("测试用物理页框范围: %u - %u\n", test_frame_start, test_frame_end - 1);
    
    // 清理测试页框
    for (u32 i = test_frame_start; i < test_frame_end; i++) {
        if (i < manager->total_frames) {
            manager->frames[i].status = PAGE_FREE;
            manager->frames[i].reference_count = 0;
        }
    }
    
    // 为每个页面创建地址映射
    u32 page_to_vaddr[MAX_PAGES + 1];
    u32 user_base = 0x60000000;
    for (int i = 1; i <= MAX_PAGES; i++) {
        page_to_vaddr[i] = user_base + (i * PAGE_SIZE);
    }
    
    // 页面状态跟踪
    typedef struct {
        u32 virtual_addr;
        u32 physical_frame;
        bool in_memory;
        u32 insert_order;
    } page_state_t;
    
    page_state_t page_states[MAX_PAGES + 1];
    for (int i = 1; i <= MAX_PAGES; i++) {
        page_states[i].virtual_addr = page_to_vaddr[i];
        page_states[i].physical_frame = 0xFFFFFFFF;
        page_states[i].in_memory = false;
        page_states[i].insert_order = 0xFFFFFFFF;
    }
    
    u32 frame_occupied[FRAME_COUNT];
    u32 frame_orders[FRAME_COUNT];
    for (int i = 0; i < FRAME_COUNT; i++) {
        frame_occupied[i] = 0xFFFFFFFF;
        frame_orders[i] = 0xFFFFFFFF;
    }
    
    u32 next_insert_order = 0;
    u32 next_free_slot = 0;
    
    // 获取当前要使用的访问序列长度
    int sequence_length = use_user_sequence ? actual_sequence_length : 30;
    
    console_print("\n=== 执行FIFO页面置换 ===\n");
    
    for (int i = 0; i < sequence_length; i++) {
        u32 page;
        
        if (use_user_sequence) {
            // 使用用户输入的访问序列
            page = user_access_sequence[i];
        } else {
            // 使用原有的硬编码序列生成逻辑
            if (i < sequence_length / 2) {
                // 前半部分使用正常序列
                page = i % 10 + 1;
            } else {
                int repeat_index = (i - sequence_length / 2) % 5;
                page = repeat_index + 1; // 只访问前5个页面
            }
        }
        
        console_printf("[访问 %d] 页面 %d: ", i + 1, page);
        
        // 检查页面是否已在内存中
        bool page_found = false;
        if (page_states[page].in_memory) {
            // 验证页表项确实存在
            page_entry_t* entry = get_page_entry(page_states[page].virtual_addr, false);
            if (entry && (*entry & PAGE_PRESENT)) {
                page_found = true;
                result.page_hit++;
                console_printf("命中 -> 页框 %d\n", page_states[page].physical_frame);
            }
        }
        
        if (!page_found) {
            // 页面错误，需要置换
            result.page_fault++;
            console_printf("缺页 -> ");
            
            u32 victim_frame;
            u32 victim_slot;
            
            if (next_free_slot < FRAME_COUNT) {
                // 有空闲页框
                victim_frame = test_frame_start + next_free_slot;
                victim_slot = next_free_slot;
                next_free_slot++;
                console_printf("使用空闲页框 %d\n", victim_frame);
            } else {
                // 需要置换 - 选择最早进入的页面
                u32 oldest_order = 0xFFFFFFFF;
                u32 oldest_slot = 0;
                
                for (int slot = 0; slot < FRAME_COUNT; slot++) {
                    if (frame_orders[slot] < oldest_order) {
                        oldest_order = frame_orders[slot];
                        oldest_slot = slot;
                    }
                }
                
                victim_frame = test_frame_start + oldest_slot;
                victim_slot = oldest_slot;
                
                u32 victim_page = frame_occupied[oldest_slot];
                console_printf("FIFO置换: 选择页面 %d (页框 %d, 插入顺序: %u) -> 页面 %d\n", 
                              victim_page, victim_frame, oldest_order, page);
                
                // 清理被置换的页面
                if (victim_page != 0xFFFFFFFF) {
                    page_states[victim_page].in_memory = false;
                    page_states[victim_page].physical_frame = 0xFFFFFFFF;
                    page_states[victim_page].insert_order = 0xFFFFFFFF;
                    
                    // 清除页表项
                    page_entry_t* victim_entry = get_page_entry(page_states[victim_page].virtual_addr, false);
                    if (victim_entry) *victim_entry = 0;
                }
            }
            
            // 加载新页面
            u32 virtual_addr = page_states[page].virtual_addr;
            u32 physical_addr = victim_frame * PAGE_SIZE;
            
            // 映射页面
            map_page(virtual_addr, physical_addr, PAGE_PRESENT | PAGE_WRITE);
            
            // 更新页面状态
            page_states[page].in_memory = true;
            page_states[page].physical_frame = victim_frame;
            page_states[page].insert_order = next_insert_order;
            
            // 更新页框状态
            frame_occupied[victim_slot] = page;
            frame_orders[victim_slot] = next_insert_order;
            
            // 更新物理页框状态
            if (victim_frame < manager->total_frames) {
                manager->frames[victim_frame].status = PAGE_USED;
                manager->frames[victim_frame].reference_count = 1;
            }
            
            next_insert_order++;
        }
        
        result.access_count++;
    }
    
    result.fault_percent = (result.page_fault * 100) / result.access_count;
    
    console_print("\n=== FIFO 算法测试结果 ===\n");
    console_printf("总访问次数: %d\n", result.access_count);
    console_printf("页面错误次数: %d\n", result.page_fault);
    console_printf("页面命中次数: %d\n", result.page_hit);
    console_printf("页面错误率: %d%%\n", result.fault_percent);
    
    console_print("\n=== 最终页框状态 (FIFO) ===\n");
    for (int i = 0; i < FRAME_COUNT; i++) {
        u32 frame_idx = test_frame_start + i;
        u32 page_id = frame_occupied[i];
        if (page_id != 0xFFFFFFFF) {
            console_printf("  页框 %d: 页面 %d (0x%x) [插入顺序: %u]\n", 
                          frame_idx, page_id, page_states[page_id].virtual_addr, frame_orders[i]);
        } else {
            console_printf("  页框 %d: 空闲\n", frame_idx);
        }
    }
    
    // 清理测试页框
    console_print("\n=== 清理测试页框 ===\n");
    for (int i = 0; i < FRAME_COUNT; i++) {
        u32 frame_idx = test_frame_start + i;
        if (frame_idx < manager->total_frames) {
            u32 page_id = frame_occupied[i];
            if (page_id != 0xFFFFFFFF) {
                page_entry_t* entry = get_page_entry(page_states[page_id].virtual_addr, false);
                if (entry) *entry = 0;
            }
            manager->frames[frame_idx].status = PAGE_FREE;
            manager->frames[frame_idx].reference_count = 0;
        }
    }
    
    // 将FIFO算法结果写入文件
    write_result(result.name, result.page_fault, result.page_hit, result.fault_percent, result.access_count);
    console_print("FIFO测试完成，页框已清理\n");
}

// LRU算法进程函数
void lru_test_process(void) {
    algo_result result;
    
    // 初始化结果结构
    strcpy(result.name, "LRU");
    result.page_fault = 0;
    result.page_hit = 0;
    result.access_count = 0;
    
    console_print("LRU进程开始执行页面置换测试...\n");
    
    // 多次重复测试
    for (int loop = 0; loop < EXEC_LOOP_COUNT; loop++) {
        // 每次循环都重新初始化算法
        lru_init(FRAME_COUNT);

        // 获取当前要使用的访问序列长度
        int sequence_length = use_user_sequence ? actual_sequence_length : 30;

        for (int i = 0; i < sequence_length; i++) {
            u32 page;
            
            if (use_user_sequence) {
                // 使用用户输入的访问序列
                page = user_access_sequence[i];
            } else {
                // 使用原有的硬编码序列生成逻辑
                // 对于LRU算法，我们创建局部性访问模式
                if (i < sequence_length / 2) {
                    // 前半部分正常访问
                    page = i % 10 + 1;
                } else {
                    int local_group = (i - sequence_length / 2) % 5;
                    page = local_group + 1; // 只访问前5个页面
                    
                    // 添加一个顺序访问的页面，让LRU可以更好地利用时间局部性
                    if (local_group % 2 == 0) {
                        page = 1; // 重复访问页面1
                    }
                }
            }
            
            u32 frame;
            bool page_found = false;
            
            // 查找页面是否已在内存中
            u32 frames[FRAME_COUNT];
            u32 vaddrs[FRAME_COUNT];
            u32 access_times[FRAME_COUNT];
            lru_get_state(frames, vaddrs, access_times);
            
            for (int j = 0; j < FRAME_COUNT; j++) {
                if (frames[j] != 0xFFFFFFFF && vaddrs[j] == page) {
                    page_found = true;
                    result.page_hit++;
                    lru_access_page(frames[j], page);
                    break;
                }
            }
            
            if (!page_found) {
                // 页面错误，需要置换
                result.page_fault++;
                
                // 尝试分配新帧
                frame = alloc_page_frame();
                if (frame == 0) {
                    frame = lru_replace();
                }
                lru_add_frame(frame, page);
                
                // 只在第一轮和最后一轮显示详细输出
                if (loop == 0 || loop == EXEC_LOOP_COUNT - 1) {
                    console_printf("LRU: 页面错误 - 页面 %d -> 帧 %d\n", page, frame);
                }
            } else {
                // 只在第一轮显示命中信息
                if (loop == 0) {
                    console_printf("LRU: 页面命中 - 页面 %d\n", page);
                }
            }           
            result.access_count++;
        }
        
        // 在每次循环结束时输出一些进度信息
        if (loop > 0 && loop < EXEC_LOOP_COUNT - 1) {
            console_printf("LRU: 已完成 %d/%d 轮测试\n", loop + 1, EXEC_LOOP_COUNT);
        }
    }
    
    result.fault_percent = (result.page_fault * 100) / result.access_count;
    
    console_print("\n=== LRU 算法测试结果 ===\n");
    console_printf("总访问次数: %d\n", result.access_count);
    console_printf("页面错误次数: %d\n", result.page_fault);
    console_printf("页面命中次数: %d\n", result.page_hit);
    console_printf("页面错误率: %d%%\n", result.fault_percent);
    
    // 将LRU算法结果写入文件
    write_result(result.name, result.page_fault, result.page_hit, result.fault_percent, result.access_count);
}

// CLOCK算法进程函数
void clock_test_process(void) {
    algo_result result;
    
    // 初始化结果结构
    strcpy(result.name, "CLOCK");
    result.page_fault = 0;
    result.page_hit = 0;
    result.access_count = 0;
    
    console_print("CLOCK进程开始执行页面置换测试...\n");
    
    // 多次重复测试
    for (int loop = 0; loop < EXEC_LOOP_COUNT; loop++) {
        // 每次循环都重新初始化算法
        clock_init(FRAME_COUNT);
        
        // 获取当前要使用的访问序列长度
        int sequence_length = use_user_sequence ? actual_sequence_length : 30;

        for (int i = 0; i < sequence_length; i++) {
            u32 page;
            
            if (use_user_sequence) {
                // 使用用户输入的访问序列
                page = user_access_sequence[i];
            } else {
                // 使用原有的硬编码序列生成逻辑
                // 对于CLOCK算法，我们创建一个不同的访问模式
                if (i < sequence_length / 2) {
                    // 前半部分正常访问
                    page = i % 10 + 1;
                } else {
                    int cycle_pos = (i - sequence_length / 2) % 5;
                    page = cycle_pos + 1; // 只访问前5个页面
                    if (cycle_pos % 2 == 0) {
                        page = 8; // 偶尔访问一个不同页面
                    }
                }
            }
            
            u32 frame;
            bool page_found = false;
            
            // 查找页面是否已在内存中
            u32 frames[FRAME_COUNT];
            u32 ref_bits[FRAME_COUNT];
            u32 hand;
            u32 vaddrs[FRAME_COUNT];
            clock_get_state(frames, ref_bits, &hand, vaddrs);
            
            for (int j = 0; j < FRAME_COUNT; j++) {
                if (frames[j] != 0xFFFFFFFF && vaddrs[j] == page) {
                    page_found = true;
                    result.page_hit++;
                    clock_mark_accessed(frames[j]);
                    break;
                }
            }
            
            if (!page_found) {
                // 页面错误，需要置换
                result.page_fault++;
                
                // 尝试分配新帧
                frame = alloc_page_frame();
                if (frame == 0) {
                    frame = clock_replace();
                }
                clock_add_frame(frame, page);
                
                // 只在第一轮和最后一轮显示详细输出
                if (loop == 0 || loop == EXEC_LOOP_COUNT - 1) {
                    console_printf("CLOCK: 页面错误 - 页面 %d -> 帧 %d\n", page, frame);
                }
            } else {
                // 只在第一轮显示命中信息
                if (loop == 0) {
                    console_printf("CLOCK: 页面命中 - 页面 %d\n", page);
                }
            }           
            result.access_count++;
        }
        
        // 在每次循环结束时输出一些进度信息
        if (loop > 0 && loop < EXEC_LOOP_COUNT - 1) {
            console_printf("CLOCK: 已完成 %d/%d 轮测试\n", loop + 1, EXEC_LOOP_COUNT);
        }
    }
    
    result.fault_percent = (result.page_fault * 100) / result.access_count;
    
    console_print("\n=== CLOCK 算法测试结果 ===\n");
    console_printf("总访问次数: %d\n", result.access_count);
    console_printf("页面错误次数: %d\n", result.page_fault);
    console_printf("页面命中次数: %d\n", result.page_hit);
    console_printf("页面错误率: %d%%\n", result.fault_percent);
    
    // 将CLOCK算法结果写入文件
    write_result(result.name, result.page_fault, result.page_hit, result.fault_percent, result.access_count);
}

void run_algo(void){
    console_print("\n=================================================\n");
    console_print("         页面置换算法性能比较演示\n");
    console_print("=================================================\n");  
    console_print("\n开始执行页面置换算法比较...\n\n");
    
    // 创建结果文件
    console_print("正在创建结果文件...\n");
    create_file();
    
    // 首先获取用户输入的访问序列
    get_user_access_sequence();
    
    // 为访问序列分配虚拟地址
    allocate_virtual_addresses();
    
    // 然后执行算法测试
    fifo_test_process();
    lru_test_process();
    clock_test_process();
    
    // 导出所有结果文件
    console_print("\n正在导出所有算法测试结果...\n");
    export_files();
    console_print("\n=================================================\n");
    console_print("             文件导出完成\n");
    console_print("         页面置换算法比较完成\n");
    console_print("=================================================\n");
}