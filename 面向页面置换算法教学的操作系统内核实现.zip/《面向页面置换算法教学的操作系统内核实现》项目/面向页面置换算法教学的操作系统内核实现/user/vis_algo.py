import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import random
import time
import threading
from typing import List, Tuple, Optional
import copy

class PageReplacementAlgorithm:
    """页面置换算法基类"""
    
    def __init__(self, frame_count: int):
        self.frame_count = frame_count
        self.frames = [-1] * frame_count  # -1表示空帧
        self.access_history = []
        self.fault_count = 0
        self.hit_count = 0
        self.current_time = 0
        
    def reset(self):
        """重置算法状态"""
        self.frames = [-1] * self.frame_count
        self.access_history = []
        self.fault_count = 0
        self.hit_count = 0
        self.current_time = 0
        
    def access_page(self, page: int) -> bool:
        """
        访问页面
        返回True表示缺页，False表示命中
        """
        self.current_time += 1
        
        # 检查是否命中
        if page in self.frames:
            self.hit_count += 1
            self._on_page_hit(page)
            result = False
        else:
            self.fault_count += 1
            result = True
            self._on_page_fault(page)
            
        # 记录访问历史
        self.access_history.append({
            'page': page,
            'is_fault': result,
            'frames_before': copy.deepcopy(self.frames),
            'frames_after': copy.deepcopy(self.frames)
        })
        
        return result
    
    def _on_page_hit(self, page: int):
        """页面命中时的处理（子类实现）"""
        pass
    
    def _on_page_fault(self, page: int):
        """缺页时的处理（子类实现）"""
        pass
    
    def get_fault_rate(self) -> float:
        """获取缺页率"""
        total = self.fault_count + self.hit_count
        return self.fault_count / total if total > 0 else 0.0

class FIFOAlgorithm(PageReplacementAlgorithm):
    """FIFO页面置换算法"""
    
    def __init__(self, frame_count: int):
        super().__init__(frame_count)
        self.queue = []  # 维护页面进入顺序
        self.insert_order = 0
        
    def reset(self):
        super().reset()
        self.queue = []
        self.insert_order = 0
        
    def _on_page_fault(self, page: int):
        """FIFO缺页处理"""
        if len(self.queue) < self.frame_count:
            # 有空闲帧
            self.frames[len(self.queue)] = page
            self.queue.append(page)
        else:
            # 需要置换：选择最早进入的页面
            victim = self.queue.pop(0)
            # 找到victim在frames中的位置
            for i in range(self.frame_count):
                if self.frames[i] == victim:
                    self.frames[i] = page
                    break
            self.queue.append(page)

class LRUAlgorithm(PageReplacementAlgorithm):
    """LRU页面置换算法"""
    
    def __init__(self, frame_count: int):
        super().__init__(frame_count)
        self.access_times = {}  # 记录每个页面的最后访问时间
        
    def reset(self):
        super().reset()
        self.access_times = {}
        
    def _on_page_hit(self, page: int):
        """LRU命中处理：更新访问时间"""
        self.access_times[page] = self.current_time
        
    def _on_page_fault(self, page: int):
        """LRU缺页处理"""
        if -1 in self.frames:
            # 有空闲帧
            for i in range(self.frame_count):
                if self.frames[i] == -1:
                    self.frames[i] = page
                    self.access_times[page] = self.current_time
                    break
        else:
            # 需要置换：选择最近最少使用的页面
            lru_page = min(self.access_times.keys(), key=lambda p: self.access_times[p])
            # 找到lru_page在frames中的位置
            for i in range(self.frame_count):
                if self.frames[i] == lru_page:
                    self.frames[i] = page
                    del self.access_times[lru_page]
                    self.access_times[page] = self.current_time
                    break

class CLOCKAlgorithm(PageReplacementAlgorithm):
    """CLOCK页面置换算法"""
    
    def __init__(self, frame_count: int):
        super().__init__(frame_count)
        self.ref_bits = [0] * frame_count  # 引用位
        self.hand = 0  # 时钟指针
        self.page_ref_bits = {}  # 记录每个页面的引用位
        
    def reset(self):
        super().reset()
        self.ref_bits = [0] * self.frame_count
        self.hand = 0
        self.page_ref_bits = {}
        
    def _on_page_hit(self, page: int):
        """CLOCK命中处理：设置引用位"""
        # 找到页面在frames中的位置
        for i in range(self.frame_count):
            if self.frames[i] == page:
                self.ref_bits[i] = 1
                self.page_ref_bits[page] = 1
                break
                
    def _on_page_fault(self, page: int):
        """CLOCK缺页处理"""
        if -1 in self.frames:
            # 有空闲帧
            for i in range(self.frame_count):
                if self.frames[i] == -1:
                    self.frames[i] = page
                    self.ref_bits[i] = 1
                    self.page_ref_bits[page] = 1
                    break
        else:
            # CLOCK算法置换
            while True:
                if self.ref_bits[self.hand] == 0:
                    # 引用位为0，置换此页
                    victim = self.frames[self.hand]
                    self.frames[self.hand] = page
                    self.ref_bits[self.hand] = 1
                    self.page_ref_bits[page] = 1
                    if victim in self.page_ref_bits:
                        del self.page_ref_bits[victim]
                    break
                else:
                    # 引用位为1，清除并继续
                    self.ref_bits[self.hand] = 0
                
                self.hand = (self.hand + 1) % self.frame_count

class DataGenerator:
    """模拟数据生成器"""
    
    @staticmethod
    def generate_random_sequence(length: int, page_range: int) -> List[int]:
        """生成随机访问序列"""
        return [random.randint(1, page_range) for _ in range(length)]
    
    @staticmethod
    def generate_locality_sequence(length: int, page_range: int, locality_size: int = 5) -> List[int]:
        """生成具有局部性的访问序列"""
        sequence = []
        current_locality = random.randint(1, page_range - locality_size + 1)
        
        for i in range(length):
            if random.random() < 0.8:  # 80%概率在当前局部范围内
                sequence.append(current_locality + random.randint(0, locality_size - 1))
            else:  # 20%概率跳转到新的局部范围
                current_locality = random.randint(1, page_range - locality_size + 1)
                sequence.append(current_locality + random.randint(0, locality_size - 1))
                
        return sequence
    
    @staticmethod
    def generate_sequential_sequence(length: int, page_range: int) -> List[int]:
        """生成顺序访问序列"""
        return [(i % page_range) + 1 for i in range(length)]

class PageReplacementVisualizer:
    """页面置换算法可视化器"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("页面置换算法动画演示")
        self.root.geometry("2000x1200")
        
        # 算法实例
        self.algorithms = {
            'FIFO': FIFOAlgorithm(4),
            'LRU': LRUAlgorithm(4), 
            'CLOCK': CLOCKAlgorithm(4)
        }
        
        # 当前算法
        self.current_algorithm = 'FIFO'
        
        # 访问序列
        self.access_sequence = []
        self.current_step = 0
        
        # 动画控制
        self.is_playing = False
        self.animation_speed = 1000  # 毫秒
        self.animation_thread = None
        
        # 创建界面
        self.create_widgets()
        
        # 生成默认数据
        self.generate_default_data()
    
    def create_widgets(self):
        """创建界面组件"""
        # 主框架
        main_frame = ttk.Frame(self.root, padding="25")
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # 配置网格权重
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        
        # 设置默认字体大小
        style = ttk.Style()
        style.configure('Large.TLabel', font=('Arial', 18))
        style.configure('Large.TButton', font=('Arial', 16))
        style.configure('Large.TCombobox', font=('Arial', 16))
        style.configure('Large.TSpinbox', font=('Arial', 16))
        
        # 控制面板
        control_frame = ttk.LabelFrame(main_frame, text="控制面板", padding="20")
        control_frame.grid(row=0, column=0, columnspan=2, sticky=(tk.W, tk.E), pady=(0, 20))
        
        # 算法选择
        ttk.Label(control_frame, text="算法:", style='Large.TLabel').grid(row=0, column=0, sticky=tk.W, padx=(0, 15))
        self.algo_var = tk.StringVar(value="FIFO")
        self.algo_combo = ttk.Combobox(control_frame, textvariable=self.algo_var, 
                                      values=list(self.algorithms.keys()), state="readonly", width=35)
        self.algo_combo.grid(row=0, column=1, padx=(0, 40))
        self.algo_combo.bind('<<ComboboxSelected>>', self.on_algorithm_change)
        
        # 帧数设置
        ttk.Label(control_frame, text="页帧数:", style='Large.TLabel').grid(row=0, column=2, sticky=tk.W, padx=(0, 15))
        self.frame_var = tk.IntVar(value=4)
        frame_spinbox = ttk.Spinbox(control_frame, from_=3, to=8, textvariable=self.frame_var, width=15)
        frame_spinbox.grid(row=0, column=3, padx=(0, 40))
        frame_spinbox.bind('<<Increment>>', self.on_frame_count_change)
        frame_spinbox.bind('<<Decrement>>', self.on_frame_count_change)
        
        # 数据生成
        ttk.Label(control_frame, text="数据生成:", style='Large.TLabel').grid(row=0, column=4, sticky=tk.W, padx=(0, 15))
        self.data_type_var = tk.StringVar(value="随机")
        data_combo = ttk.Combobox(control_frame, textvariable=self.data_type_var,
                                 values=["随机", "局部性", "顺序"], state="readonly", width=20)
        data_combo.grid(row=0, column=5, padx=(0, 15))
        
        ttk.Label(control_frame, text="长度:", style='Large.TLabel').grid(row=0, column=6, sticky=tk.W, padx=(30, 15))
        self.length_var = tk.IntVar(value=20)
        length_spinbox = ttk.Spinbox(control_frame, from_=10, to=100, textvariable=self.length_var, width=15)
        length_spinbox.grid(row=0, column=7, padx=(0, 15))
        
        ttk.Button(control_frame, text="生成数据", style='Large.TButton', command=self.generate_data).grid(row=0, column=8, padx=(40, 0))
        
        # 动画控制
        animation_frame = ttk.Frame(control_frame)
        animation_frame.grid(row=1, column=0, columnspan=9, pady=(30, 0), sticky=(tk.W, tk.E))
        
        self.play_button = ttk.Button(animation_frame, text="播放", style='Large.TButton', command=self.toggle_animation)
        self.play_button.pack(side=tk.LEFT, padx=(0, 30))
        
        self.step_button = ttk.Button(animation_frame, text="单步", style='Large.TButton', command=self.step_forward)
        self.step_button.pack(side=tk.LEFT, padx=(0, 30))
        
        self.reset_button = ttk.Button(animation_frame, text="重置", style='Large.TButton', command=self.reset_simulation)
        self.reset_button.pack(side=tk.LEFT, padx=(0, 30))
        
        ttk.Label(animation_frame, text="速度:", style='Large.TLabel').pack(side=tk.LEFT, padx=(40, 15))
        self.speed_var = tk.DoubleVar(value=1.0)
        speed_scale = ttk.Scale(animation_frame, from_=0.1, to=3.0, 
                               variable=self.speed_var, orient=tk.HORIZONTAL, length=300)
        speed_scale.pack(side=tk.LEFT, padx=(0, 30))
        self.speed_label = ttk.Label(animation_frame, text="1.0x", style='Large.TLabel')
        self.speed_label.pack(side=tk.LEFT)
        
        speed_scale.configure(command=self.on_speed_change)
        
        # 显示区域
        display_frame = ttk.Frame(main_frame)
        display_frame.grid(row=1, column=0, columnspan=2, sticky=(tk.W, tk.E, tk.N, tk.S), pady=(0, 20))
        main_frame.rowconfigure(1, weight=1)
        
        # 算法显示区域
        algo_display_frame = ttk.LabelFrame(display_frame, text="算法演示", padding="20")
        algo_display_frame.pack(fill=tk.BOTH, expand=True, padx=(0, 20))
        
        # 创建画布用于绘制
        self.canvas = tk.Canvas(algo_display_frame, bg="white", height=800)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        # 统计信息面板
        stats_frame = ttk.LabelFrame(main_frame, text="统计信息", padding="20")
        stats_frame.grid(row=2, column=0, columnspan=2, sticky=(tk.W, tk.E))
        
        # 状态显示
        self.status_var = tk.StringVar(value="就绪")
        status_label = ttk.Label(stats_frame, textvariable=self.status_var, style='Large.TLabel')
        status_label.pack(side=tk.LEFT)
        
        # 统计信息
        self.stats_var = tk.StringVar(value="缺页: 0 | 命中: 0 | 缺页率: 0.0%")
        stats_label = ttk.Label(stats_frame, textvariable=self.stats_var, style='Large.TLabel')
        stats_label.pack(side=tk.RIGHT)
        
        # 绑定窗口关闭事件
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
    
    def generate_default_data(self):
        """生成默认数据"""
        self.access_sequence = DataGenerator.generate_random_sequence(20, 10)
        self.current_step = 0
        self.reset_simulation()
        self.update_display()
    
    def generate_data(self):
        """根据设置生成数据"""
        data_type = self.data_type_var.get()
        length = self.length_var.get()
        
        if data_type == "随机":
            self.access_sequence = DataGenerator.generate_random_sequence(length, 10)
        elif data_type == "局部性":
            self.access_sequence = DataGenerator.generate_locality_sequence(length, 15)
        elif data_type == "顺序":
            self.access_sequence = DataGenerator.generate_sequential_sequence(length, 8)
        
        self.current_step = 0
        self.reset_simulation()
        self.update_display()
    
    def on_algorithm_change(self, event=None):
        """算法选择改变"""
        self.current_algorithm = self.algo_var.get()
        self.reset_simulation()
        self.update_display()
    
    def on_frame_count_change(self, event=None):
        """帧数改变"""
        frame_count = self.frame_var.get()
        for algo in self.algorithms.values():
            algo.frame_count = frame_count
            algo.reset()
        self.current_step = 0
        self.update_display()
    
    def on_speed_change(self, value):
        """速度改变"""
        self.speed_label.config(text=f"{float(value):.1f}x")
    
    def toggle_animation(self):
        """切换动画播放状态"""
        if self.is_playing:
            self.stop_animation()
        else:
            self.start_animation()
    
    def start_animation(self):
        """开始动画"""
        if not self.access_sequence:
            messagebox.showwarning("警告", "请先生成访问序列")
            return
        
        self.is_playing = True
        self.play_button.config(text="暂停")
        self.run_animation()
    
    def stop_animation(self):
        """停止动画"""
        self.is_playing = False
        self.play_button.config(text="播放")
    
    def run_animation(self):
        """运行动画"""
        def animate():
            while self.is_playing and self.current_step < len(self.access_sequence):
                self.step_forward()
                time.sleep(self.animation_speed / self.speed_var.get())
            
            self.stop_animation()
        
        self.animation_thread = threading.Thread(target=animate, daemon=True)
        self.animation_thread.start()
    
    def step_forward(self):
        """单步执行"""
        if self.current_step >= len(self.access_sequence):
            return
        
        # 获取当前页面访问
        page = self.access_sequence[self.current_step]
        
        # 执行算法
        algo = self.algorithms[self.current_algorithm]
        is_fault = algo.access_page(page)
        
        # 更新状态
        self.current_step += 1
        self.status_var.set(f"访问页面 {page} {'→ 缺页!' if is_fault else '→ 命中!'}")
        
        # 更新显示
        self.update_display()
        
        # 如果到达末尾，停止动画
        if self.current_step >= len(self.access_sequence):
            self.stop_animation()
            self.status_var.set("演示完成")
    
    def reset_simulation(self):
        """重置模拟"""
        self.stop_animation()
        for algo in self.algorithms.values():
            algo.reset()
        self.current_step = 0
        self.status_var.set("已重置")
        self.update_display()
    
    def update_display(self):
        """更新显示"""
        self.canvas.delete("all")
        
        if not self.access_sequence:
            return
        
        # 绘制页面访问序列
        self.draw_access_sequence()
        
        # 绘制当前算法的状态
        self.draw_algorithm_state()
        
        # 更新统计信息
        algo = self.algorithms[self.current_algorithm]
        fault_rate = algo.get_fault_rate() * 100
        self.stats_var.set(f"缺页: {algo.fault_count} | 命中: {algo.hit_count} | 缺页率: {fault_rate:.1f}%")
    
    def draw_access_sequence(self):
        """绘制访问序列"""
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        if canvas_width <= 1:
            return
        
        # 序列显示区域
        sequence_y = 20
        sequence_height = 60
        
        # 绘制背景
        self.canvas.create_rectangle(10, sequence_y, canvas_width-10, sequence_y + sequence_height, 
                                   fill="#f0f0f0", outline="#ccc")
        
        # 绘制访问序列
        if self.access_sequence:
            cell_width = (canvas_width - 40) / len(self.access_sequence)
            max_cells = min(len(self.access_sequence), 50)  # 最多显示50个
            
            for i in range(max_cells):
                x = 20 + i * cell_width
                page = self.access_sequence[i]
                
                # 颜色：当前步骤高亮，已访问为蓝色，待访问为灰色
                if i < self.current_step:
                    fill_color = "#4CAF50"  # 绿色表示已访问
                elif i == self.current_step:
                    fill_color = "#FF9800"  # 橙色表示当前访问
                else:
                    fill_color = "#E0E0E0"  # 灰色表示待访问
                
                self.canvas.create_rectangle(x, sequence_y + 10, 
                                           x + cell_width - 2, sequence_y + sequence_height - 10,
                                           fill=fill_color, outline="#666")
                
                # 绘制页面号
                self.canvas.create_text(x + cell_width/2, sequence_y + sequence_height/2,
                                      text=str(page), font=("Arial", 22))
        
        # 绘制标题
        self.canvas.create_text(canvas_width/2, sequence_y + 5, text="页面访问序列", 
                              font=("Arial", 24, "bold"))
    
    def draw_algorithm_state(self):
        """绘制算法状态"""
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        
        if canvas_width <= 1:
            return
        
        # 算法状态显示区域
        algo_y = 120
        algo_height = canvas_height - algo_y - 20
        
        # 绘制标题
        title_text = f"{self.current_algorithm} 算法 - 当前步骤: {self.current_step}/{len(self.access_sequence)}"
        self.canvas.create_text(canvas_width/2, algo_y, text=title_text, 
                              font=("Arial", 22, "bold"))
        
        # 获取当前算法状态
        algo = self.algorithms[self.current_algorithm]
        
        # 绘制页帧
        frame_width = 100
        frame_height = 80
        frame_spacing = 25
        total_width = self.frame_var.get() * frame_width + (self.frame_var.get() - 1) * frame_spacing
        start_x = (canvas_width - total_width) / 2
        
        for i in range(self.frame_var.get()):
            x = start_x + i * (frame_width + frame_spacing)
            y = algo_y + 30
            
            # 绘制帧边框
            frame_color = "#2196F3" if i < len(algo.frames) and algo.frames[i] != -1 else "#ccc"
            self.canvas.create_rectangle(x, y, x + frame_width, y + frame_height,
                                       fill="white", outline=frame_color, width=2)
            
            # 绘制页帧内容
            if i < len(algo.frames) and algo.frames[i] != -1:
                page = algo.frames[i]
                
                # 页面号
                self.canvas.create_text(x + frame_width/2, y + frame_height/2 - 15,
                                      text=f"页面 {page}", font=("Arial", 16, "bold"))
                
                # 特殊算法信息
                if self.current_algorithm == "CLOCK" and i < len(algo.ref_bits):
                    ref_bit = algo.ref_bits[i]
                    self.canvas.create_text(x + frame_width/2, y + frame_height/2 + 15,
                                          text=f"引用位: {ref_bit}", font=("Arial", 14))
                
                # 如果是当前访问的页面，高亮显示
                if (self.current_step < len(self.access_sequence) and 
                    page == self.access_sequence[self.current_step]):
                    self.canvas.create_rectangle(x-3, y-3, x + frame_width + 3, y + frame_height + 3,
                                               outline="#FF5722", width=4)
            
            # 帧编号
            self.canvas.create_text(x + frame_width/2, y + frame_height + 20,
                                  text=f"帧 {i}", font=("Arial", 14))
        
        # 绘制算法特定信息
        self.draw_algorithm_info(algo_y + 120, canvas_width)
    
    def draw_algorithm_info(self, start_y, canvas_width):
        """绘制算法特定信息"""
        info_texts = []
        
        algo = self.algorithms[self.current_algorithm]
        
        if self.current_algorithm == "CLOCK":
            info_texts.append(f"时钟指针位置: {algo.hand}")
        elif self.current_algorithm == "LRU":
            if algo.access_times:
                lru_page = min(algo.access_times.keys(), key=lambda p: algo.access_times[p])
                info_texts.append(f"最近最少使用页面: {lru_page}")
        
        # 绘制信息文本
        for i, text in enumerate(info_texts):
            self.canvas.create_text(canvas_width/2, start_y + i * 30, text=text, 
                                  font=("Arial", 16))
    
    def on_closing(self):
        """窗口关闭事件"""
        self.stop_animation()
        self.root.destroy()
    
    def run(self):
        """运行程序"""
        self.root.mainloop()

if __name__ == "__main__":
    # 设置随机种子以获得可重现的结果
    random.seed(42)
    
    # 创建并运行可视化器
    app = PageReplacementVisualizer()
    app.run()