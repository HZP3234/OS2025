#include "kernel.h"
#include "../lib/common.h"
#include "console.h"
#include "../mm/page.h"
#include "../mm/vmm.h"

// 定义键盘输入缓冲区大小
#define KEYBOARD_BUFFER_SIZE 256

// 键盘输入缓冲区
static char keyboard_buffer[KEYBOARD_BUFFER_SIZE];
static int keyboard_buffer_head = 0;
static int keyboard_buffer_tail = 0;

static const char scancode_to_ascii[] = {
    0,  27, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n', 0,
    'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`', 0, '\\',
    'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0, '*', 0, ' '
};

// 修正中断描述符表结构（符合x86 32位中断门规范）
typedef struct {
    u16 base_low;       // 中断处理函数地址低16位
    u16 sel;            // 段选择子（内核代码段）
    u8  reserved;       // 保留位（必须为0）
    u8  access;         // 访问标志（0x8E表示32位中断门）
    u16 base_high;      // 中断处理函数地址高16位
} idt_entry_t;

// IDT寄存器结构
typedef struct {
    u16 limit;          // IDT界限
    u32 base;           // IDT基地址
} idtr_t;

// 声明IDT和IDTR
static idt_entry_t idt[256];
static idtr_t idtr;

// 外部汇编中断处理函数
extern void isr0();    // 除法错误
extern void isr14();   // 页错误
extern void isr32();   // 时钟中断
extern void isr33();   // 键盘中断
extern void isr_common_stub();  // 通用中断处理入口

// 初始化PIC（可编程中断控制器）
void pic_init() {
    // 初始化主从PIC
    outb(0x20, 0x11);    // 主PIC: 初始化命令
    outb(0xA0, 0x11);    // 从PIC: 初始化命令
    outb(0x21, 0x20);    // 主PIC: 中断向量偏移32
    outb(0xA1, 0x28);    // 从PIC: 中断向量偏移40
    outb(0x21, 0x04);    // 主PIC: 级联到从PIC
    outb(0xA1, 0x02);    // 从PIC: 连接到主PIC IRQ2
    outb(0x21, 0x01);    // 主PIC: 8086模式
    outb(0xA1, 0x01);    // 从PIC: 8086模式

    // 启用IRQ0（时钟中断）和IRQ1（键盘中断）
    outb(0x21, 0xFD);    // 主PIC: 启用IRQ0和IRQ1
    outb(0xA1, 0xFF);    // 从PIC: 禁用所有中断
}

// 设置IDT项
static void idt_set_gate(u8 num, u32 base, u16 sel, u8 flags) {
    idt[num].base_low = (base & 0xFFFF);         // 低16位地址
    idt[num].base_high = (base >> 16) & 0xFFFF;  // 高16位地址
    idt[num].sel = sel;                          // 段选择子（内核代码段0x08）
    idt[num].reserved = 0;                       // 保留位清零
    idt[num].access = flags;                     // 中断门属性
}

// 初始化中断描述符表
void idt_init() {
    idtr.limit = sizeof(idt_entry_t) * 256 - 1;
    idtr.base = (u32)&idt;

    // 初始化所有IDT项为0
    for (int i = 0; i < 256; i++) {
        idt_set_gate(i, 0, 0, 0);
    }

    // 设置特定中断（0x8E表示32位中断门、内核级、存在）
    idt_set_gate(0, (u32)isr0, 0x08, 0x8E);     // 除法错误
    idt_set_gate(14, (u32)isr14, 0x08, 0x8E);   // 页错误
    idt_set_gate(32, (u32)isr32, 0x08, 0x8E);   // 时钟中断
    idt_set_gate(33, (u32)isr33, 0x08, 0x8E);   // 键盘中断

    // 加载IDT
    asm volatile("lidt %0" : : "m"(idtr));
}

// 初始化PIT时钟
void pit_init(u32 frequency) {
    // 限制频率范围（1Hz - 1193180Hz）
    if (frequency < 1) frequency = 1;
    if (frequency > 1193180) frequency = 1193180;
    
    u32 divisor = 1193180 / frequency;
    
    outb(0x43, 0x36);              // 控制字：方波模式
    outb(0x40, divisor & 0xFF);    // 低8位除数
    outb(0x40, (divisor >> 8) & 0xFF);  // 高8位除数
}

// 页错误处理（修正CR2获取方式）
void page_fault_handler(u32 error_code) {
    u32 cr2;
    asm volatile("mov %%cr2, %0" : "=r"(cr2));

    vmm_page_fault_handler(cr2, error_code);
}

// 键盘中断处理
void keyboard_interrupt_handler() {
    u8 scancode = inb(0x60);
    bool is_release = (scancode & 0x80);  // 释放码标记
    
    if (!is_release) {  // 仅处理按下事件
        char c = scancode_to_ascii[scancode & 0x7F];
        if (c != 0) {  // 有效字符
            int next_head = (keyboard_buffer_head + 1) % KEYBOARD_BUFFER_SIZE;
            if (next_head != keyboard_buffer_tail) {  // 缓冲区未满
                keyboard_buffer[keyboard_buffer_head] = c;
                keyboard_buffer_head = next_head;
            }
        }
    }
    
    outb(0x20, 0x20);  // 发送EOI
}

// 获取键盘缓冲区中的字符（供console_read_char调用）
char get_keyboard_char() {
    if (keyboard_buffer_head != keyboard_buffer_tail) {
        char c = keyboard_buffer[keyboard_buffer_tail];
        keyboard_buffer_tail = (keyboard_buffer_tail + 1) % KEYBOARD_BUFFER_SIZE;
        return c;
    }
    return 0; // 缓冲区为空
}

// 时钟中断处理
void clock_interrupt_handler() {
    static u32 tick = 0;
    tick++;
    
    // 发送EOI（中断结束信号）
    outb(0x20, 0x20);
}

// 通用中断处理函数（修正参数传递方式）
void isr_handler(u32 interrupt_number, u32 error_code) {
    switch (interrupt_number) {
        case 14:  // 页错误
            page_fault_handler(error_code);
            break;
        case 32:  // 时钟中断
            clock_interrupt_handler();
            break;
        case 33:  // 键盘中断
            keyboard_interrupt_handler();
            break;
        default:
            // 未知中断，直接发送EOI
            outb(0x20, 0x20);  // 发送EOI
            break;
    }
}

// 初始化中断系统
void interrupt_init() {
    idt_init();    // 初始化IDT
    pic_init();    // 初始化PIC
    // pit_init(1); // 初始化PIT（1Hz）
    asm volatile("sti");  // 启用中断
    console_printf("中断系统初始化完成\n");
}