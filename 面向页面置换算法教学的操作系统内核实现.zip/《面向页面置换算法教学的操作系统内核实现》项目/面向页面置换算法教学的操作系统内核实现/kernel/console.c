#include "console.h"
#include "../lib/common.h"
#include <stdarg.h>
#include <stdint.h>

// 串口端口定义
#define COM_PORT 0x3F8

// 控制台状态
static console_state_t console;

// 检查串口是否就绪
static bool serial_received(void) {
    return inb(COM_PORT + 5) & 1;
}

static bool is_transmit_empty(void) {
    return inb(COM_PORT + 5) & 0x20;
}

// 初始化控制台
void console_init(void){
    outb(COM_PORT + 1, 0x00); // 禁用中断
    outb(COM_PORT + 3, 0x80); // 启用DLAB
    outb(COM_PORT + 0, 0x03); // 设置波特率为38400
    outb(COM_PORT + 1, 0x00); // 波特率高位
    outb(COM_PORT + 3, 0x03); // 8位数据,1位停止位
    outb(COM_PORT + 2, 0xC7); // 启用FIFO,清除FIFO,14字节触发
    outb(COM_PORT + 4, 0x0B); // 启用IRQs,启用接收中断

    console.initialized = true;
    console.row = 0;
    console.column = 0;
}

// 向串口输出一个字符
void console_write_char(char c) {
    if (!console.initialized) {
        return;
    }
    while (!is_transmit_empty());
    outb(COM_PORT, c);

    // 更新控制台位置
    if (c == '\n') {
        console.row++;
        console.column = 0;
    } else {
        console.column++;
        if (console.column >= 80) {
            console.row++;
            console.column = 0;
        }
    }
}

// 从串口中读取一个字符
char console_read_char(void){
    if (!console.initialized) {
        return '\0';
    }
    
    // 首先检查键盘缓冲区是否有字符
    char c = get_keyboard_char();
    if (c != 0) {
        return c;
    }
    
    // 如果键盘缓冲区为空，继续从串口读取
    while (!serial_received());
    return (char)inb(COM_PORT);
}

// 输出字符串到控制台
void console_print(const char* str) {
    if (!console.initialized || !str) {
        return;
    }

    while (*str) {
        console_write_char(*str);
        str++;
    }
}

// 读取一行输入
void console_readline(char* buffer, size_t size) {
    if (!console.initialized || !buffer || size == 0) {
        return;
    }

    size_t index = 0;
    while (index < size - 1) {
        char c = console_read_char();

        // 处理回车键
        if(c=='\r' || c=='\n'){
            console_write_char('\n');
            buffer[index] = '\0';
            return;
        }

        // 处理退格键
        if(c=='\b' || c==127){
            if(index>0){
                index--;
                console_write_char('\b');
                console_write_char(' ');
                console_write_char('\b');
            }
            continue;
        }

        // 处理普通字符
        if(c>=32 && c<=126){
            buffer[index++] = c;
            console_write_char(c);
        }
    }
    buffer[size-1] = '\0';
}

// 清空控制台
void console_clear(void){
    if (!console.initialized) {
        return;
    }
    console_print("\033[2J\033[H");
    console.row = 0;
    console.column = 0;
}

// 将数字转换为字符串（支持十进制）
void itoa(int value, char* buffer, int base) {
    char digits[] = "0123456789";
    char temp[32];
    int i = 0;
    int is_negative = 0;
    
    // 处理0
    if (value == 0) {
        buffer[0] = '0';
        buffer[1] = '\0';
        return;
    }
    
    // 处理负数
    if (value < 0 && base == 10) {
        is_negative = 1;
        value = -value;
    }
    
    // 转换数字
    while (value > 0) {
        temp[i++] = digits[value % base];
        value /= base;
    }
    
    // 添加负号
    if (is_negative) {
        temp[i++] = '-';
    }
    
    // 反转字符串
    int j = 0;
    while (i > 0) {
        buffer[j++] = temp[--i];
    }
    buffer[j] = '\0';
}

// 将无符号数字转换为十六进制字符串
static void utoa_hex(uint32_t value, char* buffer) {
    static char digits[] = "0123456789ABCDEF";
    char temp[32];
    int i = 0;
    
    if (value == 0) {
        buffer[0] = '0';
        buffer[1] = '\0';
        return;
    }
    
    while (value > 0) {
        temp[i++] = digits[value & 0xF];
        value >>= 4;
    }
    
    // 反转字符串
    int j = 0;
    while (i > 0) {
        buffer[j++] = temp[--i];
    }
    buffer[j] = '\0';
}

// 公共函数：将字符串安全地复制到缓冲区
static void safe_strcpy(char* dest, const char* src, size_t* dest_len, size_t max_len) {
    while (*src && *dest_len < max_len - 1) {
        dest[(*dest_len)++] = *src++;
    }
}

// 格式化输出
void console_printf(const char* format, ...) {
    if (!console.initialized || !format) {
        return;
    }
    
    va_list args;
    va_start(args, format);
    
    char buffer[256];
    size_t length = 0;
    const char* p = format;
    
    while (*p && length < sizeof(buffer) - 1) {
        if (*p == '%') {
            p++;
            
            if (*p == '\0') break; // 格式字符串意外结束
            
            switch (*p) {
                case 'd': {
                    int value = va_arg(args, int);
                    char num_buffer[32];
                    itoa(value, num_buffer, 10);
                    
                    safe_strcpy(buffer, num_buffer, &length, sizeof(buffer));
                    break;
                }
                case 'u': {
                    unsigned int value = va_arg(args, unsigned int);
                    char num_buffer[32];
                    
                    // 简单实现无符号整数转字符串
                    unsigned int temp = value;
                    int i = 0;
                    
                    if (temp == 0) {
                        num_buffer[i++] = '0';
                    }
                    
                    while (temp > 0) {
                        num_buffer[i++] = (temp % 10) + '0';
                        temp /= 10;
                    }
                    
                    // 反转字符串
                    char rev_buffer[32];
                    int j = 0;
                    while (i > 0) {
                        rev_buffer[j++] = num_buffer[--i];
                    }
                    rev_buffer[j] = '\0';
                    
                    safe_strcpy(buffer, rev_buffer, &length, sizeof(buffer));
                    break;
                }
                case 'x': {
                    uint32_t value = va_arg(args, uint32_t);
                    char num_buffer[32];
                    utoa_hex(value, num_buffer);
                    
                    safe_strcpy(buffer, num_buffer, &length, sizeof(buffer));
                    break;
                }
                case 's': {
                    char* str = va_arg(args, char*);
                    if (!str) str = "(null)";
                    
                    safe_strcpy(buffer, str, &length, sizeof(buffer));
                    break;
                }
                case 'c': {
                    char ch = (char)va_arg(args, int);
                    if (length < sizeof(buffer) - 1) {
                        buffer[length++] = ch;
                    }
                    break;
                }
                case '%': {
                    if (length < sizeof(buffer) - 1) {
                        buffer[length++] = '%';
                    }
                    break;
                }
                default: {
                    // 未知格式符，直接输出
                    if (length < sizeof(buffer) - 1) {
                        buffer[length++] = '%';
                        buffer[length++] = *p;
                    }
                    break;
                }
            }
            p++;
        } else {
            if (length < sizeof(buffer) - 1) {
                buffer[length++] = *p;
            }
            p++;
        }
    }
    
    buffer[length] = '\0';
    console_print(buffer);
    va_end(args);
}

// 文件导出专用输出函数 - 直接输出到stdout
void console_export_print(const char* str) {
    if (!str) {
        return;
    }
    
    // 使用内核兼容的方式输出
    console_print(str);
}