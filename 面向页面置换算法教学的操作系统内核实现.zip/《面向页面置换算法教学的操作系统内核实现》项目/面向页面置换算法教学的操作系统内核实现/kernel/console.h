#ifndef CONSOLE_H
#define CONSOLE_H

#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <stdbool.h>
#include "../lib/common.h"

//控制台状态结构
typedef struct {
    bool initialized;
    int row;
    int column;
} console_state_t;

//控制台函数声明
void console_init(void);
void console_write_char(char c);
char console_read_char(void);
void console_print(const char* str);
void console_printf(const char* format, ...);
void console_readline(char* buffer, size_t size);
void console_clear(void);
char get_keyboard_char(void);
void console_export_print(const char* str);

#endif
