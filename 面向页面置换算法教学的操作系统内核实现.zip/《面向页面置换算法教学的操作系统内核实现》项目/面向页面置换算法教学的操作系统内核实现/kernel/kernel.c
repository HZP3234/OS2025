#include "kernel.h"
#include "../lib/common.h"
#include "console.h"
#include "../lib/param.h"
#include "../mm/page.h"
#include "../mm/bitmap.h"
#include "../mm/vmm.h"
#include "../user/command.h"

kernel_t kernel_state = {
    .initialized = false,
    .memory_size = 0,
    .free_memory = 0,
    .used_memory = 0,
    .tick_count = 0
};

// 获取内核状态
kernel_t* get_kernel_state(void) {
    return &kernel_state;
}

// 物理内存初始化
void physical_memory_init(u32 total_memory) {
    console_printf("物理内存总量: %d MB\n", total_memory / 1024 / 1024);
    
    page_frame_init();
    bitmap_init();
    
    page_frame_manager_t* fm = get_page_frame_manager();
    u32 user_frames = fm->total_frames - fm->reserved_frames;
    console_printf("初始化 CLOCK 置换算法，用户可用页帧: %u\n", user_frames);
    clock_init(user_frames);
    
    vmm_init();
    
    console_printf("物理内存管理初始化完成\n");
    console_printf("已使用内存: %d KB\n", kernel_state.used_memory / 1024);
    console_printf("空闲内存: %d KB\n", kernel_state.free_memory / 1024);
}

// 内核主循环
static void kernel_main_loop() {
    console_printf("\n进入内核主循环\n");
    
    char buffer[256];
    char* argv[11]; //最多支持10个参数 + NULL结尾
    while (1) {
        console_printf("$ ");
        console_readline(buffer, sizeof(buffer));
        
        int argc = parse_command(buffer, argv);
        if (argc == 0) {
            continue; //空命令，直接跳过
        }
        
        if (strcmp(argv[0], "echo") == 0) {
           command_echo(argc, argv);
        } 
        else if (strcmp(argv[0], "help") == 0) {
            command_help(argc, argv);
        }
        else if (strcmp(argv[0], "alloc") == 0) {
            command_alloc(argc, argv);
        }
        else if (strcmp(argv[0], "free") == 0) {
            command_free(argc, argv);
        }
        else if (strcmp(argv[0], "list") == 0 && argc >= 2 && strcmp(argv[1], "alloc") == 0) {
            command_list_alloc(argc, argv);
        }
        else if (strcmp(argv[0], "meminfo") == 0) {
            command_meminfo(argc, argv);
        }
        else if (strcmp(argv[0], "bitmap") == 0) {
            command_bitmap(argc, argv);
        }
        else if (strcmp(argv[0], "clock") == 0) {
            command_clock(argc, argv);
        }
        else if (strcmp(argv[0], "exit") == 0) {
            command_exit(argc, argv);
        }
        else if (strcmp(argv[0], "memtest") == 0) {
            command_memtest(argc, argv);
        }
        else if (strcmp(argv[0], "lru") == 0) {
            command_lru(argc, argv);
        }
        else if (strcmp(argv[0], "fifo") == 0) {
            command_fifo(argc, argv);
        }
        else if (strcmp(argv[0], "algo") == 0) {
            command_algo(argc, argv);
        }
        else {
            console_printf("未知命令: %s\n", argv[0]);
        }
    }
}

// 初始化内核
void kernel_init(void) {
    console_init();
    console_clear();
    console_printf("=== 操作系统内核初始化 ===\n");
    
    page_frame_init();
    bitmap_init();
    page_table_init();
    vmm_init();
    interrupt_init();

    kernel_state.initialized = true;
    kernel_main_loop();
}