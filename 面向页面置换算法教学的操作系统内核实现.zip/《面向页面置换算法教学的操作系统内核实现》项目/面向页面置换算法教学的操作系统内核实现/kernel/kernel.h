#ifndef __KERNEL_H__
#define __KERNEL_H__

#include<stdint.h> 
#include<stdbool.h>
#include<stddef.h>
#include "../lib/common.h"

#define TIME_SLICE 10;

typedef struct{
    bool initialized;    //是否初始化
    u32 memory_size;     //物理内存总大小
    u32 free_memory;     //空闲物理内存大小
    u32 used_memory;     //已用物理内存大小
    u32 tick_count;      //系统运行时间(以时间片的个数为单位)
}kernel_t;

//函数声明
void kernel_init(void);
kernel_t* get_kernel_state(void);
void physical_memory_init(u32 total_memory);
void page_table_init(void);
void interrupt_init(void);
void isr_handler(u32 interrupt_number, u32 error_code);
void pic_init();
char get_keyboard_char();

#endif
