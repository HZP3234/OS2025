# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' 

# 配置变量
KERNEL_IMAGE="kernel.bin"
QEMU="qemu-system-i386"
QEMU_FLAGS="-kernel kernel.bin \
    -machine accel=tcg \
    -no-reboot \
    -no-shutdown \
    -serial stdio \
    -monitor none \
    -display none"

# 函数：打印带颜色的消息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1" >&2
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1" >&2
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" >&2
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1" >&2
}

# 函数：检查依赖
check_dependencies() {
    print_info "检查系统依赖..."
    
    local missing_deps=()
    
    # 检查 QEMU
    if ! command -v $QEMU &> /dev/null; then
        missing_deps+=("qemu-system-x86")
    fi
    
    # 检查 GCC
    if ! command -v gcc &> /dev/null; then
        missing_deps+=("gcc")
    fi
    
    # 检查 NASM
    if ! command -v nasm &> /dev/null; then
        missing_deps+=("nasm")
    fi
    
    # 检查 Make
    if ! command -v make &> /dev/null; then
        missing_deps+=("make")
    fi
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        print_error "缺少以下依赖: ${missing_deps[*]}"
        echo "请使用以下命令安装:"
        echo "  sudo apt update && sudo apt install ${missing_deps[*]}"
        return 1
    fi
    
    print_success "所有依赖已安装"
    return 0
}

# 函数：编译内核
compile_kernel() {
    print_info "开始编译操作系统内核..."
    
    if ! make all; then
        print_error "内核编译失败"
        return 1
    fi
    
    if [ ! -f "$KERNEL_IMAGE" ]; then
        print_error "内核镜像未生成: $KERNEL_IMAGE"
        return 1
    fi
    
    print_success "内核编译完成"
    return 0
}

# 函数：运行内核
run_kernel() {
    print_info "                   "
    print_info "       启动内核..."
    echo "=========================================="
    echo "  操作系统内核 - 页面置换算法教学平台"
    echo "=========================================="
    echo "模式: 基础内核运行（纯终端模式）"
    echo "命令: $QEMU $QEMU_FLAGS"
    echo "=========================================="
    
    $QEMU $QEMU_FLAGS
}

# 函数：清理
cleanup() {
    print_info "清理临时文件..."
    make clean
}

# 函数：主流程
main() {  
    # 检查参数
    local mode="basic"
    if [ $# -ge 1 ]; then
        mode="$1"
    fi
    
    # 检查依赖
    if ! check_dependencies; then
        exit 1
    fi
    
    # 根据模式执行
    case "$mode" in
        "kernel")
            if compile_kernel; then
                run_kernel
            else
                exit 1
            fi
            ;;
        "compile")
            compile_kernel
            ;;
        "clean")
            cleanup
            ;;
        *)
            print_error "未知模式: $mode"
            show_help
            exit 1
            ;;
    esac
    
    print_success "执行完成"
}

# 捕获用户中断
stty intr '^X'
trap 'echo -e "\n${YELLOW}[INFO]${NC} 用户中断 (Ctrl+X)"; exit 0' INT

# 启动主函数
main "$@"